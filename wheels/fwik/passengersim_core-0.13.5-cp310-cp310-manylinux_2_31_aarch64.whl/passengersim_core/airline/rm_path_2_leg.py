#
# Aggregate path forecasts to the leg level
#
# Alan W, Mathstream LLC, December 2022
#
from math import sqrt
from typing import Any, ClassVar, Literal

from passengersim_core import SimulationEngine
from passengersim.rm_steps import RmStep


# ------ RM STEP, USED TO PLUG THIS INTO THE SYSTEM -----------------------------------------------
#
class AggregationStep(RmStep):
    step_type: Literal["aggregation"]
    legs_by_airline: dict = {}

    @property
    def requires(self) -> list[str]:
        return ["path_forecast"]

    @property
    def produces(self) -> list[str]:
        return ["leg_forecast"]

    def run(
        self,
        sim: SimulationEngine,
        airline: str,
        dcp_index: int = 0,
        dcp: int = 0,
        debug: bool = False,
    ):
        if sim.sample < 3:
            return

        if debug:
            print("Aggregating, sample = ", sim.sample, ", airline = ", airline)

        sim.path_2_leg(airline)
        return

# Deprecated code, as I have implemented the aggregation in the C++ code now
#         if airline in self.legs_by_airline:
#             my_legs = self.legs_by_airline[airline]
#         else:
#             my_legs = [leg for leg in sim.legs if leg.carrier == airline]
#             self.legs_by_airline[airline] = my_legs
#
#         for leg in my_legs:
#             leg.fcst_mean = 0.0
#             leg.fcst_std_dev = 0.0
#             for bkt in leg.buckets:
#                 bkt.fcst_mean = 0.0
#                 bkt.fcst_std_dev = 0.0
#                 bkt.fcst_revenue = 0.0
#
#         for path in sim.paths:
#             if (path.get_leg_carrier(0) != airline):
#                 continue
#             path.accumulate_forecasts(debug)
#
#         for leg in my_legs:
#             # We actually added up the variance, so this gets us standard deviation
#             leg.fcst_std_dev = sqrt(leg.fcst_std_dev)
#             for bkt in leg.buckets:
#                 bkt.fcst_std_dev = sqrt(bkt.fcst_std_dev)
#                 if (bkt.fcst_mean > 0.0):
#                     bkt.fcst_revenue = bkt.fcst_revenue / bkt.fcst_mean

