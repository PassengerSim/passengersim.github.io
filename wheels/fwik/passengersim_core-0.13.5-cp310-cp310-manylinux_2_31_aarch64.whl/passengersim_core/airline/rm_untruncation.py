#
# Demand untruncation
#
# Alan W, Mathstream LLC, November 2022
#

import pathlib
from math import exp, pi, sqrt
from statistics import fmean, mean, pstdev
from time import time
from typing import Literal

import numpy as np
from passengersim_core import Demand, Leg
from scipy.optimize import minimize
from scipy.stats import norm
from passengersim.rm_steps import RmStep
from passengersim.snapshot import get_snapshot_instruction


# ------ UNTRUNCATION ADAPTER ----------------------------------------------------------------------
#
class UntruncationAdapter:
    """A facade class that can wrap a leg and work at the bucket_number or flight level,
    and can also wrap around a market to work at the O&D level
    Added bonus - also works standalone for testing
    Type == 1: Leg objects
    Type == 2: Leg objects, specified bucket_number
    Type == 3  Demand objects:
    Type == 4  Dummy object for testing:
    """

    # __slots__ = ["type", "leg", "bucket_number", "path", "sold", "capacity", "demand"]

    def __init__(self, *args):
        # If it's wrapping a Leg, keep that object handy
        self.type = 0
        self.sold = 0
        self.capacity = 0
        self.demand = 0
        self.leg, self.path = None, None

        if len(args) >= 1:
            if isinstance(args[0], Leg):
                self.type = 1
                self.leg = args[0]
                if len(args) >= 2:
                    self.type = 2
                    self.bucket = int(args[1])

            elif isinstance(args[0], Demand):
                self.type = 3
                self.path = args[0]

            elif isinstance(args[0], int) or isinstance(args[0], float):
                self.type = 4
                self.capacity = args[0]
                self.sold = args[1]

    #            else:
    #                raise Exception("Cannot create UntruncationAdapter")

    def is_closed(self):
        if self.type == 1:
            return self.leg.sold >= self.leg.capacity

        elif self.type == 2:
            return self.leg.sold >= self.leg.get_bucket_auth()

        elif self.type == 3:
            return False

        elif self.type == 4:
            return self.sold >= self.capacity

    def get_capacity(self):
        if self.type == 1:
            return self.leg.capacity

        elif self.type == 2:
            return self.leg.get_bucket_auth(self.bucket)

        elif self.type == 3:
            return 99

        elif self.type == 4:
            return self.capacity

    def get_sold(self):
        if self.type == 1:
            return self.leg.sold

        elif self.type == 2:
            return self.leg.get_bucket_sold(self.bucket)

        elif self.type == 3:
            return self.path.base_demand

        elif self.type == 4:
            return self.sold

    def __str__(self):
        return f"({int(self.capacity)}, {int(self.sold)}, {round(self.demand,2)})"

    def __repr__(self):
        return f"({int(self.capacity)}, {int(self.sold)}, {round(self.demand,2)})"


# ------ RM STEP, USED TO PLUG THIS INTO THE SYSTEM -----------------------------------------------
#


class UntruncationStep(RmStep):
    step_type: Literal["untruncation"]
    kind: Literal["leg", "path", "hybrid"] = "leg"
    algorithm: str

    @property
    def produces(self):
        if self.kind == "path":
            return ["path_demand"]
        elif self.kind == "hybrid":
            return ["hybrid_demand"]
        elif self.kind == "leg":
            return ["leg_demand"]
        else:
            raise ValueError(f"bad kind {self.kind!r}")

    def serialize(self):
        return {
            "step_type": "untruncation",
            "name": self.name,
            "algorithm": self.algorithm,
            "kind": self.kind,
        }

    def run(self, sim, _airline, _dcp_index=0, _dcp=0, _debug=False):
        if sim.sample < 10 or _dcp_index > 0:
            # do not do untruncation when there is not enough data.
            # only do it once per departure day, it shouldn't change for later DCPs.
            return
        if _debug:
            print("Untruncation, sample = ", sim.sample, ", airline = ", _airline)

        if self.kind == "leg":
            self.run_leg(sim, _airline, _dcp_index=_dcp_index, _dcp=_dcp, _debug=_debug)
        elif self.kind == "path":
            self.run_path(sim, _airline, _dcp_index=_dcp_index, _dcp=_dcp, _debug=_debug)

    def run_leg(self, sim, _airline, _dcp_index=0, _dcp=0, _debug=False):
        for leg in sim.legs:
            if leg.carrier != _airline:
                continue

            elif self.algorithm in ["em", "none", "naive1", "naive3"]:
                debug_print = _debug or get_snapshot_instruction(
                    sim, leg=leg, only_type="leg_untruncation"
                )
                snapshot_output = leg.untruncate_demand(_dcp_index, self.algorithm, debug_print)
                if snapshot_output:
                    print(snapshot_output)

            else:
                for bkt in leg.buckets:
                    self.do_single_bucket(leg, bkt, _dcp_index, _debug)

    def run_path(self, sim, _airline, _dcp_index=0, _dcp=0, _debug=False):
        for path in sim.paths:
            if path.get_leg_carrier(0) != _airline:
                continue
            debug_print = _debug or get_snapshot_instruction(sim, path=path, only_type="path_untruncation")
            path.untruncate_demand(_dcp_index, self.algorithm, debug_print)
            if debug_print:
                path.print_class_history(1)

    def do_single_bucket(self, leg, bkt, _dcp_index, _debug=False):
        # Get the data
        data = []
        prev_sold = 0
        for dep in range(bkt.get_history_num_dep()):
            sold = bkt.get_history_sold(dep, _dcp_index)
            inc_sold = sold - prev_sold
            closed = bkt.get_history_closed(dep, _dcp_index)
            capacity = inc_sold if closed else inc_sold * 1.5
            ua = UntruncationAdapter(capacity, inc_sold)
            data.append(ua)
            prev_sold = sold

        # Run the algorithm
        avg_dmd = 0.0
        if self.algorithm in ["none", ""]:
            for ua in data:
                ua.demand = ua.sold
        elif self.algorithm == "em_py":
            rc, iteration, avg_dmd = simple_em_untruncation(data, debug=False)
        elif self.algorithm == "pd":
            avg_dmd, iteration = projection_detruncation(
                wrapped_data, max_iteration=30, debug=False
            )
        elif self.algorithm == "naive1":
            avg_dmd = naive_1(data)
        elif self.algorithm == "naive2":
            avg_dmd = naive_2(data)
        elif self.algorithm == "naive3":
            avg_dmd = naive_3(data)
        else:
            raise Exception(f"Unknown algorithm for untruncation: {self.algorithm}")

        if _debug and leg.flt_no == 101 and bkt.name == "Y2" and _dcp_index == 3:
            print(f"flt:{leg.flt_no}, bkt:{bkt.name}, dcp:{_dcp_index}, data = ", data)
            print(f"    avg_dmd = {round(avg_dmd, 2)}")

        # Write it back to the system
        ua = data[0]
        bkt.set_history_demand(_dcp_index, ua.demand)

        return avg_dmd


# ------ EM (EXPECTATION-MAXIMIZATION) -------------------------------------------------------------
#
def expected_demand_given_capacity(mu: float, sigma: float, cap: float, debug=False):
    """Find E(dmd | Capacity)
    Uses the formula from Rick Zeni's dissertation
    """
    if mu < 0.01:
        return 0

    if sigma < 0.01:
        sigma = mu * 0.3

    numerator = (sigma / sqrt(2 * pi)) * exp(
        -((cap - mu) ** 2) / (2 * sigma**2)
    ) + mu * (1.0 - norm.cdf((cap - mu) / sigma))
    tmp = 1 - exp(-((cap - mu) ** 2) / (1.6 * sigma**2))
    denominator = 0.5 - 0.5 * sqrt(tmp) if cap >= mu else 0.5 + 0.5 * sqrt(tmp)
    if debug:
        print(
            f"numerator = {round(numerator, 5)}, denominator = {round(denominator, 5)}"
        )
        print(f"E(dmd | dmd > {cap}) = {round(numerator / denominator, 5)}")
    return numerator / denominator


def simple_em_untruncation(
    departures: list, epsilon: float = 0.0001, max_iter: int = 10, debug=False
):
    """Untruncation using Expectation-Maximization"""
    if len(departures) == 0:
        return True, 0, 0.0

    for d in departures:
        d.demand = d.get_sold()

    # Observed demand is never negative, so -1 is safe, and we also won't divide by zero
    prev_mu = -1.0
    for iteration in range(max_iter):
        tmp = [d.demand for d in departures]
        mu = fmean(tmp)
        sigma = pstdev(tmp)
        for d in departures:
            if d.is_closed():  # constrained
                d.demand = expected_demand_given_capacity(mu, sigma, d.get_capacity())

        if debug:
            print(
                f"iteration {iteration}: μ = {round(mu, 5)}, σ = {round(sigma, 5)}"
                f" | dmd = ",
                ", ".join([f"{d.demand:.3f}" for d in departures]),
            )

        # Only testing overall mean for now, not individual flights
        if abs(prev_mu) < epsilon or abs((mu - prev_mu) / prev_mu) < epsilon:
            return True, iteration, mu
        prev_mu = mu

    mu = fmean([d.demand for d in departures])
    return False, max_iter, mu  # Did not converge


# ------ PROJECTION DETRUNCATION -------------------------------------------------------------------
#
def get_pd_ratio(x_projected: float, x_censored: float, mu: float, sigma: float):
    neg_inf_to_b = norm.cdf(x_projected, loc=mu, scale=sigma)
    neg_inf_to_a = norm.cdf(x_censored, loc=mu, scale=sigma)
    b_to_inf = 1.0 - neg_inf_to_b
    a_to_inf = 1.0 - neg_inf_to_a
    area_a = a_to_inf - b_to_inf
    ratio = b_to_inf / (b_to_inf + area_a)
    # print("-->", x_projected, ratio)
    return ratio


def optimize_pd(x_censored: float, mu: float, sigma: float, tau: float, debug=False):
    results = minimize(
        lambda x: (tau - get_pd_ratio(x, x_censored, mu, sigma)) ** 2,
        x0=np.array([x_censored]),
        options={"maxiter": 200},
        bounds=[(0.01, 100)],
    )
    if debug:
        print("optimize_pd", results)
    return float(results.x[0])


def projection_detruncation(
    departures: list,
    max_iter: int = 20,
    tau: float = 0.3,
    epsilon: float = 0.0001,
    debug: bool = False,
):
    """Based on the method developed by Hopperstad and described by Weatherford & Polt"""
    for d in departures:
        d.demand = d.get_sold()

    mu, prev_mu = 0.0, 0.0
    for iteration in range(max_iter):
        mu = mean([d.demand for d in departures])
        sigma = pstdev([d.demand for d in departures])
        if abs(mu - prev_mu) < epsilon:  # Convergence test
            break
        prev_mu = mu

        for d in departures:
            if d.is_closed():  # constrained
                d.demand = optimize_pd(d.get_capacity(), mu, sigma, tau)

        if debug:
            tmp = [round(d.demand, 2) for d in departures]
            print(f"Iteration: {iteration}, mu = {round(mu, 5)}")
            print("    ", tmp)
    return mu, iteration


# ------ NAIVE METHODS ------------------------------------------------------------------------
#
def naive_1(departures: list, debug: bool = False):
    """Replace constrained demand by mean of all cases (Shebalov 2022)"""
    mu = mean([d.get_sold() for d in departures])
    avg_dmd = 0.0
    for d in departures:
        if d.is_closed():  # constrained
            d.demand = mu
        else:
            d.demand = d.get_sold()
        avg_dmd += d.demand
    return avg_dmd / len(departures)  # Mostly used for the unit tests


def naive_2(departures: list, debug: bool = False):
    """Replace constrained demand with mean of open cases (Shebalov 2022)"""
    mu = mean([d.get_sold() for d in departures if not d.is_closed()])
    avg_dmd = 0.0
    for d in departures:
        if d.is_closed():  # constrained
            d.demand = mu
        else:
            d.demand = d.get_sold()
        avg_dmd += d.demand
    return avg_dmd / len(departures)  # Mostly used for the unit tests


def naive_3(departures: list, debug: bool = False):
    """Replace constrained demand with max of mean of open cases and actual (Shebalov 2022)"""
    open_flights = [d.get_sold() for d in departures if not d.is_closed()]

    mu = mean(open_flights) if len(open_flights) > 0 else None
    avg_dmd = 0.0
    for d in departures:
        if d.is_closed() and mu is not None and mu > d.get_sold():
            d.demand = mu
        else:
            d.demand = d.get_sold()
        avg_dmd += d.demand
    return avg_dmd / len(departures)  # Mostly used for the unit tests


# ------ TRY IT OUT ------------------------------------------------------------------------
#
def data1():
    """Use the wrapper class directly"""
    data = [
        UntruncationAdapter(20, 18),
        UntruncationAdapter(19, 19),
        UntruncationAdapter(17, 17),
        UntruncationAdapter(22, 19),
        UntruncationAdapter(21, 20),
        UntruncationAdapter(18, 17),
        UntruncationAdapter(19, 19),
        UntruncationAdapter(21, 21),
        UntruncationAdapter(22, 18),
        UntruncationAdapter(20, 20),
    ]
    return data


def data1b():
    """Use the wrapper class directly"""
    data = [
        UntruncationAdapter(20, 18),
        UntruncationAdapter(1, 19),
        UntruncationAdapter(1, 17),
        UntruncationAdapter(22, 19),
        UntruncationAdapter(21, 20),
        UntruncationAdapter(18, 17),
        UntruncationAdapter(19, 19),
        UntruncationAdapter(1, 21),
        UntruncationAdapter(22, 18),
        UntruncationAdapter(1, 20),
    ]
    return data


def data2():
    """Wrapper class around some legs"""
    _data = [
        Leg("XX", 0, "ABQ", "DFW", sold=18, capacity=20),
        Leg("XX", 1, "ABQ", "DFW", sold=19, capacity=19),
        Leg("XX", 2, "ABQ", "DFW", sold=17, capacity=17),
        Leg("XX", 3, "ABQ", "DFW", sold=19, capacity=22),
        Leg("XX", 4, "ABQ", "DFW", sold=20, capacity=21),
        Leg("XX", 5, "ABQ", "DFW", sold=17, capacity=18),
        Leg("XX", 6, "ABQ", "DFW", sold=19, capacity=19),
        Leg("XX", 7, "ABQ", "DFW", sold=21, capacity=21),
        Leg("XX", 8, "ABQ", "DFW", sold=18, capacity=22),
        Leg("XX", 9, "ABQ", "DFW", sold=20, capacity=20),
    ]
    tmp = [UntruncationAdapter(leg) for leg in _data]
    return tmp


if __name__ == "__main__":
    print("##### Demo the expected demand function")
    mu1 = 18.8
    sigma1 = 1.25
    cap1 = 20
    exp_dmd = expected_demand_given_capacity(mu1, sigma1, cap1, debug=True)
    print(f"μ = {mu1}, σ = {sigma1}, E(dmd | dmd > {cap1}) = {round(exp_dmd, 5)}")

    mu1 = 0.428571
    sigma1 = 0.728431
    cap1 = 1
    exp_dmd = expected_demand_given_capacity(mu1, sigma1, cap1, debug=True)
    print(f"μ = {mu1}, σ = {sigma1}, E(dmd | dmd > {cap1}) = {round(exp_dmd, 5)}")

    print("##### Demo a list of flights, spreadsheet example")
    data = data1()
    wrapped_data = data

    start_time = time()
    rc, iteration, mu = simple_em_untruncation(data, debug=True)
    elapsed = time() - start_time
    if rc:
        print(
            f"Simple EM converged in {iteration} iterations, mu = {mu},  elapsed = {round(elapsed, 3)}"
        )
        tmp = "  ".join([str(ua.demand) for ua in data])
        print(tmp)

    start_time = time()
    rc, iteration, mu = simple_em_untruncation(data1b(), debug=False)
    elapsed = time() - start_time
    if rc:
        print(
            f"Simple EM2 converged in {iteration} iterations, mu = {mu}, elapsed = {round(elapsed, 3)}"
        )

    z = naive_3(data)
    print(f"New average from naive_3 = {z}")
    z = naive_3(wrapped_data)
    print(f"New average from naive_3 (wrapped) = {z}")

    z = get_pd_ratio(20.20146, 19, 18.8, 1.249)
    print(f"Test of get_pd_ratio, z = {z}")
    z = optimize_pd(19, 18.8, 1.249, tau=0.3)
    print(f"Test of optimize_pd, z = {z}")

    start_time = time()
    z, iteration = projection_detruncation(data, max_iter=30, debug=False)
    elapsed = time() - start_time
    print(
        f"New average from PD = {round(z, 5)}, iterations = {iteration}, elapsed = {round(elapsed, 3)}"
    )

    start_time = time()
    z, iteration = projection_detruncation(wrapped_data, max_iter=30, debug=False)
    elapsed = time() - start_time
    print(
        f"New average from PD = {round(z, 5)}, iterations = {iteration}, elapsed = {round(elapsed, 3)}"
    )
