#
# Custom exceptions for PassengerSim
#
# Alan W, Mathstream LLC, December 2022
#


class InputParseException(Exception):
    """Thrown when the input file has syntax errors"""
    pass

