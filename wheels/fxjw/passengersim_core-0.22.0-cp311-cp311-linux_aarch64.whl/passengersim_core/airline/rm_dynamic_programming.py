#
# Adding a leg-based DP to PassengerSim
#
# - This shows the structure, you can plug your DP in below
#
# Alan W, Mathstream LLC, April 2023
#
import math
from math import floor, sqrt
from statistics import NormalDist

from passengersim_core import Bucket
from passengersim_core import Leg
from passengersim_core.airline.rm_step import RmStep


# ------ RM STEP, USED TO PLUG THIS INTO THE SYSTEM -----------------------------------------------
#
class DynamicProgramStep(RmStep):
    def __init__(self, _name, _algorithm):
        super().__init__()
        self.name = _name
        self.algorithm = _algorithm
        self.requires = ["leg_forecast"]

    def serialize(self):
        return {
            'step_type': "optimization",
            'name': self.name,
            'algorithm': "dp",
        }

    def run(self, sim, _airline, _dcp_index=0, _days_prior=0, _debug=False):
        # This lets the forecasts get a little stable first
        if sim.sample < 10: # or sim.num_events() > 0:
            return

        # Only run for the airline we've been asked to process
        for leg in sim.legs:
            if leg.carrier != _airline:
                continue

            # self.compute_decision_fares(leg)
            self.static_decision_fares(leg)

            emsr_b(leg, debug=_debug)

            # This is an example of how to print for a subset for flight / sample / dcp
            if _debug:   #  or (leg.flt_no == 101 and sim.sample in [10, 20, 30] and sim.last_dcp in [21]):
                print(f"Sample = {sim.sample}, DCP = {sim.last_dcp}")
                print(leg.print_bucket_detail())

    # Just leave these alone
    def static_decision_fares(self, leg):
        if leg.orig == 'BOS' and leg.dest == 'ORD':
            leg.set_bucket_fcst_revenue(0, 400)
            leg.set_bucket_fcst_revenue(1, 300)
            leg.set_bucket_fcst_revenue(2, 200)
            leg.set_bucket_fcst_revenue(3, 150)
            leg.set_bucket_fcst_revenue(4, 125)
            leg.set_bucket_fcst_revenue(5, 100)
        else:
            leg.set_bucket_fcst_revenue(0, 500)
            leg.set_bucket_fcst_revenue(1, 400)
            leg.set_bucket_fcst_revenue(2, 300)
            leg.set_bucket_fcst_revenue(3, 225)
            leg.set_bucket_fcst_revenue(4, 175)
            leg.set_bucket_fcst_revenue(5, 150)

    def compute_decision_fares(self, leg):
        """Exponential smoothing of actual revenue, rather than fixed decision fares"""
        for bkt in leg.buckets:
            if bkt.revenue > 0:
                bkt.fcst_revenue = 0.85 * bkt.fcst_revenue + 0.15 * bkt.revenue / bkt.sold


# ------ RM OPTIMIZATION ALGORITHMS --------------------------------------------------------------------
#
# - You would put the DP code in here, to replace the EMSRb
# - Use the methods and attributes on Leg and Bucket to get data and then set nested allocations
#
def littlewood(mu, sigma, rev_low, rev_hi, cv100=0.2):
    # print("littlewood", mu, sigma, rev_low, rev_hi)
    # In case I don't have standard deviation, use cv100
    if sigma is None or sigma < 0.001:
        sigma = cv100 * sqrt(mu) * 10.0

    if mu <= 0.01:
        return 0

    # Beware of fare inversions
    if rev_low >= rev_hi or rev_low < 1:
        prot = 0.0
    else:
        z = 1.0 - rev_low / rev_hi
        prot = NormalDist(mu=mu, sigma=sigma).inv_cdf(z)
    if math.isnan(prot):
        prot = 0.0
    return max(prot, 0.0)


def emsr_b(leg: bool=False, debug: bool=False):
    capacity = leg.capacity
    prot = 0.0   # if theftNesting else leg.sold
    for j in range(leg.get_num_buckets() - 1):
        alloc = max(0, math.floor(capacity - (prot + leg.sold)))
        leg.bucket(j).alloc = alloc

        # Get weighted average down to and including bucket_number j
        fare_num, fare_denom = 0.0, 0.0
        agg_mu, agg_sigma = 0.0, 0.0
        for k in range(j+1):
            b = leg.bucket(k)
            fare_num += b.fcst_revenue * b.fcst_mean
            fare_denom += b.fcst_mean
            agg_mu += b.fcst_mean
            agg_sigma += b.fcst_std_dev ** 2
        agg_fare = fare_num / fare_denom if fare_denom > 0 else 0
        agg_sigma = sqrt(agg_sigma)
        rev_low = leg.bucket(j+1).fcst_revenue

        prot = littlewood(mu=agg_mu, sigma=agg_sigma, rev_low=rev_low, rev_hi=agg_fare)
        # prot = round(prot)
        leg.bucket(j).protection = round(prot)
        if debug:
            print(f"Class {leg.bucket(j).name}, sold={leg.bucket(j).sold}, mu={round(leg.bucket(j).fcst_mean, 2)}"
                  f" agg_fare={round(agg_fare, 2)}, rev_low={round(rev_low, 2)}, agg_mu={round(agg_mu, 2)},"
                  f" agg_sigma={round(agg_sigma, 2)}, prot={round(prot, 2)}, auth={leg.bucket(j).alloc}")

    # Whatever is left goes into the last bucket_number (no protection as nothing is below it)
    alloc = max(0, round(capacity - (prot + leg.sold)))
    leg.bucket(leg.get_num_buckets() - 1).alloc = alloc

    if debug:
        j = leg.get_num_buckets() - 1
        print(f"Class {leg.bucket(j).name}, sold={leg.bucket(j).sold}, mu={round(leg.bucket(j).fcst_mean, 2)}"
              f" agg_fare={round(agg_fare, 2)}, agg_mu={round(agg_mu, 2)},"
              f" agg_sigma={round(agg_sigma, 2)}, prot={0}, auth={leg.bucket(j).alloc}")

    #if debug and leg.flt_no == 101:
    #if leg.flt_no == 201:
    #    leg.print_bucket_detail()


# This evaluates to True if Python is running this as the main module, i.e. "python rm_dynamic_programming.py"
# It's a simple way to run stuff and lets other file import functions and classes from this file
# but without running this code.
if __name__ == "__main__":
    prot = littlewood(mu=19.15, sigma=81.9, rev_low=240.7, rev_hi=278.54)
    print("Test 1, prot = ", prot)

    leg = Leg("AL1", 123, "BOS", "ORD", capacity=100, duration=60)
    leg.sold = 46
    leg.add_bucket(Bucket("FC1", 100, 200, sold=1, revenue=676.63, fcst_mean=7.35, fcst_std_dev=3.9))
    leg.add_bucket(Bucket("FC2", 100, 200, sold=4, revenue=428.56, fcst_mean=11.50, fcst_std_dev=6.82))
    leg.add_bucket(Bucket("FC3", 100, 200, sold=1, revenue=315.83, fcst_mean=9.46, fcst_std_dev=6.23))
    leg.add_bucket(Bucket("FC4", 100, 200, sold=0, revenue=250.96, fcst_mean=11.51, fcst_std_dev=23.83))
    leg.add_bucket(Bucket("FC5", 100, 200, sold=36, revenue=201.89, fcst_mean=17.93, fcst_std_dev=8.41))
    leg.add_bucket(Bucket("FC6", 100, 200, sold=4, revenue=151.16, fcst_mean=7.16, fcst_std_dev=4.94))
    for i in range(6):
        rev = leg.get_bucket_revenue(i)
        leg.set_bucket_fcst_revenue(i, rev)
    print("***** EMSRb - PODS example")
    emsr_b(leg, debug=False)
    print(leg.print_bucket_detail())
