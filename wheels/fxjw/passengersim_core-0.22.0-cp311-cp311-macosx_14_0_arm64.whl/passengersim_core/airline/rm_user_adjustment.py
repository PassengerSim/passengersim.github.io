#
# Simulate users overriding the RM recommendations
#
# Alan W, Mathstream LLC, March 2024
#
from typing import Any, Literal

from passengersim_core import SimulationEngine, Bucket, Leg
from passengersim.config import SnapshotFilter
from passengersim.rm_steps import RmStep


# ------ RM STEP, USED TO PLUG THIS INTO THE SYSTEM -----------------------------------------------

class UserAdjustmentStep(RmStep):
    snapshot_filters: list[Any] = []
    step_type: Literal["useradjustment"]

    def serialize(self):
        return {
            "step_type": "useradjustment",
            "name": self.name,
        }

    def run(self, sim: SimulationEngine, airline, dcp_index=0, _days_prior=0, debug=False):
        if sim.sample < sim.rm_start_sample:
            return
        for leg in sim.legs:
            if leg.carrier != airline:
                continue
            self.check_competition(sim, leg)

    def check_competition(self, sim: SimulationEngine, leg: Leg):
        # First, we turn off the force closed flags
        for bkt in leg.buckets:
            bkt.force_closed = False

        # Check competitors lowest fare
        for mkt in sim.markets:
            if mkt.orig == leg.orig and mkt.dest == leg.dest:
                my_lowest, market_lowest = 9e9, 9e9
                for cxr in sim.airlines:
                    price = mkt.get_competitor_price(cxr.name)
                    if cxr.name == leg.carrier:
                        my_lowest = min(my_lowest, price)
                    else:
                        market_lowest = min(market_lowest, price)

                # Don't be the cheapest !!!
                if my_lowest < market_lowest:
                    lowest_open_bkt = None
                    for bkt in leg.buckets:
                        if bkt.alloc > 0:
                            lowest_open_bkt = bkt
                    if lowest_open_bkt is not None:
                        lowest_open_bkt.force_closed = True
                        # print(f"Force close, flt={leg.flt_no}, bkt={lowest_open_bkt.name}, my_lowest={my_lowest}, market_lowest={market_lowest}")


if __name__ == "__main__":
    print("Hello World, I'm an RM Analyst !!!")

