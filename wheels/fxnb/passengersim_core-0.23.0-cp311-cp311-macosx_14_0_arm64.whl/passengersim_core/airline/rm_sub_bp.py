#
# RM Step to use SubBP
#  - Used CoreProBP to do the work
#  - Only real difference is that we subtract displacement instead of prorating
#
# Alan W, Mathstrem LLC, June 2024
#
import pathlib
from time import time
from typing import Any, Literal

from passengersim_core import (
    SimulationEngine,
    Bucket,
    Demand,
    Fare,
    Leg,
    Path,
    PathClass,
    ProBP,
)
from passengersim.config import SnapshotFilter, SnapshotInstruction
from passengersim.rm_steps import RmStep


class SubBpStep(RmStep):
    """Implements SubBP as an RM Step"""

    snapshot_filters: list[Any] = []

    step_type: Literal["subbp"]

    kind: Literal["path"] = "path"
    """
    SubBP is a path-based optimization algorithm.

    The `kind` parameter is included in the interface for compatability, but setting
    any value here other than `path` will result in an error.
    """

    maxiter: int = 10
    """
    The maximum number of iterations to run SubBP. 
    
    If the algorithm has not converged by the time this number of iterations has 
    been reached, it will stop and return the current results.
    """

    @property
    def requires(self) -> list[str]:
        return ["path_forecast"]

    @property
    def produces(self) -> list[str]:
        return ["bid_price", "displacement"]

    def __init__(self, **data):
        super().__init__(**data)
        self._sub_bp = {}

    @property
    def sub_bp(self):
        return self._sub_bp

    def serialize(self):
        return {
            "step_type": "subbp",
            "name": self.name,
        }

    def run(
            self,
            sim: SimulationEngine,
            airline: str,
            dcp_index: int = 0,
            dcp: int = 0,
            debug: bool = False,
    ):
        if sim.sample < 10:  # or sim.num_events() > 0:
            return

        # We keep a map of core objects, as the CoreProBP code caches
        # the data structures it needs for each iteration
        if airline not in self.sub_bp:
            tmp = ProBP(sim, airline)
            tmp.use_sub_bp = True
            self.sub_bp[airline] = tmp

        z = self.sub_bp[airline]
        debug_print = debug
        if sim.snapshot_filters is not None:
            snapshot_filters = sim.snapshot_filters
        else:
            snapshot_filters = SnapshotFilter.filters
        snapshot_instuction = None
        for sf in snapshot_filters:
            if sf.type != "pro_bp":
                continue
            snapshot_instuction = sf.run(sim, carrier=airline)
            info = getattr(sf, "_last_run_info", "")
            if snapshot_instuction and (sf.airline == airline or sf.airline == ""):
                debug_print = True
                z.debug_fltno = sf.flt_no[0] if len(sf.flt_no) > 0 else 0
                debug_output_title = sf.title
                break

        debug_output = z.run(self.maxiter, snapshot_instuction)
        if debug_output:
            print(debug_output)


if __name__ == "__main__":
    print("Hello from SubBP")
