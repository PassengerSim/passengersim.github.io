from ortools.linear_solver import pywraplp
from typing import Any, Literal

from passengersim_core import SimulationEngine, DynamicProgram
from passengersim.rm_steps import RmStep

import numpy as np
from passengersim.config import SnapshotFilter

from typing import Annotated
from pydantic import Field


class LpDisplacementSolver:
    __slots__ = ('carrier', 'solver', 'objective', 'lp_vars', 'constraints')

    def __init__(self, sim: SimulationEngine, carrier: str):
        self.carrier = carrier
        self.solver = pywraplp.Solver.CreateSolver("GLOP")
        self.objective = self.solver.Objective()
        self.objective.SetMaximization()

        # create LP decision variables, which are how many passengers to accept for each path class
        self.lp_vars = {}
        for path in sim.paths:
            if path.carrier == carrier:
                for pc in path.pathclasses:
                    name = pc.identifier
                    fare = pc.fare_price
                    pc_dmd = pc.fcst_mean
                    self.lp_vars[name] = x = self.solver.NumVar(0, pc_dmd, name)
                    self.objective.SetCoefficient(x, fare)

        # Create capacity constraints
        self.constraints = {}
        for leg in sim.legs:
            if leg.carrier != carrier:
                continue
            ct = self.solver.Constraint(0, leg.capacity - leg.sold, f"Leg-{leg.flt_no}")
            for pc_id in leg.pathclass_identifiers:
                ct.SetCoefficient(self.lp_vars[pc_id], 1)
            self.constraints[leg.flt_no] = ct

    def update(self, sim: SimulationEngine):
        # update LP decision variables, which are how many passengers to accept for each path class
        for path in sim.paths:
            if path.carrier == self.carrier:
                for pc in path.pathclasses:
                    self.lp_vars[pc.identifier].SetUb(pc.fcst_mean)

        # Create capacity constraints
        for leg in sim.legs:
            if leg.carrier != self.carrier:
                continue
            self.constraints[leg.flt_no].SetUb(leg.capacity - leg.sold)

    def solve(self, sim: SimulationEngine):
        self.solver.Solve()
        # The bid prices used to find displacement adjusted fares are the dual
        # values of the capacity constraints
        for leg in sim.legs:
            if leg.carrier != self.carrier:
                continue
            # the duals of the contraints are the displacement costs.
            # In theory they should be non-negative by construction, but we
            # enforce that here because the solver can sometimes return tiny
            # negative values due to numerical imprecision.
            leg.displacement = max(self.constraints[leg.flt_no].dual_value(), 0)


class UdpStep(RmStep):
    """Implements UDP as an RM Step"""

    snapshot_filters: list[Any] = []

    step_type: Literal["udp"]

    kind: Literal["path"] = "path"
    """
    UDP is a path-based optimization algorithm.

    The `kind` parameter is included in the interface for compatability, but setting
    any value here other than `path` will result in an error.
    """

    store_bid_prices: Literal["daily", "dcp"] = "daily"
    """
    The `store_bid_prices` parameter determines how bid prices are used.
    
    If `store_bid_prices` is set to `daily`, then the bid prices are stored for 
    each day prior to departure by dividing each DCP into its component days, and
    then the bid prices are stored for each day, so they can vary for the same level
    of remaining capacity over the days in the DCP.  If set to `dcp`, then the bid
    prices are stored only for each DCP, and are the same for each day within the 
    DCP.
    
    Note that if `store_bid_prices` is set to `daily`, then there must be a call to
    the `udpupdate` RM step in the DAILY section of the RM configuration, which
    updates the bid price algorithm about which day's bid prices to be using in 
    offer generation.
    """

    reoptimize: Literal["once", "dcp"] = "dcp"
    """
    The `reoptimize` parameter determines how often the UDP is re-run.
    
    If `reoptimize` is set to `once`, then the UDP is run once for each sample,
    based only the forecast sales by DCP over the entire booking curve.  If set
    to `dcp`, then the UDP is re-run for each DCP, and information on prior sales
    in this sample is used to adjust the displacement costs.
    """

    arrivals_per_time_slice: Annotated[float, Field(gt=0, le=1.0)] = 1.0
    """
    The number of arrivals in each time slice.
    
    The number of DP simulation time slices in each time period is scaled so the 
    total arrivals over all path-classes in one time slice is approximately equal 
    to this value. It should not be set to a value greater than 1.0, as this will
    cause the DP to be under-populated.
    """

    min_time_slices_per_dcp: int = 1
    """
    The minimum number of time slices in each DCP.
    
    This minimum overrides the `arrivals_per_time_slice` parameter, and ensures 
    that each DCP has at least this many time slices.
    """

    @property
    def requires(self) -> list[str]:
        return ["path_forecast"]

    def __init__(self, **data):
        super().__init__(**data)
        self._udp = {}
        self._lp = {}
        self._max_days_prior = None
        self._dcp_days = None

    def set_dcps(self, dcps: list[int]):
        self._max_days_prior = max(dcps)
        self._dcps = dcps
        if self.store_bid_prices == "daily":
            self._dcp_days = -np.diff(dcps, append=0)
            if self._dcp_days.min() <= 0:
                raise ValueError("DCPs must be strictly descending")

    @property
    def udp(self):
        return self._udp

    def serialize(self):
        return {
            "step_type": "udp",
            "name": self.name,
        }

    def run(
        self,
        sim: SimulationEngine,
        airline: str,
        dcp_index: int = 0,
        dcp: int = 0,
        debug: bool = False,
    ):
        if sim.sample < 10:
            return

        if sim.snapshot_filters is not None:
            snapshot_filters = sim.snapshot_filters
        else:
            snapshot_filters = SnapshotFilter.filters
        snapshot_instruction = None

        for sf in snapshot_filters:
            if sf.type != "udp":
                continue
            snapshot_instruction = sf.run(sim, carrier=airline)

        if self._max_days_prior is None:
            self.set_dcps(sim.config.dcps)

        # We keep a map of core objects, as the CoreDP code caches
        # the data structures it needs for each iteration
        if airline not in self.udp:
            self.udp[airline] = DynamicProgram(sim, airline)
            self.udp[airline].initialize()

        dp = self.udp[airline]

        if self.reoptimize == "dcp" or (dcp_index == 0 and dcp == self._max_days_prior):
            # todo: cache the setup for the LP if needed
            self.solve_airline_lp_for_leg_fare_displacements(sim, airline)

            for leg in sim.legs:
                if leg.carrier != airline:
                    continue
                debug_output = dp.solve_for_leg(
                    leg,
                    n_dcps=len(self._dcps),
                    snapshot_instruction=snapshot_instruction,
                    dcp_days=self._dcp_days,
                    arrivals_per_time_slice=self.arrivals_per_time_slice,
                    min_time_slices_per_dcp=self.min_time_slices_per_dcp,
                )
                if debug_output:
                    print(debug_output)
                # leg needs to know current BP index to pick the column when getting bid price
                if self.store_bid_prices == "daily":
                    leg.bp_index = self._max_days_prior - dcp
                else:
                    leg.bp_index = dcp_index

        else:
            for leg in sim.legs:
                if leg.carrier != airline:
                    continue
                if self.store_bid_prices == "daily":
                    leg.bp_index = self._max_days_prior - dcp
                else:
                    leg.bp_index = dcp_index

    def solve_airline_lp_for_leg_fare_displacements(
        self,
        sim: SimulationEngine,
        airline: str,
    ):
        if airline in self._lp:
            try:
                # it is faster to update the LP than to recreate it
                self._lp[airline].update(sim)
            except KeyError:
                # If we didn't set up the LP correctly with all the pathclasses,
                # then we need to recreate it.
                # TODO: this should not be needed if all pathclasses are initialized correctly
                self._lp[airline] = LpDisplacementSolver(sim, airline)
        else:
            self._lp[airline] = LpDisplacementSolver(sim, airline)
        self._lp[airline].solve(sim)


class UdpUpdateStep(RmStep):
    """Implements UDP as an RM Step"""

    snapshot_filters: list[Any] = []

    step_type: Literal["udpupdate"]

    kind: Literal["path"] = "path"
    """
    UDP is a path-based optimization algorithm.

    The `kind` parameter is included in the interface for compatability, but setting
    any value here other than `path` will result in an error.
    """

    @property
    def requires(self) -> list[str]:
        return []

    def __init__(self, **data):
        super().__init__(**data)
        self._max_days_prior = None

    def set_dcps(self, dcps: list[int]):
        self._max_days_prior = max(dcps)

    def serialize(self):
        return {
            "step_type": "udpupdate",
            "name": self.name,
        }

    def run(
        self,
        sim: SimulationEngine,
        airline: str,
        dcp_index: int = 0,
        dcp: int = 0,
        debug: bool = False,
    ):
        if sim.sample < 10:
            return

        if self._max_days_prior is None:
            self.set_dcps(sim.config.dcps)

        for leg in sim.legs:
            if leg.carrier != airline:
                continue
            leg.bp_index = self._max_days_prior - dcp
