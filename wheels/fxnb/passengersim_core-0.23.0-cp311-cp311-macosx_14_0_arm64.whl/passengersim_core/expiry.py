import datetime
from ._SimulationEngine import SimulationEngine


def build_expiration():
    return SimulationEngine("").build_expiration().astimezone(datetime.timezone.utc)
