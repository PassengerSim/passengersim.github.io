#
# RM Step to use Linear Programming
#
# For now, it's largely a placeholder, but there are some things I'd like to do with LP
#  - Displacement calculation for DAVN
#  - Deterministic LP, just as a base model
#  - Piecewise Linear approximation
#  - Sales Based LP (SBLP), along the lines of Sabre's model
#
# Alan W, Mathstrem LLC, June 2024
#
from time import time
from ortools.linear_solver import pywraplp
from typing import Any, Literal

from passengersim_core import (
    SimulationEngine,
    Bucket,
    Demand,
    Fare,
    Leg,
    Path,
    PathClass,
    ProBP,
)
from passengersim.config import SnapshotFilter, SnapshotInstruction
from passengersim.rm_steps import RmStep
from passengersim_core import DynamicProgram


class LpStep(RmStep):
    """Implements Linear Programming as an RM Step"""

    snapshot_filters: list[Any] = []

    step_type: Literal["lp"]

    kind: Literal["path"] = "path"
    """
    LP is a path-based optimization algorithm - but I might add leg in the future...

    The `kind` parameter is included in the interface for compatability, but setting
    any value here other than `path` will result in an error.
    """

    @property
    def requires(self) -> list[str]:
        return ["path_forecast"]

    @property
    def produces(self) -> list[str]:
        return ["bid_price", "displacement"]

    def __init__(self, **data):
        super().__init__(**data)
        self._lp = {}

    @property
    def lp(self):
        return self._lp

    def serialize(self):
        return {
            "step_type": "lp",
            "name": self.name,
        }

    def run(
            self,
            sim: SimulationEngine,
            airline: str,
            dcp_index: int = 0,
            dcp: int = 0,
            debug: bool = False,
    ):
        if sim.sample < 10:  # or sim.num_events() > 0:
            return

        if airline not in self._lp:
            self._lp[airline] = LpSimpleSolver(sim, airline)
            tmp = DynamicProgram(sim, airline)
            tmp.initialize()   # This step sets up the PcPtr structures, will refactor later to make this a separate call
            # self._lp[airline].initialize()

        s = self._lp[airline]
        s.update(sim)
        s.solve(sim)

        debug_print = debug
        if sim.snapshot_filters is not None:
            snapshot_filters = sim.snapshot_filters
        else:
            snapshot_filters = SnapshotFilter.filters
        snapshot_instruction = None
        for sf in snapshot_filters:
            if sf.type != "lp":
                continue
            snapshot_instuction = sf.run(sim, carrier=airline)
            info = getattr(sf, "_last_run_info", "")
            if snapshot_instuction and (sf.airline == airline or sf.airline == ""):
                debug_print = True
                # z.debug_fltno = sf.flt_no[0] if len(sf.flt_no) > 0 else 0
                debug_output_title = sf.title
                break

        debug_output = None  # z.run(self.maxiter, snapshot_instuction)
        if debug_output:
            print(debug_output)


class LpSimpleSolver:
    __slots__ = ('carrier', 'solver', 'objective', 'lp_vars', 'constraints')

    def __init__(self, sim: SimulationEngine, carrier: str):
        self.carrier = carrier
        self.solver = pywraplp.Solver.CreateSolver("GLOP")
        self.objective = self.solver.Objective()
        self.objective.SetMaximization()

        # create LP decision variables, which are how many passengers to accept for each path class
        self.lp_vars = {}
        for path in sim.paths:
            if path.carrier == carrier:
                for pc in path.pathclasses:
                    name = pc.identifier
                    # name = f"{path.path_id}{pc.identifier}"
                    # name = f"{path.get_leg_fltno(0)}-{path.get_leg_fltno(1) if path.num_legs() > 1 else 0}{pc.identifier}"
                    fare = pc.fare_price
                    pc_dmd = pc.fcst_mean
                    self.lp_vars[name] = x = self.solver.NumVar(0, pc_dmd, name)
                    self.objective.SetCoefficient(x, fare)

        # Create capacity constraints
        # print("CAPACITY CONSTRAINTS")
        self.constraints = {}
        for leg in sim.legs:
            if leg.carrier != carrier:
                continue
            ct = self.solver.Constraint(0, leg.capacity - leg.sold, f"Leg-{leg.flt_no}")
            for pc_id in leg.pathclass_identifiers:
                ct.SetCoefficient(self.lp_vars[pc_id], 1)
                # print(f"  Leg={leg}, pc_id={pc_id}")
            self.constraints[leg.flt_no] = ct

    def update(self, sim: SimulationEngine):
        # update LP decision variables, which are how many passengers to accept for each path class
        for path in sim.paths:
            if path.carrier == self.carrier:
                for pc in path.pathclasses:
                    name = pc.identifier
                    # name = f"{path.path_id}{pc.identifier}"
                    # name = f"{path.get_leg_fltno(0)}-{path.get_leg_fltno(1) if path.num_legs() > 1 else 0}{pc.identifier}"
                    self.lp_vars[name].SetUb(pc.fcst_mean)

        # Create capacity constraints
        for leg in sim.legs:
            if leg.carrier != self.carrier:
                continue
            self.constraints[leg.flt_no].SetUb(leg.capacity - leg.sold)

    def solve(self, sim: SimulationEngine):
        result_status = self.solver.Solve()
        # The bid prices are the dual values of the capacity constraints
        for leg in sim.legs:
            if leg.carrier != self.carrier:
                continue
            # The duals of the constraints are the displacement costs.
            # In theory, they should be non-negative by construction, but we
            # enforce that here because the solver can sometimes return tiny
            # negative values due to numerical imprecision.
            leg.displacement = max(self.constraints[leg.flt_no].dual_value(), 0)
            leg.bid_price = leg.displacement
            # print(f"Leg: {leg}, bp={leg.bid_price}")


if __name__ == "__main__":
    print("Hello from LP")
