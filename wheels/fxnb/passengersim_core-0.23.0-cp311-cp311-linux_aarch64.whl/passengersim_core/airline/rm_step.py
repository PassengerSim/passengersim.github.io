#
# A step in the RM system
#  - Untruncation / Forecasting / Adjustments / Optimization / etc.
#  - This is the abstract base class, each component will inherit from this
#  - It defines the means to link the processing steps and check they fit together
#
# The lists for "requires" and "produces" allow the driver to check that the flow is correct
#  - If forecasting produces "leg_forecast" but optimization requires "path_forecast"
#    then an exception will be thrown
#
# Alan W, Mathstream LLC, January 2023
#

from abc import abstractmethod, ABC


class RmStep:
    def __init__(self):
        self.name = "None"
        self.requires = []
        self.produces = []
        self.debug_filters = []

    def __str__(self):
        return f"RM Step: {self.name}"

    @abstractmethod
    def add_parm(self, p1, p2):
        """Add a parameter to this step.  Designed to be used by the file loader
            and takes a list of strings"""
        pass

    @abstractmethod
    def run(self, sim, _airline, _dcp_index, _days_prior, _debug=False):
        pass


