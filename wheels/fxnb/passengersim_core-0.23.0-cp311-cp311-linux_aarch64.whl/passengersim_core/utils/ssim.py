#
# Code for manipulating IATA SSIM (schedule) files
# Uses the Ch.7 format.
# For now, just limited to reading SSIM data
# I might rewrite this into C++ in the future, for performance...
#
# Alan W, Mathstream LLC, December 2022
#

from datetime import datetime
import math
from time import time


# We have a dictionary of variables to place, this lets me reuse it for both reading and writing
# I also have the column (byte) numbers that match the SSIM manual exactly, then convert them
# to the correct offsets for Python string slicing

rec1_defs = [
    ("record_number", 1, 1),
    ("title", 1, 34),
    ("record_serial_number", 195, 200)]

rec2_defs = [
    ("record_number", 1, 1),
    ("airline", 3, 5),
    ("season", 11, 13),
    ("period_start", 15, 21, "D"),
    ("period_end", 22, 28, "D"),
    ("creation_date", 29, 25, "D"),
    ("title", 36, 64),
    ("record_serial_number", 195, 200)]

rec3_defs = [
    ("record_number", 1, 1),
    ("airline", 3, 5),
    ("flight_number", 6, 9),
    ("variation", 10, 11),
    ("leg_sequence_number", 12, 13),
    ("service_type", 14, 14),
    ("period_start", 15, 21, "d"),
    ("period_end", 22, 28, "d"),
    ("days_of_operation", 29, 35),
    ("departure_station", 37, 39),
    ("passenger_std", 40, 43),
    ("aircraft_std", 44, 47),
    ("departure_utc_variation", 48, 52),
    ("departure_terminal", 53, 54),
    ("arrival_station", 55, 57),
    ("aircraft_sta", 58, 61),
    ("passenger_sta", 62, 65),
    ("arrival_utc_variation", 66, 70),
    ("arrival_terminal", 71, 72),
    ("aircraft_type", 73, 75),
    ("prbd", 76, 95),
    ("prbm", 96, 100),
    ("meal_service_note", 101, 110),
    ("joint_operation_designators", 111, 119),
    ("minimum_connecting_time_di", 120, 121),
    ("itinerary_variation_overflow", 128, 128),
    ("aircraft_owner", 129, 131),
    ("cockpit_crew_employer", 132, 134),
    ("cabin_crew_employer", 135, 137),
    ("onward_airline", 138, 140),
    ("onward_flight_number", 141, 144),
    ("onward_aircraft_rotation_layover", 145, 145),
    ("onward_operational_suffix", 146, 146),
    ("flight_transit_layover", 148, 148),
    ("operationg_airline_disclosure", 149, 149),
    ("traffic_restriction_code", 150, 160),
    ("traffic_restriction_code_overflow_indicator", 161, 161),
    ("aircraft_configuration", 173, 192),
    ("record_serial_number", 195, 200)]

rec4_defs = [
    ("record_number", 1, 1),
    ("airline", 3, 5),
    ("flight_number", 6, 9),
    ("variation", 10, 11),
    ("leg_sequence_number", 12, 13),
    ("service_type", 14, 14),
    ("itinerary_variation_overflow", 28, 28),
    ("board_point_indicator", 29, 29),
    ("off_point_indicator", 30, 30),
    ("data_element_identifier", 31, 33),
    ("board_point", 34, 37),
    ("off_point", 37, 39),
    ("data", 40, 194),
    ("record_serial_number", 195, 200)]

rec5_defs = [
    ("record_number", 1, 1),
    ("airline", 3, 5),
    ("release_date", 6, 12),
    ("record_serial_number", 195, 200)]

record_definitions = [rec1_defs, rec2_defs, rec3_defs, rec4_defs, rec5_defs]


# ######################################################################################################
# Some Data Element Identifiers (for the record 4 data)
#


class Dei:
    def __init__(self):
        self.number = 0  # Unknown


class DeiNotImplemented(Dei):
    """Not sure what's in the data, but this will hold it anyway..."""
    def __init__(self, _n):
        self.number = _n

    def from_text(self, z: str):
        self.data = z


class Dei10(Dei):
    """Duplicate Leg Cross-Reference
       Stores an array of tuples: (carrier, flight_number)"""
    def from_text(self, z: str):
        self.number = 10
        self.duplicate_legs = []
        for tmp in z.strip().split("/"):
            self.duplicate_legs.append((tmp[0:3], tmp[3:]))


class Dei50(Dei):
    """Operational Leg Identification"""
    def from_text(self, z: str):
        self.number = 50
        tmp = z.strip().split(" ")
        self.operational_carrier_code = tmp[0]
        self.operational_flight_number = tmp[1]


class Dei101(Dei):
    """PRBD Segment Override"""
    def from_text(self, z: str):
        self.number = 101
        self.overrride_data = z


class Dei102(Dei):
    """Passenger Reservations Booking Modifier Segment Override"""
    def from_text(self, z: str):
        self.number = 102
        self.overrride_data = z


class Dei107(Dei):
    """Passenger Reservations Booking Modifier Exceeding Maximum Length"""
    def from_text(self, z: str):
        self.number = 107
        self.prbm_data = []
        for tmp in z.split(" "):
            self.prbm_data.append(tmp.strip())


class Dei109(Dei):
    """Meal Service Exceeding Maximum Length"""
    def from_text(self, z: str):
        self.number = 109
        self.meal_codes = []
        num_fields = math.ceil(len(z.strip()) / 2.0)
        for i in range(num_fields):
            self.meal_codes.append(z[i*2 : i*2+1])


class Dei111(Dei):
    """Meal Service Segment Override"""
    def from_text(self, z: str):
        self.number = 111
        self.meal_overrides = []
        for code in z.split("/"):
            self.meal_overrides.append(code)


class Dei122(Dei):
    """Flight Number Override"""
    def from_text(self, z: str):
        self.number = 170
        self.flight_numbers = []
        for code in z.split(" "):
            self.flight_numbers.append(code)


class Dei125(Dei):
    """Joint Operation Airline Designators Segment Override"""
    def from_text(self, z: str):
        self.number = 170
        self.designators = []
        for code in z.split("/"):
            self.designators.append(code)


class Dei127(Dei):
    """Operating airline disclosure"""
    def from_text(self, z: str):
        self.number = 127
        tmp = z.split("/")
        if len(tmp) == 2:
            self.operating_airline_code = tmp[0]
            self.operating_airline_name = tmp[1]
        else:
            self.operating_airline_code = tmp[0]
            self.operating_airline_name = ""


class Dei170(Dei):
    """Traffic Restriction Code Applicable to Passengers only"""
    def from_text(self, z: str):
        self.number = 170
        self.data = z


class Dei171(Dei):
    """Traffic Restriction Code Applicable to Cargo/Mail only"""
    def from_text(self, z: str):
        self.number = 171
        self.data = z


class Dei172(Dei):
    """Traffic Restriction Code Applicable to Cargo only"""
    def from_text(self, z: str):
        self.number = 172
        self.data = z


class Dei173(Dei):
    """Traffic Restriction Code Applicable to Mail only"""
    def from_text(self, z: str):
        self.number = 173
        self.data = z.strip()


class Dei200(Dei):
    """???  Not sure!
       I've seen it in SSIM files, but it's not in the version of the manual I have"""
    def from_text(self, z: str):
        self.number = 101
        self.overrride_data = z


class Dei210(Dei):
    """Plane Change without Aircraft Type Change"""
    def from_text(self, z: str):
        self.number = 210
        self.data = z.strip()


class Dei301(Dei):
    """Flaglanding at board point only"""
    def from_text(self, z: str):
        self.number = 301
        self.data = None


class Dei302(Dei):
    """Flaglanding at off point only"""
    def from_text(self, z: str):
        self.number = 302
        self.data = None


class Dei303(Dei):
    """Flaglanding at off point and board point"""
    def from_text(self, z: str):
        self.number = 303
        self.data = None


class Dei501(Dei):
    """On-time Performance Indicator"""
    def from_text(self, z: str):
        tmp = z.split(" ")
        self.ontime_performance = z[0]
        self.calculated_month_year = z[1]
        # print(self.ontime_performance, self.calculated_month_year)


class Dei503(Dei):
    """Inflight Service Information"""
    def from_text(self, z: str):
        self.inflight_services = []
        for tmp_code in z.split("/"):
            self.inflight_services.append(int(tmp_code))

    def decode_service_code(self, code: int):
        if code in dei_service_codes:
            return dei_service_codes[code]
        else:
            return "???"


class Dei505(Dei):
    """Electronic ticketing information"""
    def from_text(self, z: str):
        self.number = 505
        self.electronic_ticketing_candidate = False if "EN" in z else True


class Dei800plus(Dei):
    """Free Format Bilateral Use"""
    def __init__(self, _n):
        self.number = _n

    def from_text(self, z: str):
        self.data = z.strip()


class Dei900plus(Dei):
    """Free Format Internal Use"""
    def __init__(self, _n):
        self.number = _n

    def from_text(self, z: str):
        self.data = z.strip()


dei_classes = {10: Dei10,
               50: Dei50,
               101: Dei101,
               102: Dei102,
               107: Dei107,
               109: Dei109,
               111: Dei111,
               122: Dei122,
               125: Dei125,
               127: Dei127,
               170: Dei170,
               171: Dei171,
               172: Dei172,
               173: Dei173,
               200: Dei200,
               210: Dei210,
               301: Dei301,
               302: Dei302,
               303: Dei303,
               501: Dei501,
               503: Dei503,
               505: Dei505}


dei_service_codes = {1: "Movie",
                        2: "Telephone",
                        3: "Telex",
                        4: "Audio programming",
                        5: "Television",
                        6: "Reservation booking service",
                        7: "Duty Free sales",
                        8: "Smoking",
                        9: "Non-smoking",
                        10: "Short Feature Video",
                        11: "No Duty Free sales",
                        12: "In-seat power source",
                        13: "Internet access",
                        14: "E-Mail",
                        15: "In-seat Video Player/Library",
                        16: "Lie-flat Seat",
                        17: "Additional Services",
                        18: "Wi-Fi"}


# ######################################################################################################
# And now the code !!!
#
def dateFromSsim(str_date: str):
    if str_date == "00XXX00" or str_date.strip() == "":
        return None
    try:
        d = datetime.strptime(str_date, "%d%b%y")
        return d
    except ValueError:
        print(str_date, " is a bad date")
        exit()


class SsimRecord:
    def from_text(self, rec_str: str):
        for fd in record_definitions[int(self.record_number) - 1]:
            name = fd[0]
            start = int(fd[1] - 1)
            end = int(fd[2])
            z = rec_str[start : end]
            if len(fd) > 3 and fd[3] == "D":
                z = dateFromSsim(z)
            self.__setattr__(name, z)

        if int(self.record_number) == 4:
            self.data = self.parse_dei()

    def output_record(self):
        """Output a 200 byte SSIM record, in ASCII format"""
        rec = bytearray(" "*200, "ascii")
        for fd in record_definitions[int(self.record_number) - 1]:
            name = fd[0]
            start = int(fd[1] - 1)
            end = int(fd[2])
            if name in self.__dict__:
                z = self.__getattribute__(name)
                tmp_z = bytearray(z, 'ascii')
                rec[start : end] = tmp_z
        return rec.decode()

    def parse_dei(self):
        if self.data_element_identifier.isnumeric():
            dei_number = int(self.data_element_identifier)
        else:
            return None

        if dei_number in dei_classes:
            dei = dei_classes[dei_number]()
            dei.from_text(self.data)
            return dei
        elif 800 <= dei_number <= 899:
            dei = Dei800plus(dei_number)
            dei.from_text(self.data)
        elif 900 <= dei_number <= 999:
            dei = Dei900plus(dei_number)
            dei.from_text(self.data)
        else:
            print("Unknown DEI", dei_number)
            print("Data = ", self.data)
            dei = DeiNotImplemented(dei_number)
        return dei


class SsimRecord1(SsimRecord):
    def __init__(self):
        self.record_number = 1


class SsimRecord2(SsimRecord):
    def __init__(self):
        self.record_number = 2


class SsimRecord3(SsimRecord):
    def __init__(self):
        self.record_number = 3


class SsimRecord4(SsimRecord):
    def __init__(self):
        self.record_number = 4


class SsimRecord5(SsimRecord):
    def __init__(self):
        self.record_number = 5


def read_ssim(file_name: str, records: list=[1,2,3,4,5]):
    """
    Generator that reads through the specified SSIM file and returns requested record types.
    If we only want record 3 for some analyses, then we can have just that.
    A generator lets us process the entire file with loading it all into memory, it just
    returns one record at a time
    :param file_name: SSIM Chapter 7 file
    :param records: List of record numbers to return
    :return:
    """
    for line in open(file_name, "r"):
        line = line.strip(" \n")
        if len(line) == 0 or line[0] == "#":
            continue
        if line[0] == "1" and int(line[0]) in records:
            rec = SsimRecord1()
            rec.from_text(line)
            yield rec
        elif line[0] == "2" and int(line[0]) in records:
            rec = SsimRecord2()
            rec.from_text(line)
            yield rec
        elif line[0] == "3" and int(line[0]) in records:
            rec = SsimRecord3()
            rec.from_text(line)
            yield rec
        elif line[0] == "4" and int(line[0]) in records:
            rec = SsimRecord4()
            rec.from_text(line)
            yield rec
        elif line[0] == "5" and int(line[0]) in records:
            rec = SsimRecord5()
            rec.from_text(line)
            yield rec


if __name__ == "__main__":
    start_time = time()
    airlines = ["AA", "DL", "UA", "HA", "B6", "AS", "NK", "F9", "G4", "WN"]
    n = 0
    for rec in read_ssim("/Users/alanw/tmp/ssim.14feb2000.txt", [3]):
        if rec.airline.strip() not in airlines:
            continue
        if n % 100 == 0:
            print("n = ", n, rec.airline, rec.flight_number)
        n += 1
    print(f"Record count = {n}, Elapsed time = {round(time() - start_time, 3)}")

