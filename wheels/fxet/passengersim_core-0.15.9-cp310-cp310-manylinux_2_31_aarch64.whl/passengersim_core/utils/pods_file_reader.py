#
# Read (some of) the PODS input (.NWK and .IN files)
# - Just enough of the legs / demand / fares data to compare results
#
# Alan W, Mathstream LLC, January 2023
#

from airsim_utils import decimal_time_to_ts, ts_to_time, parse_array
from passengersim_core import SimulationEngine, BookingCurve, Demand, Fare, Leg, Path
from collections import defaultdict


class FareProduct:
    def __init__(self, _airline, _name):
        self.airline = _airline
        self.name = _name
        self.adv_purch = {}
        self.cancel_penalty = {}
        self.restrictions = {}


class PodsReader:
    """Read in (some of) the PODS files, mostly to get the network data for testing
       The PODS input is very FORTRAN-esque, so the IN file specifies the number
       of rows of various items in the NWK file.  Easy to trip if the files don't agree"""

    def __init__(self, _sim, _base_date=0):
        self.market_k_factor = None
        self.num_airlines = None
        self.dcps = []
        self.title = None
        self.system_k_factor = None
        self.sim = _sim
        self.base_date = _base_date
        self.booking_curve_index = {}
        self.choice_model_index = {}
        self.dmd_index = {}
        self.leg_index = {}
        self.fares = []
        self.fare_products = {}
        self.non_stops_by_airline = defaultdict(int)
        self.connections_by_airline = defaultdict(int)

    def get_next_line(self, file):
        """Get the next line that's not blank and not a comment"""
        while True:
            line = file.readline()
            print("Line = ", line)
            if line[0] != "!" and len(line.strip()) > 0:
                break
        return line

    def read(self, network_file_name="", in_file_name="", debug=False):
        input_file = open(in_file_name, "r")
        self.read_infile(input_file, debug)
        network_file = open(network_file_name, "r")
        self.read_network_file(network_file, debug)
        network_file.close()
        input_file.close()

    def read_infile(self, input_file, debug=True):
        # IN file data
        self.title = input_file.readline().strip()
        print("Title =", self.title)
        self.parse_case_info(input_file.readline())
        self.parse_factors(self.get_next_line(input_file))
        print_control_line = self.get_next_line(input_file)
        pax_choice_line = self.get_next_line(input_file)
        for i in range(self.num_pax_types):
            seasonality_line = self.get_next_line(input_file)
        trend_slope_line = self.get_next_line(input_file)
        self.dcps = parse_array(self.get_next_line(input_file), cast_int=True)
        for i in range(self.num_pax_types):
            tmp = self.get_next_line(input_file)
            emult_line = self.get_next_line(input_file)
            tmp = self.get_next_line(input_file)
            tmp = self.get_next_line(input_file)
            tmp = self.get_next_line(input_file)
            for j in range(self.num_restrictions):
                restriction_line = self.get_next_line(input_file)
            for j in range(self.num_add_ons):
                add_on = self.get_next_line(input_file)

        for i in range(self.num_booking_curves):
            self.add_booking_curve(i, self.get_next_line(input_file))

        # Cancellation probs
        for i in range(self.num_booking_curves):
            for j in [0, 1]:
                cancel_info_line = self.get_next_line(input_file)

        for a in range(self.num_airlines):
            num_product_sets = int(self.get_next_line(input_file))
            for n in range(num_product_sets):
                airline = "AL"+str(a+1)
                product_set = "PS"+str(n+1)
                p = FareProduct(airline, product_set)
                self.fare_products[airline + product_set] = p
                # print("Created product set ", airline+product_set)
                for f in range(self.num_fare_classes):
                    product_line = self.get_next_line(input_file)
                    z = parse_array(product_line, cast_int=True)
                    # z = product_line.split()
                    last_tf = int(z[0])
                    last_dcp = self.dcps[last_tf] if last_tf < len(self.dcps) else 0
                    cancel_penalty = z[1]
                    restrictions = z[2:2+self.num_restrictions]
                    # add_on = z[-1]
                    fare_class = "Y" + str(f)
                    p.adv_purch[fare_class] = last_dcp
                    p.cancel_penalty[fare_class] = cancel_penalty
                    p.restrictions[fare_class] = restrictions


    def read_network_file(self, network_file, debug=False):
        # NWK file data
        for i in range(self.num_legs):
            line = self.get_next_line(network_file)
            leg = self.parse_leg(line)
            leg.flt_no = i+1  # PODS uses array indices to lookup and link data together
            self.sim.add_leg(leg)
            self.leg_index[leg.flt_no] = leg
            if debug:
                print(leg)

        for i in range(self.num_markets):
            mkt_line = self.get_next_line(network_file)
            z = mkt_line.split()
            tmp = z[0].split("-")
            mkt_orig, mkt_dest = tmp[0], tmp[1]
            num_paths = int(z[3])
            dmd_b = Demand(mkt_orig, mkt_dest, "business")
            self.sim.add_demand(dmd_b)
            dmd_l = Demand(mkt_orig, mkt_dest, "leisure")
            self.sim.add_demand(dmd_l)
            self.dmd_index[i] = dmd_b
            if debug:
                print(f"Market {mkt_orig}-{mkt_dest}, num_paths={num_paths}")

            base_fare_line = self.get_next_line(network_file)
            z = base_fare_line.split()
            dmd_b.reference_fare = float(z[0])
            dmd_l.reference_fare = float(z[1])

            use_product_set = []
            for j in range(self.num_airlines):
                product_set_line = self.get_next_line(network_file)
                # print("Product set =", product_set_line)
                use_product_set.append(int(product_set_line))

            _ = self.get_next_line(network_file)

            #for j in range(self.num_pax_types):
            #    dwm_line = self.get_next_line(network_file)
                # print("dwm_line =", dwm_line)

            dmd_line = self.get_next_line(network_file)
            z = dmd_line.split()
            # print("dmd_line =", dmd_line)
            dmd_b.base_demand = float(z[0])
            dmd_l.base_demand = float(z[1])

            booking_curve_line = self.get_next_line(network_file)
            # print("booking_curve_line =", booking_curve_line)
            z = parse_array(booking_curve_line, cast_int=True)
            dmd_b.curve_number = z[0]
            dmd_l.curve_number = z[1]

            for j in range(self.num_airlines):
                pref_fares_line = self.get_next_line(network_file)
                # print("pref_fares_line = ", pref_fares_line)
                self.parse_fares(pref_fares_line,
                                 mkt_orig, mkt_dest, airline=j, product_set=use_product_set[j])

            for p in range(num_paths):
                for a in range(self.num_airlines):
                    self.parse_decision_fares(self.get_next_line(network_file),
                                              mkt_orig, mkt_dest, airline=a)

            for p in range(num_paths):
                path = self.parse_path(self.get_next_line(network_file), mkt_orig, mkt_dest)
                self.sim.add_path(path)
                # dmd_b.add_path(path)
                # dmd_l.add_path(path)

    def parse_factors(self, data):
        z = parse_array(data)
        self.system_k_factor = z[0]
        self.market_k_factor = z[1]
        self.pax_type_k_factor = z[2]
        self.attributed_cost_k_factor = z[3]
        self.attributed_airline_k_factor = z[4]
        self.addon_disutility_k_factor = z[5]
        self.pos_multiplier1 = z[6]
        self.pos_multiplier2 = z[7]

    def parse_case_info(self, data, debug=True):
        """This is the second line of the input"""
        z = parse_array(data, cast_int=True)
        self.num_airlines = z[0]
        self.num_legs = z[1]
        self.num_markets = z[2]
        self.num_pax_types = z[3]
        self.num_fare_classes = z[4]
        self.num_restrictions = z[5]
        self.num_add_ons = z[6]
        self.num_booking_curves = z[7]
        self.num_timeframes = z[8]
        self.nobs_rm_fcst = z[9]
        self.nobs_burn = z[10]
        self.num_samples = z[11]
        self.num_trials = z[12]
        self.trip_purpose = z[13]
        if debug:
            print(f"Case: num_al={self.num_airlines}. num_leg={self.num_legs}, num_markets={self.num_markets}")

    def add_booking_curve(self, i, data):
        z = parse_array(data)
        self.booking_curve_index[i+1] = z
        bc = BookingCurve(str(i))
        for _dcp, _pct in zip(self.dcps, z):
            bc.add_dcp(int(_dcp), float(_pct))

    def parse_leg(self, data):
        z = data.split()
        city_pair = z[0]
        tmp = city_pair.split("-")
        orig = tmp[0]
        dest = tmp[1]
        carrier = "AL" + z[1]
        coach_cap = int(float(z[2]))
        distance = float(z[4])
        bank = z[6]
        if len(z) > 7:
            snapshot = z[7]
        leg = Leg(carrier, 0, orig, dest, capacity=coach_cap)
        leg.distance=distance
        return leg

    def parse_fares(self, data, mkt_orig, mkt_dest, airline, product_set, debug=True):
        # print("Fare line =", data)
        classes = ["Y0", "Y1", "Y2", "Y3", "Y4", "Y5", "Y6", "Y7", "Y8", "Y9"]
        z = parse_array(data)
        z_fares = z[1:]
        for price, fare_class in zip(z_fares, classes):
            carrier = f"AL{airline+1}"
            fare = Fare(carrier, mkt_orig, mkt_dest, fare_class, price)
            self.fares.append(fare)
            # Get the fare product
            key = f"{carrier}PS{product_set}"
            ps = self.fare_products[key]
            fare.adv_purch = ps.adv_purch[fare.booking_class]
            for flag, code in zip(ps.restrictions[fare.booking_class], ["R1", "R2", "R3", "R4"]):
                if flag > 0:
                    fare.add_restriction(code)
            #if debug:
            #    print(fare)

    def parse_decision_fares(self, data, mkt_orig, mkt_dest, airline, debug=True):
        pass
        # print("Decision fares line =", data)

    def parse_path(self, data, _mkt_orig, _mkt_dest):
        # print("Path line = ", data)
        path = Path(_mkt_orig, _mkt_dest)
        z = data.split()
        path_dep = decimal_time_to_ts(z[0])
        path_arr = decimal_time_to_ts(z[1])
        airline_id = "AL" + (z[2]).strip()
        path_quality = float(z[3])
        path.path_quality_index = path_quality
        num_legs_in_path = int(z[4])

        if int(path_quality) != int(num_legs_in_path):
            print("PQI stuff", path_quality, num_legs_in_path)

        for i in range(num_legs_in_path):
            leg_id = int(z[5+i])
            tmp_leg = self.leg_index[leg_id]
            if tmp_leg.carrier != airline_id:
                print("Oops")
            path.add_leg(tmp_leg)
            if num_legs_in_path == 1:
                # Set the departure and arrival times of the leg, just to make it pretty
                tmp_leg.dep_time = path_dep
                tmp_leg.arr_time = path_arr

        if num_legs_in_path == 1:
            self.non_stops_by_airline[airline_id] += 1
        else:
            self.connections_by_airline[airline_id] += 1

        #estimation_category = z[5+num_legs_in_path]
        #path_purpose = z[6+num_legs_in_path]
        return path

    def print_summary(self):
        """Just to see that everything is loading OK"""
        print(sim)
        print("##### Legs:")
        for leg in sim.legs:
            dep = ts_to_time(leg.dep_time)
            arr = ts_to_time(leg.arr_time)
            print(f"    {leg}, {dep}-{arr}")
        print("##### Demands:")
        for dmd in sim.demands:
            print(f"    {dmd}, ref_fare=${dmd.reference_fare:.0f}, dmd={dmd.base_demand}")

    def print_airsim_format(self, out_file_name):
        of = open(out_file_name, "w")

        print("# Sample PassengerSim input file", file=of)
        print(f"SCENARIO,{sim.name}", file=of)
        print("", file=of)

        self.output_sim_parms(of)
        print(file=of)
        self.output_choice_models(of)

        print("", file=of)
        print("SYSTEM,rm_test1", file=of)
        print("RM_STEP,untruncation,em", file=of)
        print("RM_STEP,forecast,exp_smoothing,0.15", file=of)
        print("RM_STEP,optimization,emsrb", file=of)

        print("", file=of)
        print("AIRLINE,AL1,rm_test1", file=of)
        print("AIRLINE,AL2,rm_test1", file=of)
        print("AIRLINE,AL3,rm_test1", file=of)
        print("AIRLINE,AL4,rm_test1", file=of)

        print(file=of)
        c = ",".join([f"Y{i}" for i in range(self.num_fare_classes)])
        print("CLASSES," + c, file=of)

        print(file=of)
        tmp = ",".join([str(i) for i in self.dcps])
        print("DCPS," + tmp, file=of)

        print("", file=of)
        for k, v in self.booking_curve_index.items():
            v = [str(x) for x in v]
            tmp = ",".join(v)
            print(f"CURVE,{k},{tmp}", file=of)

        print("", file=of)
        for leg in sim.legs:
            dep = ts_to_time(leg.dep_time)
            arr = ts_to_time(leg.arr_time)
            cap = int(leg.capacity)
            distance = leg.distance
            print(f"LEG,{leg.carrier},{leg.flt_no},{leg.orig},{leg.dest},{dep},{arr},{cap},{distance}", file=of)

        print("", file=of)
        for dmd in sim.demands:
            cm = dmd.segment
            bcn = dmd.curve_number
            print(f"DMD,{dmd.orig},{dmd.dest},{dmd.segment},{dmd.base_demand},{dmd.reference_fare},{cm},{bcn}", file=of)

        print("", file=of)
        for f in self.fares:
            rest = ",".join([f.get_restriction(pos) for pos in range(f.num_restrictions())])
            if len(rest) > 0:
                rest = "," + rest
            print(f"FARE,{f.carrier},{f.orig},{f.dest},{f.booking_class},{f.price:.2f},{f.adv_purch}{rest}", file=of)

        print("", file=of)
        for n, p in enumerate(sim.paths):
            flts = ["0", "0"]
            for i in range(p.num_legs()):
                flts[i] = str(p.get_leg_fltno(i))
            tmp = ",".join(flts)
            pqi = p.path_quality_index
            print(f"PATH,{n+1},{p.orig},{p.dest},{pqi},{tmp}", file=of)

    def output_sim_parms(self, of):
        tmp = """SIM,num_trials,1
SIM,num_samples,300
SIM,sys_k_factor,0.10
SIM,mkt_k_factor,0.20
SIM,pax_type_k_factor,0.40
SIM,tf_k_factor,0.1
SIM,tf_z_factor,2.0
SIM,prorate_revenue,1
SIM,dwm_lite,0
SIM,max_connect_time,120
SIM,disable_ap,0
SIM,demand_multiplier,1
SIM,manual_paths,1"""
        print(tmp, file=of)

    def output_choice_models(self, of):
        tmp = """# Choice model - name,type
#  - then named parameters are listed as - PARM,name,value(s)
CM,business,pods
PARM,emult,1.6
PARM,basefare_mult,2.5
PARM,path_quality, 38.30, 0.10
PARM,preferred_airline, -12.29, 0.17
PARM,tolerance,2.0
PARM,r1,0.30
PARM,r2,0.10
PARM,r3,0.20
PARM,r4,0.15

CM,leisure,pods
PARM,emult,1.5
PARM,basefare_mult,1.0
PARM,path_quality, 2.02, 0.12
PARM,preferred_airline, -1.98, 0.11
PARM,tolerance,5.0
PARM,r1,0.30
PARM,r2,0.15
PARM,r3,0.25
PARM,r4,0.20"""
        print(tmp, file=of)

    def print_summary_stats(self):
        for i in range(self.num_airlines):
            k = "AL" + str(i+1)
            print(f"{k},  NS = {self.non_stops_by_airline[k]:5},  CNX = {self.connections_by_airline[k]:5}")


if __name__ == "__main__":
    sim = SimulationEngine("Test PODS Reader")
    rdr = PodsReader(sim)
    rdr.read(network_file_name="passengersim-core/networks/W10GT.NWK",
             in_file_name="passengersim-core/networks/W10GTEEEE.IN")
    # rdr.print_summary()
    rdr.print_airsim_format(out_file_name="passengersim-core/networks/W10-converted.txt")
    rdr.print_summary_stats()

