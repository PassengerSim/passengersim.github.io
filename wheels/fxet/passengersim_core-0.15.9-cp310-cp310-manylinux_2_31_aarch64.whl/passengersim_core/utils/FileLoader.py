#
# Utilities for reading CSV input.
#
# Still in the experimental stage, just an example of how to do this
#
# Alan Walker, Mathstream LLC, June 2022
#

import time
from datetime import datetime

import yaml

import passengersim_core
import passengersim_core.airline.rm_dynamic_programming as dp
import passengersim_core.airline.rm_emsr as emsr
import passengersim_core.airline.rm_pro_bp as proBP
from passengersim_core import Airline, BookingCurve, Bucket, Demand, Fare, Leg, Path
from passengersim_core.airline.rm_forecast import ForecastStep
from passengersim_core.airline.rm_path_2_leg import AggregationStep
from passengersim_core.airline.rm_step import RmStep
from passengersim_core.airline.rm_system import Rm_System
from passengersim_core.airline.rm_untruncation import UntruncationStep
from passengersim_core.utils import airsim_utils
from passengersim_core.utils.airsim_exceptions import InputParseException
from passengersim_core.utils.SimDriver import SimDriver
from passengersim_core.utils.SnapshotFilter import SnapshotFilter
from passengersim_core import SimulationEngine


class FileLoader:
    def __init__(self, debug=False):
        self.last_component = None
        self.last_demand = None
        self.choice_models = {}
        self.airports = []
        self.classes = []
        self.fares = []
        self.legs = [
            0
        ]  # We want flt_no==1 to be in legs[1], so I put in a dummy element
        self.leg_index = {}
        self.dcps = [63, 56, 49, 42, 35, 31, 28, 24, 21, 17, 14, 10, 7, 5, 3, 1]
        self.curves = {}
        self.frat5_curves = {}
        self.rm_systems = {}
        self.debug = debug
        self.demand_multiplier = 1.0
        self.random_generator = passengersim_core.Generator(42)
        # Used to initialize RM controls at load time
        # self.init_rm = {"Y": 100, "B": 80, "M": 60, "H": 45, "Q": 30}
        self.buckets = ["Y0", "Y1", "Y2", "Y3", "Y4", "Y5", "Y6"]
        self.init_rm = {
            "Y0": 100,
            "Y1": 100,
            "Y2": 100,
            "Y3": 100,
            "Y4": 100,
            "Y5": 100,
            "Y6": 100,
        }

    def load_network(
        self,
        driver: SimDriver,
        file_name: str,
        base_date: datetime = None,
        offset: int = 0,
    ):
        sim = driver.sim
        with open(file_name) as input_file:
            for line in input_file:
                line = line.strip(" \n")
                if len(line) == 0 or line[0] == "#":
                    continue
                z = line.split(",")

                cmd = z[0].upper()
                if cmd == "AIRLINE":
                    a = Airline(z[1], z[2])
                    rm_system = self.rm_systems[z[3]]
                    a.rm_system = rm_system
                    sim.add_airline(a)
                elif cmd == "CURVE" or cmd == "BKG_CURVE":
                    name = str(z[1]).strip()
                    curve = airsim_utils.parse_array(z[2:])
                    bc = BookingCurve(name)
                    self.curves[name] = bc
                    for _dcp, _pct in zip(self.dcps, curve):
                        bc.add_dcp(int(_dcp), float(_pct))
                elif cmd == "CLASSES":
                    self.add_classes(sim, z)
                elif cmd == "CM":
                    self.last_component = self.add_choice_model(sim, z)
                elif cmd == "DCPS":
                    self.dcps = airsim_utils.parse_array(z[1:])
                elif cmd == "DMD":
                    self.last_demand = self.add_demand(sim, z)
                elif cmd == "FARE":
                    self.add_fare(sim, z)
                elif cmd == "FILTER":  # TODO
                    SnapshotFilter.add_filter(z)
                elif cmd == "GROUP_SIZE":
                    self.add_group_size(z)
                elif cmd == "LEG":
                    self.add_leg(sim, z, base_date, offset)
                elif cmd == "PARM":
                    self.add_parm(z)
                elif cmd == "PATH":
                    self.add_path(sim, z)
                elif cmd == "RM_STEP":
                    self.add_rm_step(z)
                elif cmd == "SCENARIO":
                    sim.name = z[1]
                elif cmd == "SIM":
                    if z[1] == "demand_multiplier":
                        self.demand_multiplier = float(z[2])
                    else:
                        sim.set_parm(z[1], float(z[2]))
                elif cmd == "SNAPSHOT":
                    self.add_snapshot_filter(z)
                elif cmd == "SYSTEM":
                    sys = Rm_System(z[1])
                    self.rm_systems[z[1]] = sys
                    self.last_component = sys
                elif cmd == "VERSION":
                    version = float(z[1])
                    if version < 2:
                        raise Exception("Incompatible input file version")
                else:
                    raise Exception(f"Unkown input statement: {cmd}")
        input_file.close()
        self.join_stuff_together(sim)

    def dump_network(self, driver: SimDriver, file_name: str) -> dict:
        sim = driver.sim
        x = {}
        x["scenario"] = sim.name
        x["simulation_controls"] = {
            "num_trials": sim.num_trials,
            "num_samples": sim.num_samples,
            "sys_k_factor": sim.sys_k_factor,
            "mkt_k_factor": sim.mkt_k_factor,
            "pax_type_k_factor": sim.pax_type_k_factor,
            "tf_k_factor": sim.tf_k_factor,
            "tf_z_factor": sim.tf_z_factor,
            "prorate_revenue": sim.prorate_revenue,
            "dwm_lite": sim.dwm_lite,
            "max_connect_time": sim.max_connect_time,
            "disable_ap": sim.disable_ap,
            "demand_multiplier": self.demand_multiplier,
            "manual_paths": sim.manual_paths,
        }

        rm_system_list = []
        for rs_name, rs in self.rm_systems.items():
            rm_system_list.append(
                {
                    "name": rs_name,
                    "steps": [step.serialize() for step in rs.steps],
                }
            )
        x["rm_systems"] = rm_system_list

        # choice_models: not implemented...
        cm_dict = {}
        for modelname, choicemodel in self.choice_models.items():
            cm_dict[modelname] = choicemodel.serialize()
        x["choice_models"] = cm_dict

        airline_list = []
        for a in sim.airlines:
            airline_list.append(
                {
                    "name": a.name,
                    "rm_system": a.rm_system.name,
                }
            )
        x["airlines"] = airline_list

        x["classes"] = self.classes
        x["dcps"] = [int(i) for i in self.dcps]

        curve_list = []
        for curve_name, c in self.curves.items():
            curve_list.append(
                {
                    "name": curve_name,
                    "curve": c.get_curve(),
                }
            )
        x["booking_curves"] = curve_list

        leg_list = []
        for leg in sim.legs:
            leg_list.append(
                {
                    "carrier": leg.carrier,
                    "fltno": leg.flt_no,
                    "orig": leg.orig,
                    "dest": leg.dest,
                    "date": time.strftime("%Y-%m-%d", time.localtime(leg.dep_time)),
                    "dep_time": time.strftime("%H:%M", time.localtime(leg.dep_time)),
                    "arr_time": time.strftime("%H:%M", time.localtime(leg.arr_time)),
                    "capacity": int(leg.capacity),
                    "distance": leg.distance,
                }
            )
        x["legs"] = leg_list

        demand_list = []
        for demand in sim.demands:
            demand_list.append(
                {
                    "orig": demand.orig,
                    "dest": demand.dest,
                    "segment": demand.segment,
                    "base_demand": demand.base_demand,
                    "reference_fare": demand.reference_fare,
                    "choice_model": demand.get_choice_model_name(),
                    "curve": demand.curve_number,
                }
            )
        x["demands"] = demand_list

        fare_list = []
        for fare in self.fares:
            fare_list.append(
                {
                    "carrier": fare.carrier,
                    "orig": fare.orig,
                    "dest": fare.dest,
                    "booking_class": fare.booking_class,
                    "price": fare.price,
                    "advance_purchase": fare.adv_purch,
                    "restrictions": [
                        fare.get_restriction(i) for i in range(fare.num_restrictions())
                    ],
                }
            )
        x["fares"] = fare_list

        path_list = []
        for p in sim.paths:
            path_list.append(
                {
                    "orig": p.orig,
                    "dest": p.dest,
                    "path_quality_index": p.path_quality_index,
                    "legs": [p.get_leg_fltno(i) for i in range(p.num_legs())],
                }
            )
        if path_list:
            x["paths"] = path_list

        snaps = []
        snapshot_filters = sim.snapshot_filters or SnapshotFilter.filters
        for sf in snapshot_filters:
            snaps.append(
                dict(
                    type=sf.type,
                    title=sf.title,
                    airline=sf.airline,
                    sample=sf.sample,
                    dcp=sf.dcp,
                    orig=sf.orig,
                    dest=sf.dest,
                    flt_no=sf.flt_no,
                )
            )
        if snaps:
            x["snapshot_filters"] = snaps

        if file_name:
            with open(file_name, "w") as f:
                yaml.safe_dump(x, f, sort_keys=False)
        return x

    def join_stuff_together(self, sim):
        """Go through and make sure things are linked correctly
        This allows the user to put stuf in almost any order"""
        for dmd in sim.demands:
            for fare in self.fares:
                if fare.orig == dmd.orig and fare.dest == dmd.dest:
                    # print("Joining:", dmd, fare)
                    dmd.add_fare(fare)

        for leg in sim.legs:
            for fare in self.fares:
                if (
                    fare.carrier == leg.carrier
                    and fare.orig == leg.orig
                    and fare.dest == leg.dest
                ):
                    leg.set_bucket_decision_fare(fare.booking_class, fare.price)
                    leg.set_bucket_fcst_revenue(fare.booking_class, fare.price)

    def add_choice_model(self, sim, z):
        if len(z) < 3:
            raise InputParseException("Insufficient arguments for Choice Model")
        model_name = z[1]
        model_type = z[2]
        self.last_component = passengersim_core.ChoiceModel(model_name, model_type)
        self.last_component.random_generator = self.random_generator
        self.choice_models[model_name] = self.last_component
        return self.last_component

    def add_parm(self, z):
        if len(z) < 3:
            raise InputParseException("Insufficient arguments for Parm")
        if self.last_component is None:
            raise Exception("Parameter specified, but no component to add it to")
        self.last_component.add_parm(z[1], float(z[2]))
        return self.last_component

    def add_path(self, sim, z):
        if len(z) < 5:
            raise InputParseException("Insufficient arguments for Path")
        orig = z[2]
        dest = z[3]
        p = Path(orig, dest, 0.0)
        pqi = float(z[4])
        p.path_quality_index = pqi
        leg_index1 = int(z[5])
        tmp_leg = self.legs[leg_index1]
        assert tmp_leg.orig == orig, "Path statement is corrupted, orig doesn't match"
        assert tmp_leg.flt_no == leg_index1
        p.add_leg(tmp_leg)
        if len(z) >= 7:
            leg_index2 = int(z[6])
            if leg_index2 > 0:
                tmp_leg = self.legs[leg_index2]
                p.add_leg(self.legs[leg_index2])
        assert tmp_leg.dest == dest, "Path statement is corrupted, dest doesn't match"

        sim.add_path(p)
        return self.last_component

    # Market demands - DMD,orig,dest,segment,demand,choice_model
    def add_demand(self, sim, z):
        if len(z) < 7:
            raise InputParseException("Insufficient arguments for Demand")
        orig, dest, segment = z[1], z[2], z[3]
        dmd = Demand(orig, dest, segment)
        dmd.base_demand = float(z[4]) * self.demand_multiplier
        dmd.price = float(z[5])
        dmd.reference_fare = dmd.price

        if len(self.airports) > 0:
            dmd.distance = self.get_mileage(dmd.orig, dmd.dest)

        model_name = z[6]
        cm = self.choice_models.get(model_name, None)
        if cm is not None:
            dmd.add_choice_model(cm)
        if model_name == "business" or segment == "business":
            dmd.business = True

        if len(z) >= 8:
            curve_name = str(z[7]).strip()
            curve = self.curves[curve_name]
            dmd.add_curve(curve)
            dmd.curve_number = int(z[7])

        sim.add_demand(dmd)
        self.last_demand = dmd
        if self.debug:
            print(f"Added demand: {dmd}, base_demand = {dmd.base_demand}")
        return dmd

    # Group size - GROUP_SIZE,n1,n2,...
    def add_group_size(self, z: list):
        if len(z) < 2:
            raise InputParseException("Insufficient arguments for Group Size(s)")
        if self.last_demand is not None:
            group_size = [float(tmp) for tmp in z[1:]]
            self.last_demand.add_group_sizes(group_size)

    # Fares - FARE,carrier,orig,dest,bkg_class,price,adv_purch,restrictions...
    def add_fare(self, sim, z):
        if len(z) < 6:
            raise InputParseException("Insufficient arguments for Fare")
        price = float(z[5])
        fare = Fare(z[1], z[2], z[3], z[4], price)

        if len(z) >= 7:
            adv_purch = int(z[6])
            fare.adv_purch = adv_purch

        for rest_code in z[7:]:
            fare.add_restriction(rest_code)

        self.fares.append(fare)
        sim.add_fare(fare)
        if self.debug:
            print(f"Added fare: {fare}")
        return fare

    # Flight legs - LEG,carrier,fltno,orig,dest,dep_time,capacity
    def add_leg(self, sim: SimulationEngine, z, base_date=None, offset=0):
        if len(z) < 5:
            raise InputParseException("Insufficient arguments for Leg")
        if base_date is None:
            base_date = datetime.fromisoformat("2022-09-21")
        dep_time = airsim_utils.ts_from_hhmm(z[5], base_date, offset)
        arr_time = airsim_utils.ts_from_hhmm(z[6], base_date, offset)
        carrier, fltno, orig, dest = z[1], int(z[2]), z[3], z[4]
        leg = Leg(carrier, fltno, orig, dest, capacity=int(z[7]))
        leg.dep_time = dep_time
        leg.arr_time = arr_time
        sim.add_leg(leg)
        if len(z) >= 9:
            leg.distance = float(z[8])
        elif len(self.airports) > 0:
            leg.distance = self.get_mileage(leg.orig, leg.dest)
        if len(self.classes) > 0:
            self.set_classes(leg)
        if self.debug:
            print(f"Added leg: {leg}, dist = {leg.distance}")
        self.legs.append(leg)
        return leg

    def add_classes(self, sim, z):
        self.classes = [c.strip() for c in z[1:]]

    def add_rm_step(self, z):
        if not isinstance(self.last_component, Rm_System):
            raise Exception("Must add RM_STEP after declaring a SYSTEM")
        if z[1] == "untruncation":
            type = "leg"
            if len(z) >= 4 and z[3] == "path":
                type = "path"
            step = UntruncationStep(name=z[1], algorithm=z[2], kind=type)
        elif z[1] == "forecast":
            step = ForecastStep(name=z[1], algorithm=z[2])
            # Quick hack
            if len(z) >= 4 and z[1] == "exp_smoothing":
                step.alpha = float(z[4])
        elif z[1] == "path_forecast":
            step = ForecastStep(name=z[1], algorithm=z[2], kind="path")
            # Quick hack
        elif z[1] == "aggregate":
            step = AggregationStep(_name=z[1], _algorithm="")
            # Quick hack
        elif z[1] == "optimization" and z[2] in ["fcfs", "emsra", "emsrb"]:
            step = emsr.EmsrStep(step_type="emsr", name=z[1], algorithm=z[2])
        elif z[1] == "optimization" and z[2] == "dp":
            step = dp.DynamicProgramStep(_name=z[1], _algorithm=z[2])
        elif z[1] == "optimization" and z[2] == "proBP":
            step = proBP.ProBpStep(step_type="probp", name=z[1])
        else:
            step = RmStep()
        self.last_component.add_step(step)

    def get_mileage(self, orig, dest):
        a1 = self.airports[orig]
        a2 = self.airports[dest]
        dist = airsim_utils.great_circle(
            a1.latitude, a1.longitude, a2.latitude, a2.longitude
        )
        return dist

    # Flight legs - LEG,carrier,fltno,orig,dest,dep_time,capacity
    def add_snapshot_filter(self, z):
        _sf = SnapshotFilter(_type=z[1], _name=z[2], _title=z[3])

    def set_classes(self, _leg, debug=False):
        cap = float(_leg.capacity)
        if debug:
            print(_leg, "Capacity = ", cap)
        for bkg_class in self.classes:
            # Input as a percentage
            auth = int(cap * self.init_rm.get(bkg_class, 100.0) / 100.0)
            b = Bucket(bkg_class, alloc=auth)
            # print("adding bucket_number", b)
            _leg.add_bucket(b)
            if debug:
                print("    Bucket", bkg_class, auth)


if __name__ == "__main__":
    sim = passengersim_core.SimulationEngine("Loader test")
    fl = FileLoader(debug=True)
    file_name = "/Users/alanw/projects/air-sim/networks/network-3mkt-pods.txt"
    fl.load_network(sim, file_name)
