#
# Utilities for writing PassengerSim data
# - Write data to CSV
#
# Alan Walker, Mathstream LLC, March 2023
#

import os
from datetime import datetime
import string

from passengersim_core import Bucket, Leg

def compute_rrd(sim, dep_time):
    tmp = int(dep_time / 86400) * 86400
    rrd = int((tmp - sim.last_event_time) / 86400)
    if sim.num_events() == 0:
        rrd = 0
    return rrd


class FileWriter:
    def __init__(self, out_dir):
        os.makedirs(out_dir, exist_ok=True)
        self.leg_file = open(os.path.join(out_dir, "_legs.csv"), "w")
        self.bkt_file = open(os.path.join(out_dir, "_buckets.csv"), "w")
        self.dmd_file = open(os.path.join(out_dir, "_demands.csv"), "w")
        self.fare_file = open(os.path.join(out_dir, "_fares.csv"), "w")
        self.write_headers()

    def __del__(self):
        self.leg_file.close()
        self.bkt_file.close()
        self.dmd_file.close()
        self.fare_file.close()

    def write_headers(self):
        self.leg_file.write("scenario, iteration, trial, sample, rrd, carrier, orig, dest, flt_no, dep_date, capacity, sold, revenue\n")
        self.bkt_file.write("scenario, iteration, trial, sample, rrd, carrier, orig, dest, flt_no, dep_date, bucket_number, name, auth, revenue, sold\n")
        self.dmd_file.write("scenario, iteration, trial, sample, rrd, orig, dest, segment, sample_demand, sold, revenue\n")
        self.fare_file.write("scenario, iteration, trial, sample, rrd, carrier, orig, dest, booking_class, sold, sold_business, price\n")

    # Save details, can be done at each RRD/DCP and at the end of the run
    def save_details(self, sim, dcp):
        self.save_demand(sim, dcp)
        for leg in sim.legs:
            self.save_leg(sim, leg, dcp)
            self.save_leg_bucket(sim, leg, dcp)
        self.save_fare(sim, dcp)

    def save_leg(self, sim, leg, dcp) -> string:
        dep_time = datetime.utcfromtimestamp(leg.dep_time).strftime('%Y-%m-%d %H:%M:%S')
        my_vars = [str(v) for v in [sim.name, sim.iteration, sim.trial, sim.sample, dcp,
                                 leg.carrier, leg.orig, leg.dest, leg.flt_no, dep_time, leg.capacity, leg.sold, leg.revenue]]
        tmp = ",".join(my_vars)
        self.leg_file.write(tmp)
        self.leg_file.write("\n")

    def save_leg_bucket(self, sim, leg, dcp, commit=True) -> None:
        dep_time = datetime.utcfromtimestamp(leg.dep_time).strftime('%Y-%m-%d %H:%M:%S')
        try:
            for n, bkt in enumerate(leg.buckets):
                my_vars = [str(v) for v in [sim.name, sim.iteration, sim.trial, sim.sample, dcp,
                                         leg.carrier, leg.orig, leg.dest, leg.flt_no, dep_time, n,
                                         bkt.name, bkt.alloc, bkt.revenue, bkt.sold]]
                tmp = ",".join(my_vars)
                self.bkt_file.write(tmp)
                self.bkt_file.write("\n")
        except:
            print("<-ERROR LOG-> from save_leg_bucket")
            print(leg)
            print(leg.print_bucket_detail())
            print("<-END ERROR LOG->")
            raise

    def save_demand(self, sim, dcp) -> None:
        for dmd in sim.demands:
            my_vars = [str(v) for v in [sim.name, sim.iteration, sim.trial, sim.sample, dcp,
                                     dmd.orig, dmd.dest, dmd.segment, dmd.scenario_demand, dmd.sold, dmd.revenue]]
            tmp = ",".join(my_vars)
            self.dmd_file.write(tmp)
            self.dmd_file.write("\n")

    def save_fare(self, sim, dcp) -> None:
        for fare in sim.fares:
            my_vars = [str(v) for v in [sim.name, sim.iteration, sim.trial, sim.sample, dcp, fare.carrier,
                                     fare.orig, fare.dest, fare.booking_class, fare.sold, fare.sold_business, fare.price]]
            tmp = ",".join(my_vars)
            self.fare_file.write(tmp)
            self.fare_file.write("\n")

