#
# Forecast demand at the leg / bucket_number level
#
# Alan W, Mathstream LLC, December 2022
#

from passengersim_core.utils.airsim_utils import compute_days_prior
from statistics import mean, pstdev
from passengersim.rm_steps import RmStep
from passengersim_core import Frat5
from typing import Literal
from passengersim.snapshot import get_snapshot_instruction, SnapshotInstruction

# ------ RM STEP, USED TO PLUG THIS INTO THE SYSTEM -----------------------------------------------
#
class ForecastStep(RmStep):

    step_type: Literal["forecast"]
    algorithm: Literal["exp_smoothing", "additive_pickup", "multiplicative_pickup"]
    kind: Literal["leg", "path", "hybrid"] = "leg"
    alpha: float = 0.15

    @property
    def requires(self):
        if self.kind == "path":
            return ["path_demand"]
        elif self.kind == "hybrid":
            return []    # Hybrid forecasting includes EM untruncation of yieldable demand
        elif self.kind == "leg":
            return ["leg_demand"]
        else:
            raise ValueError(f"bad kind {self.kind!r}")

    @property
    def produces(self):
        if self.kind in ("path", "hybrid"):
            return ["path_forecast"]
        elif self.kind == "leg":
            return ["leg_forecast"]
        else:
            raise ValueError(f"bad kind {self.kind!r}")

    def serialize(self):
        return {
            'step_type': "forecast",
            'name': self.name,
            'algorithm': self.algorithm,
            "alpha": self.alpha,
            "kind": self.kind,
        }

    def run(self, sim, _airline, _dcp_index, _dcp, _debug=False):
        if sim.sample < 3:
            return

        if _debug:
            print("Forecasting, sample = ", sim.sample, ", airline = ", _airline)

        if self.kind == "leg":
            self.leg_forecast(sim, _airline, _dcp_index, _dcp, _debug)
        elif self.kind == "path":
            self.path_forecast(sim, _airline, _dcp_index, _dcp, _debug)
        elif self.kind == "hybrid":
            self.hybrid_forecast(sim, _airline, _dcp_index, _dcp, _debug)
        else:
            raise Exception(f"Unknown forecast type: {self.kind}")

    def leg_forecast(self, sim, _airline, _dcp_index, _dcp, _debug:bool|SnapshotInstruction=False):
        for leg in sim.legs:
            if leg.carrier != _airline:
                continue
            debug_print = _debug or get_snapshot_instruction(sim, leg=leg, only_type="forecast")
            # The leg forecast() method will also forecast all the buckets
            debug_output = leg.forecast(_dcp_index, self.algorithm, debug_print)
            if debug_output:
                print(debug_output)

    def path_forecast(self, sim, _airline, _dcp_index, _dcp, _debug=False):
        for path in sim.paths:
            if path.get_leg_carrier(0) != _airline:
                continue
            debug_print = _debug or get_snapshot_instruction(sim, path=path, only_type="forecast")
            path.forecast(_dcp_index, self.algorithm, debug_print)

    def hybrid_forecast(self, sim, _airline, _dcp_index, _dcp, _debug=False):
        # Get the Frat5 curve we are going to use.
        # For now, there's just a single curve per airline
        f5 = None
        for a in sim.airlines:
            if a.name == _airline:
                f5 = a.frat5
                break
        if f5 is None:
            raise ValueError(f"Frat5 curve not found for hybrid forecasting")

        for path in sim.paths:
            if path.get_leg_carrier(0) != _airline:
                continue
            debug_print = _debug or get_snapshot_instruction(sim, path=path, only_type="forecast")
            debug_output = path.hybrid_forecast(_dcp_index, self.algorithm, debug_print, f5)
            if debug_output:
                print(debug_output)

    def run2_deprecated(self, sim, _airline, _dcp_index, _dcp, _debug=False):
        if sim.sample < 10:  # or sim.num_events() > 0:
            return

        if _debug:
            print("Forecasting, sample = ", sim.sample, ", airline = ", _airline)

        for leg in sim.legs:
            if leg.carrier != _airline:
                continue
            rrd = compute_days_prior(sim, leg.dep_time)
            for bkt in leg.buckets:
                if self.algorithm == "exp_smoothing":
                    self.single_bucket_exp_smoothing(leg, bkt, _dcp_index, _debug)
                elif self.algorithm == "additive_pickup":
                    self.additive_pickup2(leg, bkt, _dcp_index, _debug)
                    # self.single_bucket_additive_pickup(leg, bkt, _dcp_index, _debug)
                elif self.algorithm == "multiplicative_pickup":
                    self.single_bucket_multiplicative_pickup(leg, bkt, _dcp_index, _debug)
                else:
                    raise Exception(f"Unknown forecast algorithm: {self.algorithm}")

    def single_bucket_exp_smoothing(self, leg, bkt, _dcp_index, _debug=False):
        num_dcp = bkt.get_history_num_dcp()
        dep_fcst, vals = None, []
        for dep in range(1, bkt.get_history_num_dep()):
            remaining_demand = 0.0
            for i in range(_dcp_index, num_dcp):
                inc_demand = bkt.get_history_demand(dep, i)
                remaining_demand += inc_demand

            vals.append(remaining_demand)
            if dep_fcst is None:
                dep_fcst = remaining_demand
            else:
                dep_fcst = self.alpha * remaining_demand + (1.0 - self.alpha) * dep_fcst

        bkt.fcst_mean = dep_fcst
        std_dev = pstdev(vals)
        bkt.fcst_std_dev = std_dev
        bkt.fcst_revenue = bkt.revenue / bkt.sold if bkt.sold > 0 else 0

    def additive_pickup2(self, leg, bkt, _dcp_index, _debug=False):
        current_sold = bkt.sold   # bkt.get_history_demand(0, _dcp_index)

        # What is the average pickup from this DCP to departure?
        avg_pickup, n = 0.0, 0
        vals = []
        num_deps = bkt.get_history_num_dep()
        num_dcps = bkt.get_history_num_dcp()
        for dep in range(1, num_deps):
            inc_demand = 0.0
            for i in range(_dcp_index+1, num_dcps):
                inc_demand += bkt.get_history_demand(dep, i)
            current_demand = bkt.get_history_demand(dep, _dcp_index)
            avg_pickup += inc_demand
            n += 1
            final_demand = bkt.get_history_demand(dep, num_dcps - 1)
            vals.append(final_demand)

        avg_pickup = avg_pickup / n
        fcst = max(avg_pickup, 0.0)
        bkt.fcst_mean = fcst # + bkt.sold

        std_dev = pstdev(vals)
        bkt.fcst_std_dev = std_dev
        bkt.fcst_revenue = bkt.revenue / bkt.sold if bkt.sold > 0 else 0

        if avg_pickup < 0.0:
            print(f"{bkt.name}:{_dcp_index}, current_sold = {current_sold}, avg_pickup = {round(avg_pickup,2)}, fcst = {round(bkt.fcst_mean,2)}")

    def single_bucket_multiplicative_pickup(self, leg, bkt, _dcp_index, _debug=False):
        current_sold = bkt.sold   # bkt.get_history_demand(0, _dcp_index)

        vals = []
        total_dcp = 0.0
        total_dmd = 0.0
        for dep in range(1, bkt.get_history_num_dep()):
            this_dep = 0.0
            for dcp in range(bkt.get_history_num_dcp()):
                prev_sold = bkt.get_history_demand(dep, dcp-1) if dcp > 0 else 0
                inc_demand = bkt.get_history_demand(dep, dcp) - prev_sold
                total_dmd += inc_demand
                this_dep += inc_demand
            total_dcp += bkt.get_history_sold(dep, _dcp_index)
            vals.append(this_dep)

        ratio = total_dcp / total_dmd if total_dmd > 0 else 1.0

        fcst = current_sold / ratio if ratio > 0.0 else current_sold

        bkt.fcst_mean = fcst
        std_dev = pstdev(vals)
        bkt.fcst_std_dev = std_dev
        bkt.fcst_revenue = bkt.revenue / bkt.sold if bkt.sold > 0 else 0

