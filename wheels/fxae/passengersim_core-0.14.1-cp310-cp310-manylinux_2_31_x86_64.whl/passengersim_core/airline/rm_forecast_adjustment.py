#
# Adjust forecasts at the Path & PathClass level
#  - Mostly used for bid price controls without a gradient (i.e. ProBP optimizer)
#
# Alan W, Mathstream LLC, October 2023
#

from passengersim_core.utils.airsim_utils import compute_days_prior
from statistics import mean, pstdev
from passengersim.rm_steps import RmStep
from passengersim_core import Frat5
from typing import Any, Literal, Optional
from passengersim.snapshot import get_snapshot_instruction

# ------ RM STEP, USED TO PLUG THIS INTO THE SYSTEM -----------------------------------------------
#
class ForecastAdjustmentStep(RmStep):

    step_type: Literal["forecastadjustment"]
    algorithm: Literal["days_to_departure"]
    kind: Optional[Any]
    alpha: float = 0.15    # Not actually used for forecast adjustment

    @property
    def requires(self):
        return []

    @property
    def produces(self):
        return ["path_forecast"]

    def serialize(self):
        return {
            'step_type': "forecastadjustment",
            'name': self.name,
            'algorithm': self.algorithm,
            "kind": self.kind,
        }

    def run(self, sim, _airline, _dcp_index, _dcp, _debug=False):
        if sim.sample < 3:
            return

        if _debug:
            print("Forecast adjustment, sample = ", sim.sample, ", airline = ", _airline)

        current_ts = sim.last_event_time
        for p in sim.paths:
            if p.get_leg_carrier(0) == _airline:
                debug_print = _debug or get_snapshot_instruction(sim, path=p, only_type="forecastadjustment")
                last_fcst_ts = p.last_fcst_tx
                departure_ts = p.get_leg_dep_time(0)
                p.adjust_forecasts(last_fcst_ts, current_ts, departure_ts, debug_print)
                p.adjusted_at = current_ts

