
if __name__ == "__main__":
    print(f"""\
Copyright (c) 2023
This in-development tool is not for public distribution.
https://sites.gatech.edu/ce-atlatgt/
""")