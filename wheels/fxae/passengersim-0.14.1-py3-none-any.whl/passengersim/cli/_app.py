import typer

app = typer.Typer(help="PassengerSim Command Line Interface")
