#
# Forecast demand at the leg / bucket_number level
#
# Alan W, Mathstream LLC, December 2022
#

from passengersim_core.utils.airsim_utils import compute_days_prior
from passengersim_core import SimulationEngine
from statistics import pstdev
from passengersim.rm_steps import RmStep
from typing import Literal
from passengersim.snapshot import get_snapshot_instruction, SnapshotInstruction


# ------ RM STEP, USED TO PLUG THIS INTO THE SYSTEM -----------------------------------------------
#
class ForecastStep(RmStep):
    step_type: Literal["forecast"]
    """
    Forecasting step type must be "forecast". 
    """

    algorithm: Literal["exp_smoothing", "additive_pickup", "multiplicative_pickup"]
    """
    Forecasting algorithm.
    
    There are several available forecasting algorithms: 
    
    `exp_smoothing` 
        is an exponential smoothing model.  This model uses the `alpha` parameter 
        to control the amount of smoothing applied.  It does not (currently) 
        incorporate trend effects or seasonality.  
    
    `additive_pickup`
        is an additive pickup model, which generates a forecast by considering the 
        "pickup", or the number of new sales in a booking class, in each time 
        period (DCP).  This model is additive in that the forecast of demand yet 
        to come at given time is computed as the sum of forecast pickups in all 
        future time periods.  This forecasting model does not consider the level 
        of demand already accumulated, only the demand expected in the future. The 
        forecast is made considering the results from the prior 26 sample days. 
        The additive pickup model ignores the value of the alpha parameter, and it 
        can safely be omitted when using this algorithm.
        
    `multiplicative_pickup`
        is a multiplicative pickup model.  This model is in development.
    """

    kind: Literal["leg", "path", "hybrid"] = "leg"
    """
    Level of collected demand data that should be used for forecasting.
    
    Hybrid forecasting is primarily a path-based forecast, but it includes
    EM untruncation of yieldable demand.
    """

    alpha: float = 0.15
    """
    Exponential smoothing factor.
    """

    max_cap: float = 10.0


    @property
    def requires(self) -> list[str]:
        if self.kind == "path":
            return ["path_demand"]
        elif self.kind == "hybrid":
            return []  # Hybrid forecasting includes EM untruncation of yieldable demand
        elif self.kind == "leg":
            return ["leg_demand"]
        else:
            raise ValueError(f"bad kind {self.kind!r}")

    @property
    def produces(self) -> list[str]:
        if self.kind in ("path", "hybrid"):
            return ["path_forecast"]
        elif self.kind == "leg":
            return ["leg_forecast"]
        else:
            raise ValueError(f"bad kind {self.kind!r}")

    def serialize(self):
        return {
            "step_type": "forecast",
            "name": self.name,
            "algorithm": self.algorithm,
            "alpha": self.alpha,
            "kind": self.kind,
        }

    def run(self, sim, _airline, _dcp_index, _dcp, _debug=False):
        if sim.sample < 3:
            return

        if _debug:
            print("Forecasting, sample = ", sim.sample, ", airline = ", _airline)

        if self.kind == "leg":
            self.leg_forecast(sim, _airline, _dcp_index, _dcp, _debug)
        elif self.kind == "path":
            self.path_forecast(sim, _airline, _dcp_index, _dcp, _debug)
        elif self.kind == "hybrid":
            self.hybrid_forecast(sim, _airline, _dcp_index, _dcp, _debug)
        else:
            raise Exception(f"Unknown forecast type: {self.kind}")

    def leg_forecast(
        self,
        sim,
        _airline,
        _dcp_index,
        _dcp,
        _debug: bool | SnapshotInstruction = False,
    ):
        for leg in sim.legs:
            if leg.carrier != _airline:
                continue
            snapshot_instruction = get_snapshot_instruction(
                sim, leg=leg, only_type="forecast", debug=_debug
            )
            # The leg forecast() method will also forecast all the buckets
            leg.forecast(_dcp_index, self.algorithm, snapshot_instruction)

    def path_forecast(self, sim, _airline, _dcp_index, _dcp, _debug=False):
        for path in sim.paths:
            if path.get_leg_carrier(0) != _airline:
                continue
            snapshot_instruction = get_snapshot_instruction(
                sim, path=path, only_type="forecast", debug=_debug
            )
            path.forecast(_dcp_index, self.algorithm, sim.last_event_time, snapshot_instruction)

    def hybrid_forecast(
        self,
        sim: SimulationEngine,
        airline: str,
        dcp_index: int,
        _dcp: int,
        debug: bool = False,
    ):
        """
        Generate hybrid forecasts.

        Parameters
        ----------
        sim : SimulationEngine
            The simulation engine where the hybrid forecasts should be created.
        airline : str
            The forecasts are only generated for paths served by this carrier.
        dcp_index : int
        _dcp : int
            This parameter is unused.
        debug : bool, default False
            Override snapshot instructions, writing output directly to stdout
            instead of to a file.
        """

        # Get the Frat5 curve we are going to use.
        # For now, there's just a single curve per airline
        f5 = None
        for a in sim.airlines:
            if a.name == airline:
                f5 = a.frat5
                break
        if f5 is None:
            raise ValueError("Frat5 curve not found for hybrid forecasting")

        for path in sim.paths:
            if path.get_leg_carrier(0) != airline:
                continue
            snapshot_instruction = get_snapshot_instruction(
                sim, path=path, only_type="forecast", debug=debug
            )
            path.hybrid_forecast(
                dcp_index, self.algorithm, snapshot_instruction, f5, self.max_cap
            )

    def run2_deprecated(self, sim, _airline, _dcp_index, _dcp, _debug=False):
        if sim.sample < 10:  # or sim.num_events() > 0:
            return

        if _debug:
            print("Forecasting, sample = ", sim.sample, ", airline = ", _airline)

        for leg in sim.legs:
            if leg.carrier != _airline:
                continue
            compute_days_prior(sim, leg.dep_time)
            for bkt in leg.buckets:
                if self.algorithm == "exp_smoothing":
                    self.single_bucket_exp_smoothing(leg, bkt, _dcp_index, _debug)
                elif self.algorithm == "additive_pickup":
                    self.additive_pickup2(leg, bkt, _dcp_index, _debug)
                    # self.single_bucket_additive_pickup(leg, bkt, _dcp_index, _debug)
                elif self.algorithm == "multiplicative_pickup":
                    self.single_bucket_multiplicative_pickup(
                        leg, bkt, _dcp_index, _debug
                    )
                else:
                    raise Exception(f"Unknown forecast algorithm: {self.algorithm}")

    def single_bucket_exp_smoothing(self, leg, bkt, _dcp_index, _debug=False):
        num_dcp = bkt.get_history_num_dcp()
        dep_fcst, vals = None, []
        for dep in range(1, bkt.get_history_num_dep()):
            remaining_demand = 0.0
            for i in range(_dcp_index, num_dcp):
                inc_demand = bkt.get_history_demand(dep, i)
                remaining_demand += inc_demand

            vals.append(remaining_demand)
            if dep_fcst is None:
                dep_fcst = remaining_demand
            else:
                dep_fcst = self.alpha * remaining_demand + (1.0 - self.alpha) * dep_fcst

        bkt.fcst_mean = dep_fcst
        std_dev = pstdev(vals)
        bkt.fcst_std_dev = std_dev
        bkt.fcst_revenue = bkt.revenue / bkt.sold if bkt.sold > 0 else 0

    def additive_pickup2(self, leg, bkt, _dcp_index, _debug=False):
        current_sold = bkt.sold  # bkt.get_history_demand(0, _dcp_index)

        # What is the average pickup from this DCP to departure?
        avg_pickup, n = 0.0, 0
        vals = []
        num_deps = bkt.get_history_num_dep()
        num_dcps = bkt.get_history_num_dcp()
        for dep in range(1, num_deps):
            inc_demand = 0.0
            for i in range(_dcp_index + 1, num_dcps):
                inc_demand += bkt.get_history_demand(dep, i)
            bkt.get_history_demand(dep, _dcp_index)
            avg_pickup += inc_demand
            n += 1
            final_demand = bkt.get_history_demand(dep, num_dcps - 1)
            vals.append(final_demand)

        avg_pickup = avg_pickup / n
        fcst = max(avg_pickup, 0.0)
        bkt.fcst_mean = fcst  # + bkt.sold

        std_dev = pstdev(vals)
        bkt.fcst_std_dev = std_dev
        bkt.fcst_revenue = bkt.revenue / bkt.sold if bkt.sold > 0 else 0

        if avg_pickup < 0.0:
            print(
                f"{bkt.name}:{_dcp_index}, current_sold = {current_sold}, "
                f"avg_pickup = {round(avg_pickup,2)}, fcst = {round(bkt.fcst_mean,2)}"
            )

    def single_bucket_multiplicative_pickup(self, leg, bkt, _dcp_index, _debug=False):
        current_sold = bkt.sold  # bkt.get_history_demand(0, _dcp_index)

        vals = []
        total_dcp = 0.0
        total_dmd = 0.0
        for dep in range(1, bkt.get_history_num_dep()):
            this_dep = 0.0
            for dcp in range(bkt.get_history_num_dcp()):
                prev_sold = bkt.get_history_demand(dep, dcp - 1) if dcp > 0 else 0
                inc_demand = bkt.get_history_demand(dep, dcp) - prev_sold
                total_dmd += inc_demand
                this_dep += inc_demand
            total_dcp += bkt.get_history_sold(dep, _dcp_index)
            vals.append(this_dep)

        ratio = total_dcp / total_dmd if total_dmd > 0 else 1.0

        fcst = current_sold / ratio if ratio > 0.0 else current_sold

        bkt.fcst_mean = fcst
        std_dev = pstdev(vals)
        bkt.fcst_std_dev = std_dev
        bkt.fcst_revenue = bkt.revenue / bkt.sold if bkt.sold > 0 else 0
