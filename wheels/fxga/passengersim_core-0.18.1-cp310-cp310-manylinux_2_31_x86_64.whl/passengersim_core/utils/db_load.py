#
# Experimenting with loading durectly to the DB from CSV files
# Uses MySQL
#
# Alan Walker, Mathstream LLC, March 2023
#

import os
from datetime import datetime
import string
from time import time

import mysql.connector
from mysql.connector import errorcode

from passengersim_core import SimulationEngine
import db_utils

def save_details(cnx, sim):
    file_root = "/Users/alanw/projects/air-sim/output/test1"
    t1 = time()
    load_demand(cnx, file_root)
    print(f"Loaded demand, {round(time() - t1, 2)} seconds")

    t1 = time()
    load_leg(cnx, file_root)
    print(f"Loaded legs, {round(time() - t1, 2)} seconds")

    t1 = time()
    load_leg_bucket(cnx, file_root)
    print(f"Loaded buckets, {round(time() - t1, 2)} seconds")

    t1 = time()
    load_fare(cnx, file_root)
    print(f"Loaded fares, {round(time() - t1, 2)} seconds")


def load_demand(cnx, file_root) -> string:
    try:
        cursor = cnx.cursor()
        file_name = file_root + "_demands.csv"
        sql = f"""LOAD DATA
                INFILE '{file_name}'
                REPLACE INTO TABLE demand_detail
                FIELDS TERMINATED BY ',' 
                IGNORE 1 LINES
                (scenario, iteration, trial, sample, rrd, orig, dest, segment, sample_demand, sold, revenue)"""
        cursor.execute(sql, ())
        return True
    except mysql.connector.Error as err:
        print("Doh !!! leg_detail: {}".format(err))
        return False


def load_leg(cnx, file_root) -> string:
    try:
        cursor = cnx.cursor()
        file_name = file_root + "_legs.csv"
        sql = f"""LOAD DATA
                INFILE '{file_name}'
                REPLACE INTO TABLE leg_detail
                FIELDS TERMINATED BY ',' 
                IGNORE 1 LINES
                (scenario, iteration, trial, sample, rrd, carrier, orig, dest, flt_no, dep_date, capacity, sold, revenue)"""
        cursor.execute(sql, ())
        return True
    except mysql.connector.Error as err:
        print("Doh !!! leg_detail: {}".format(err))
        return False


def load_leg_bucket(cnx, sim) -> string:
    try:
        cursor = cnx.cursor()
        file_name = "/Users/alanw/projects/air-sim/output/test1_buckets.csv"
        sql = f"""LOAD DATA
                INFILE '{file_name}'
                REPLACE INTO TABLE leg_bucket_detail
                FIELDS TERMINATED BY ',' 
                IGNORE 1 LINES
                (scenario, iteration, trial, sample, rrd, carrier, orig, dest, flt_no,
                dep_date, bucket_number, name, auth, revenue, sold)"""
        cursor.execute(sql, ())
        return True
    except mysql.connector.Error as err:
        print("Doh !!! leg_detail: {}".format(err))
        return False

def load_fare(cnx, file_root) -> string:
    try:
        cursor = cnx.cursor()
        file_name = file_root + "_fares.csv"
        sql = f"""LOAD DATA
                INFILE '{file_name}'
                REPLACE INTO TABLE fare
                FIELDS TERMINATED BY ',' 
                IGNORE 1 LINES
                (scenario, iteration, trial, sample, rrd, carrier, orig, dest, booking_class, sold, sold_business, price)"""
        cursor.execute(sql, ())
        return True
    except mysql.connector.Error as err:
        print("Doh !!! leg_detail: {}".format(err))
        return False


if __name__ == "__main__":
    cnx = db_utils.get_database_connection()
    sim = SimulationEngine("Junk")
    save_details(cnx, sim)

