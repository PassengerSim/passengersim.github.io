#
# Quick and dirty subgradient optimizer for RM
#
# Alan Walker, Mathstream LLC, Novemeber 2022
#

import numpy as np
from scipy.stats import gamma
from statistics import NormalDist
from time import time


def subgradient(a, dmd, price, cap, _max_iter=500, _max_viol=0.1, step_size=0.2, cv100=0.2,
                add_slacks=False, epsilon = 0.00001, debug=False):
    """Simple subgradient optimizer
       Follows the example given in Barry Smith's dissertation
       I think the original formulation is due to Elizabeth (something)'s dissertation at MIT"""
    dual = np.ones(len(cap)) * min(price)
    momentum = np.zeros(len(cap))

    # Add slacks - I've used this in the past, not 100% sure we need it though...
    if add_slacks:
        ident = np.identity(len(cap))
        a = np.concatenate((a, ident), axis=1)
        slack_price = np.ones(len(cap))
        price = np.concatenate((price, slack_price), axis=0)
        dmd = np.concatenate((dmd, cap), axis=0)

    alloc = np.ones(len(dmd))
    abs_viol, prev_abs_viol = 8e9, 9e9      # Largest capacity constraint violation
    stddev = cv100 * np.sqrt(dmd) * 10.0
    best_sum_viol_squared, counter = 9e9, 0

    for iteration in range(_max_iter):
        sum_dual = dual.dot(a)
        z = 1 - sum_dual / price
        for i in range(len(dmd)):
            if z[i] > epsilon and z[i] < (1 - epsilon):
                tmp_alloc = NormalDist(mu=dmd[i], sigma=stddev[i]).inv_cdf(z[i])
                # Tried Gamma, couldn't get it to work :-(
                # tmp_alloc = gamma.ppf(z[i], loc=dmd[i], scale=stddev[i], a=2)
            else:
                tmp_alloc = 0.0
            alloc[i] = tmp_alloc if tmp_alloc > 0 else 0
        viol = cap - a.dot(alloc)
        dual -= step_size * viol + momentum
        if debug:
            print("Iteration", iteration)
            print("    z     = ", list(np.round(z, 3)))
            print("    alloc = ", list(np.round(alloc, 2)))
            print("    viol  = ", np.round(viol, 2))
            print("    delta = ", np.round(step_size * viol, 2))
            print("    dual  = ", np.round(dual, 2))
        momentum = 0.25 * (step_size * viol)          # Helps convergence !!!
        abs_viol = max(abs(viol))                     # Only care about going over capacity!

        sum_viol_squared = viol.dot(viol)
        if sum_viol_squared < best_sum_viol_squared:
            best_sum_viol_squared = sum_viol_squared
            counter = 0
        else:
            counter += 1

        if counter > 3:
            counter = 0
            step_size *= 0.75

        if abs_viol > prev_abs_viol:
            step_size *= 0.98
        elif abs_viol <= _max_viol:
            break   # Converged !

        prev_abs_viol = abs_viol
        if debug:
            print("    ", abs_viol, step_size)

    return alloc, dual, viol, iteration, abs_viol


if __name__ == "__main__":
    # Imagine DEN-DFW, connecting to DFW-BOS & DFW-ATL, each with 50 seats
    cap = np.array([50, 50, 50])

    # Markets are Y, Q by 3 local, then 2 connecting (DEN-BOS, DEN-ATL)
    #                 DEN-DFW   DFW-BOS   DFW-MIA   DEN-BOS   DEN-MIA
    #                 Y    Q    Y    Q    Y    Q    Y    Q    Y    Q
    price = np.array([200, 100, 300, 150, 250, 125, 450, 225, 400, 200])
    dmd = np.array(    [30, 45,  30,  45,  30,  45,  20,  30,  15,  22])

    # Incidence matrix, row is the flight, column is the demand & price
    a = np.array([[1, 1, 0, 0, 0, 0, 1, 1, 1, 1],     # DEN-DFW
                  [0, 0, 1, 1, 0, 0, 1, 1, 0, 0],     # DFW-BOS
                  [0, 0, 0, 0, 1, 1, 0, 0, 1, 1]])    # DFW-ATL

    dmd = dmd * 0.8

    # Let 'er rip !!!
    start_time = time()
    alloc, dual, viol, iteration, abs_viol = subgradient(a, dmd, price, cap, debug=False)

    print(f"Time = {round(time() - start_time, 3)}")
    print(f"abs_viol = {round(abs_viol, 3)}, iteration = {iteration}")
    print("alloc = ", [round(a, 2) for a in alloc])
    print("viol = ", [round(v, 2) for v in viol])
    print("bid price = ", [round(d, 2) for d in dual])
    print("E(rev) = ", round(alloc[0:len(price)].dot(price), 2))
