#
# Experimenting with log-log regression to learn a Frat5 curve
#
# Alan W, Mathstream LLC, February 2024
#

from math import exp, log, isnan
from collections import defaultdict
import numpy as np
from passengersim.rm_steps import RmStep
from scipy import stats
from scipy.optimize import curve_fit
from passengersim_core import Frat5
from typing import Any, Literal, Optional

# ------ RM STEP, USED TO PLUG THIS INTO THE SYSTEM -----------------------------------------------
#
class ElasticityStep(RmStep):
    step_type: Literal["elasticity"]
    algorithm: Literal["loglog"]
    kind: Optional[Any]
    alpha: Optional[float] = 0.05
    min_r: Optional[float] = 0.75
    smoothing_function: Optional[Literal["none", "sigmoid", "tanh", "polynomial"]] = "none"

    @property
    def requires(self):
        return []

    @property
    def produces(self):
        return []

    def serialize(self):
        return {
            'step_type': "elasticity",
            'name': self.name,
            'algorithm': self.algorithm,
            "kind": self.kind,
        }

    def run(self, sim, airline_code, _dcp_index, _days_prior, _debug=False):
        if sim.sample < 3:
            return

        if _debug:
            print("Elasticity, sample = ", sim.sample, ", airline = ", airline_code)

        for a in sim.airlines:
            if a.name == airline_code:
                airline = a
                break
        f5 = airline.frat5

        # Some code I use during debugging
#        if sim.sample % 100 == 0:
#            print("sample = ", sim.sample)

        dcp_list = [63, 56, 49, 42, 35, 31, 28, 24, 21, 17, 14, 10, 7, 5, 3, 1]
        for dcp_index in range(len(dcp_list)):
            dcp = dcp_list[dcp_index]
            data = self.get_data(sim, airline_code, dcp)
            data2 = self.make_cumulative(sim, data)
            ratio = self.do_regression(sim, data2)
            if ratio > 0.0:
                new_val = self.alpha * ratio + (1.0 - self.alpha) * f5.get_val(dcp_index)
                f5.set_val(dcp_index, new_val)

        if self.smoothing_function != "none" and sim.sample % 7 == 0:
            self.smooth(f5, dcp_list)

    def get_data(self, sim, airline_code, dcp):
        all = {}
        for f in sim.fares:
            if f.carrier != airline_code:
                continue

            mkt_key = f"{f.orig}-{f.dest}"
            if mkt_key not in all:
                all[mkt_key] = defaultdict(int)

            key2 = f.price
            sold = f.get_sales_by_dcp2(dcp)
            all[mkt_key][key2] += sold

        for m in sim.markets:
            mkt_key = f"{m.orig}-{m.dest}"
            tmp = " ".join(["(" + str(p) + ", " + str(d) + ")" for p, d in all[mkt_key].items()])
            # print(f"Market:{mkt_key} = {tmp}")
        return all

    def make_cumulative(self, sim, d):
        for m in sim.markets:
            mkt_key = f"{m.orig}-{m.dest}"
            sales = d[mkt_key]
            sales2 = [(_price, _sold) for _price, _sold in sales.items()]
            sales2 = sorted(sales2, reverse=True)
            prev, sales3 = 0, []
            for z in sales2:
                cum_sold = z[1] + prev
                prev = cum_sold
                sales3.append((z[0], cum_sold))
            d[mkt_key] = sales3
        return d

    def do_regression(self, sim, d):
        tot_ratio, tot_sold = 0.0, 0
        for m in sim.markets:
            mkt_key = f"{m.orig}-{m.dest}"
            sales = d[mkt_key]

            # log-log regression
            try:
                x, y = [], []
                #for price, sold in sales:
                #    if sold == 0 or price < 1.0:
                #        continue
                #    x.append(log(sold))
                #    y.apped(log(price))
                x = [log(sold + 0.1) for _price, sold in sales]
                y = [log(price + 0.1) for price, _sold in sales]
                slope, intercept, r, p, std_err = stats.linregress(x, y)
            except:
                continue

            # Don't use junk...
            if abs(r) < self.min_r:
                continue

            # Convert to FRAT5 value, with weighted average over the markets
            ratio = - slope / 0.5
            if ratio < 1.0:
                ratio = 1.0
            sold = exp(x[-1]) - 0.1
            tot_ratio += sold * ratio
            tot_sold += sold
        z = tot_ratio / tot_sold if tot_sold > 0 else 0.0
        if isnan(z):
            z = 1.0
        return z

    def smooth(self, f5: Frat5, dcp_list: list):
        if len(dcp_list) > -1:
            return
        x_t, y_t = [], []
        for dcp_index in range(len(dcp_list)):
            x_t.append(dcp_index)
            y_t.append(f5.get_val(dcp_index))
        x = np.array(x_t)
        y = np.array(y_t)
        if self.smoothing_function == "sigmoid":
            fn = smooth_sigmoid
        elif self.smoothing_function == "tanh":
            fn = smooth_tanh
        elif self.smoothing_function == "polynomial":
            fn = smooth_polynomial
        else:
            raise ValueError(f"Unknown smoothing function: {self.smoothing_function}")
        try:
            param, param_cov = curve_fit(fn, x, y, method='lm')
            y_hat = fn(x, param[0], param[1], param[2], param[3])
        except:
            return
        # print("Adjust Frat5")
        for dcp_index in range(len(dcp_list)):
            new_val = y_hat[dcp_index]
            new_val = max(new_val, 1.0)
            f5.set_val(dcp_index, new_val)


# ------ SMOOTHING FUNCTIONS FOR THE FRAT5 CURVES -----------------------------------------------
#
def smooth_tanh(x, s, c, h, d):
    return d + s * np.tanh(c * x + h)


def smooth_sigmoid(x, s, c, h, d):
    return d + s / (1.0 + np.exp(-1 * c * x + h))


def smooth_polynomial(x, a, b, c, d):
    return a * x**3 + b * x**2 + c * x + d


