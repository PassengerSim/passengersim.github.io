#
# Adjust forecasts at the Path & PathClass level
#  - Mostly used for bid price controls without a gradient (i.e. ProBP optimizer)
#
# Alan W, Mathstream LLC, October 2023
#

from passengersim_core.utils.airsim_utils import compute_days_prior
from statistics import mean, pstdev
from passengersim.rm_steps import RmStep
from passengersim_core import Frat5
from typing import Any, Literal, Optional


# ------ RM STEP, USED TO PLUG THIS INTO THE SYSTEM -----------------------------------------------
#
class FareAdjustmentStep(RmStep):
    step_type: Literal["fareadjustment"]
    algorithm: Literal["ki", "mr"]
    kind: Optional[Any]
    alpha: Optional[float] = 0.15    # Not actually used for fare adjustment
    frat5: str

    @property
    def requires(self):
        return ["path_forecast"]

    @property
    def produces(self):
        return ["path_forecast"]

    def serialize(self):
        return {
            'step_type': "fareadjustment",
            'name': self.name,
            'algorithm': self.algorithm,
            "kind": self.kind,
        }

    def run(self, sim, _airline, _dcp_index, _days_prior, _debug=False):
        if sim.sample < 3:
            return

        if _debug:
            print("Fare adjustment, sample = ", sim.sample, ", airline = ", _airline)

        # Get the curve we're going to use
        f5 = None   # Frat5("test")
        for a in sim.airlines:
            if a.name == _airline:
                f5 = a.frat5
                if f5 is None:
                    raise Exception("Must have a Frat5 curve to use Fare Adjustment")
                break
        if _dcp_index >= f5.num_values:
            return

        # Once I'm happy with the algorithm, I'll probably migrate these loops into C++ for performance
        for dmd in sim.demands:
            # Only do this for the specified airline
            tmp_fares = [f for f in dmd.fares if f.carrier == _airline]

            # Highest fare doesn't get adjusted, this just simplifies reporting...
            f = tmp_fares[0]
            f.adjust_price(_dcp_index, f.price)

            lo_fare = tmp_fares[-1].price
            for j in range(1, len(tmp_fares)):
                f = tmp_fares[j]
                tgt_fare = f.price
                if self.algorithm == "mr":
                    adj_fare = f5.adjust_fare_mr(_dcp_index, tgt_fare, lo_fare)
                elif self.algorithm == "ki":
                    next_higher_fare = tmp_fares[j-1].price
                    adj_fare = f5.adjust_fare_ki(_dcp_index, tgt_fare, next_higher_fare, lo_fare)
                else:
                    raise ValueError(f"Unknown algorithm for Fare Adjustment, '{self.algorithm}'")
                adj_fare = max(adj_fare, 0.0)
                # print(f"Adjust fare: dcp={_dcp_index}, price={tgt_fare}, adj_fare={adj_fare}")
                f.adjust_price(_dcp_index, adj_fare)

