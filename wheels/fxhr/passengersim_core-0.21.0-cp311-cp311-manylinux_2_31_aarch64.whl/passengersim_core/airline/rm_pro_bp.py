#
# Experimenting with CoreProBP
#  - C++ version
#
# Alan W, Mathstrem LLC, May 2023
#
import pathlib
from time import time
from typing import Any, Literal

from passengersim_core import (
    SimulationEngine,
    Bucket,
    Demand,
    Fare,
    Leg,
    Path,
    PathClass,
    ProBP,
)
from passengersim.config import SnapshotFilter, SnapshotInstruction
from passengersim.rm_steps import RmStep


class ProBpStep(RmStep):
    """Implements ProBP as an RM Step"""

    snapshot_filters: list[Any] = []

    step_type: Literal["probp"]

    kind: Literal["path"] = "path"
    """
    ProBP is a path-based optimization algorithm.

    The `kind` parameter is included in the interface for compatability, but setting
    any value here other than `path` will result in an error.
    """

    maxiter: int = 10
    """
    The maximum number of iterations to run ProBP. 
    
    If the algorithm has not converged by the time this number of iterations has 
    been reached, it will stop and return the current results.
    """

    @property
    def requires(self) -> list[str]:
        return ["path_forecast"]

    def __init__(self, **data):
        super().__init__(**data)
        self._pro_bp = {}

    @property
    def pro_bp(self):
        return self._pro_bp

    def serialize(self):
        return {
            "step_type": "probp",
            "name": self.name,
        }

    def run(
        self,
        sim: SimulationEngine,
        airline: str,
        dcp_index: int = 0,
        dcp: int = 0,
        debug: bool = False,
    ):
        if sim.sample < 10:  # or sim.num_events() > 0:
            return

        # We keep a map of core objects, as the CoreProBP code caches
        # the data structures it needs for each iteration
        if airline not in self.pro_bp:
            self.pro_bp[airline] = ProBP(sim, airline)

        z = self.pro_bp[airline]
        debug_print = debug
        if sim.snapshot_filters is not None:
            snapshot_filters = sim.snapshot_filters
        else:
            snapshot_filters = SnapshotFilter.filters
        snapshot_instuction = None
        info = ""
        debug_output_title = None
        for sf in snapshot_filters:
            if sf.type != "pro_bp":
                continue
            snapshot_instuction = sf.run(sim, carrier=airline)
            info = getattr(sf, "_last_run_info", "")
            if snapshot_instuction and (sf.airline == airline or sf.airline == ""):
                debug_print = True
                z.debug_fltno = sf.flt_no[0] if len(sf.flt_no) > 0 else 0
                debug_output_title = sf.title
                break
        debug_output = z.run(self.maxiter, snapshot_instuction)
        if debug_output:
            print(debug_output)

        # update bucket allocations  # not needed?
        # for leg in sim.legs:
        #     if leg.carrier != airline:
        #         continue
        #     cap = int(leg.capacity - leg.sold)
        #     for bkt in leg.buckets:
        #         if bkt.fcst_revenue > leg.bid_price:
        #             bkt.alloc = cap
        #             is_open = True
        #         else:
        #             bkt.alloc = 0
        #             is_open = False
        #         if isinstance(snapshot_instuction, SnapshotInstruction) and snapshot_instuction:
        #             if snapshot_instuction.filter.flt_no and leg.flt_no in snapshot_instuction.filter.flt_no:
        #                 snapshot_instuction.write_more(
        #                     f"+ {sim.sample=} {dcp=} {leg.bid_price=} {bkt.name=} "
        #                     f"{bkt.price=} {bkt.fcst_revenue=} {bkt.fcst_mean=} {is_open=}"
        #                 )


# ===================================================================================================
# Everything from here down is testing and experimentation code, it will get moved to unit tests
# once I have it all working and if I'm happy with the results
#


def setup_demand(p, booking_class, price, mean, sigma):
    """This is used to build the test data"""
    pc = PathClass(booking_class)
    p.add_path_class(pc)

    f = Fare("XX", p.orig, p.dest, booking_class, price)
    pc.add_fare(f)
    pc.decision_fare = f.price
    pc.fcst_mean = mean
    pc.fcst_std_dev = sigma if sigma > 0.0 else mean * 0.3
    return p


def setup_sample(sim):
    leg1 = Leg("XX", 1, "SFO", "DEN", 100)
    leg2 = Leg("XX", 2, "DEN", "STL", 120)
    for b in ["B1", "B2", "B3"]:
        leg1.add_bucket(Bucket(b))
        leg2.add_bucket(Bucket(b))
    sim.add_leg(leg1)
    sim.add_leg(leg2)
    d = Demand("SFO", "DEN", "business", 50, 50)
    sim.add_demand(d)
    p = Path("SFO", "DEN")
    p.add_leg(leg1)
    d.add_path(p)
    sim.add_path(p)
    setup_demand(p, "Y1", 180, 10, 0)
    setup_demand(p, "Y2", 160, 20, 0)
    setup_demand(p, "Y3", 140, 16, 0)
    setup_demand(p, "Y4", 130, 18, 0)
    setup_demand(p, "Y5", 100, 27, 0)

    d = Demand("DEN", "STL", "business", 50, 50)
    sim.add_demand(d)
    p = Path("DEN", "STL")
    p.add_leg(leg2)
    d.add_path(p)
    sim.add_path(p)
    setup_demand(p, "Y1", 130, 15, 0)
    setup_demand(p, "Y2", 110, 20, 0)
    setup_demand(p, "Y3", 90, 15, 0)
    setup_demand(p, "Y4", 80, 20, 0)
    setup_demand(p, "Y5", 75, 30, 0)

    d = Demand("SFO", "STL", "business", 50, 50)
    sim.add_demand(d)
    p = Path("SFO", "STL")
    p.add_leg(leg1, leg2)
    d.add_path(p)
    sim.add_path(p)
    setup_demand(p, "Y1", 260, 20, 0)
    setup_demand(p, "Y2", 240, 10, 0)
    setup_demand(p, "Y3", 200, 10, 0)
    setup_demand(p, "Y4", 190, 15, 0)
    setup_demand(p, "Y5", 170, 15, 0)


if __name__ == "__main__":
    start_time = time()
    sim = SimulationEngine("CoreProBP")
    setup_sample(sim)

    print(f"Setup time = {round(time() - start_time, 3)}")

    start_time = time()
    z = ProBP(sim, "XX")
    z.run(False)
    print(f"ProBP time = {round(time() - start_time, 3)}")

    print("Th' th' that's all folks !!!")
