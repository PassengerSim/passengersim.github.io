

CREATE TABLE IF NOT EXISTS leg_detail
(
	scenario	    	VARCHAR(20) NOT NULL,
    iteration	    	INT NOT NULL,
    trial	        	INT NOT NULL,
    sample  	    	INT NOT NULL,
    rrd             	INT NOT NULL,
    carrier		    	VARCHAR(10) NOT NULL,
    orig		    	VARCHAR(10) NOT NULL,
    dest		    	VARCHAR(10) NOT NULL,
    flt_no		    	INT NOT NULL,
    dep_date	    	DATETIME NOT NULL,
    updated_at	    	DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    capacity	    	INT,
    sold	    		INT,
    revenue             FLOAT,
    q_demand            FLOAT,
    untruncated_demand  FLOAT,
    demand_fcst         FLOAT
-- PRIMARY KEY(scenario, iteration, trial, sample, carrier, orig, dest, flt_no, rrd, dep_date)
);


CREATE TABLE IF NOT EXISTS leg_bucket_detail
(
    scenario		VARCHAR(20) NOT NULL,
    iteration		INT NOT NULL,
    trial	    	INT NOT NULL,
    sample  		INT NOT NULL,
    rrd         	INT NOT NULL,
    carrier			VARCHAR(10) NOT NULL,
    orig			VARCHAR(10) NOT NULL,
    dest			VARCHAR(10) NOT NULL,
    flt_no			INT NOT NULL,
    dep_date		DATETIME NOT NULL,
    bucket_number   INT NOT NULL,
    name            VARCHAR(10) NOT NULL,
    auth    		INT,
    revenue    		FLOAT,
    sold			INT,
    untruncated_demand     FLOAT,
    demand_fcst     FLOAT,
    updated_at		DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
--     PRIMARY KEY(scenario, iteration, trial, sample, rrd, carrier, orig, dest, flt_no, dep_date, bucket_number)
);



-- DROP TABLE demand_detail;
CREATE TABLE IF NOT EXISTS demand_detail
(
	scenario		VARCHAR(20) NOT NULL,
    iteration		INT NOT NULL,
    trial	    	INT NOT NULL,
    sample  		INT NOT NULL,
    rrd     	    INT NOT NULL,
    segment			VARCHAR(10) NOT NULL,
    orig			VARCHAR(10) NOT NULL,
    dest			VARCHAR(10) NOT NULL,
    updated_at		DATETIME NOT NULL DEFAuLT CURRENT_TIMESTAMP,
    sample_demand   FLOAT,
    sold			INT,
    no_go			INT,
    revenue			FLOAT
-- PRIMARY KEY(scenario, iteration, trial, sample, rrd, segment, orig, dest)
);


-- DROP TABLE fare;
CREATE TABLE IF NOT EXISTS fare
(
    scenario		VARCHAR(20) NOT NULL,
    iteration		INT NOT NULL,
    trial	    	INT NOT NULL,
    sample  		INT NOT NULL,
    rrd       		INT NOT NULL,
    carrier			VARCHAR(10) NOT NULL,
    orig			VARCHAR(10) NOT NULL,
    dest			VARCHAR(10) NOT NULL,
    booking_class   VARCHAR(10) NOT NULL,
    sold			INT,
    sold_business	INT,
    price           FLOAT,
    updated_at		DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
--     PRIMARY KEY(scenario, iteration, trial, sample, rrd, carrier, orig, dest, booking_class)
);




-- ################################################################################################
-- BOOKING CURVES FOR A SIMPLE FORECAST
--

-- These are used for leg-based forecasts
CREATE TABLE IF NOT EXISTS booking_curve (
    scenario		VARCHAR(20) NOT NULL,
    carrier			VARCHAR(10) NOT NULL,
    orig			VARCHAR(10) NOT NULL,
    dest			VARCHAR(10) NOT NULL,
    flt_no			INT NOT NULL,
    rrd         	INT NOT NULL,
    ratio           FLOAT NOT NULL,
    PRIMARY KEY(scenario, carrier, orig, dest, flt_no, rrd)
);


CREATE TABLE IF NOT EXISTS distance (
    orig			VARCHAR(10) NOT NULL,
    dest			VARCHAR(10) NOT NULL,
    miles           FLOAT,
    PRIMARY KEY(orig, dest)
);

