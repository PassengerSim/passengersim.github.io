#
# Runs all the RM components end-to-end
#
# Alan W, Mathstream LLC, February 2023
#

from passengersim_core.airline import rm_step


class Rm_System:
    def __init__(self, _name=""):
        self.name = _name
        self.steps = []
        self.availability_control = "none"

    def add_step(self, _step):
        """Add a step to the RM pipeline, and check that it's compatible"""
        available_data = []
        for s in self.steps:
            # Check inputs to this step
            for input_data in s.requires:
                if input_data not in available_data:
                    raise Exception(f"Step: {s.name} requires {input_data}")
            # What does this step output?
            for output_data in s.produces:
                available_data.append(output_data)
        self.steps.append(_step)

    def add_parm(self, p1, p2):
        """Used by the file loader
           Parameter is passed to the last step that was added"""
        if len(self.steps) == 0:
            raise Exception("No steps in the RM System, cannot add parameter")
        self.steps[-1].add_parm(p1, p2)

    def run(self, sim, _airline, _dcp_index=0, _dcp=0):
        for s in self.steps:
            s.run(sim, _airline, _dcp_index, _dcp)

