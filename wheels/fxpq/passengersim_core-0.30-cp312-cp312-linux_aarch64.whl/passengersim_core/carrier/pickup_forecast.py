#
# Pickup / booking-curve models for forecasting
#
# Starting with objects in memory, but I might do a SQL version of these in the future.
# - May change slightly as I integrate it with the other pieces
# - Doesn't (yet) have much error handling and exception logic
#
# Alan W, Nov 2022
# (c) PassengerSim LLC
#

from functools import reduce


class Flt:
    """Only used internally for testing.  Actual application will use the Flight class"""

    def __init__(self, _bkgs: list | None = None):
        """One observation per DCP, will be None if unavailable / not observed yet
        Lowest DCP is in position 0, and then on..."""
        if _bkgs is None:
            _bkgs = []
        self.bkgs = _bkgs


def find_dcp(new_flt):
    """Which is the most recent DCP we can use to forecast bookings at departure?
    Only used when the caller doesn't say which one we should use"""
    for dcp, n in enumerate(new_flt.bkgs):
        if n is not None:
            return dcp
    return None


def simple_additive(history, new_flt, dcp: int = None, debug: bool = False):
    """Additive pickup model, only using departed flights"""
    dcp = find_dcp(new_flt) if dcp is None else dcp

    # What is the average build in bookings for that period?
    avg_build = reduce(lambda tot, f: tot + f.bkgs[0] - f.bkgs[dcp], history, 0) / len(history)
    fcst = new_flt.bkgs[dcp] + avg_build

    if debug:
        print(f"Additive: DCP={dcp}, avg_build={round(avg_build, 2)}, fcst={round(fcst, 2)}")

    return fcst


def simple_multiplicative(history, new_flt, dcp: int = None, debug: bool = False):
    """Multiplicative pickup model, only using departed flights"""
    dcp = find_dcp(new_flt) if dcp is None else dcp

    # Get the ratio and the forecast
    sum_0 = reduce(lambda tot, f: tot + f.bkgs[0], history, 0)
    sum_dcp = reduce(lambda tot, f: tot + f.bkgs[dcp], history, 0)
    ratio = sum_0 / sum_dcp if sum_dcp > 0 else 1.0
    fcst = new_flt.bkgs[dcp] * ratio

    if debug:
        print(f"Multiplicative: DCP={dcp}, ratio={round(ratio, 2)}, fcst={round(fcst, 2)}")

    return fcst


# -------------------------------------------------------------------
if __name__ == "__main__":
    print("Demo of pickup models for demand forecasting")
    hist = [
        Flt([100, 90, 70, 55, 25, 10, 0]),
        Flt([97, 87, 65, 50, 23, 9, 0]),
        Flt([94, 80, 60, 45, 21, 8, 0]),
        Flt([91, 77, 57, 42, 19, 7, 0]),
        Flt([88, 73, 54, 39, 17, 6, 0]),
    ]
    tmp_flt = Flt([None, None, 45, 30, 13, 4, 0])
    _ = simple_additive(hist, tmp_flt, debug=True)
    _ = simple_multiplicative(hist, tmp_flt, debug=True)
