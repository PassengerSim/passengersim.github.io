#
# Quick and dirty subgradient optimizer for RM
#
#   Follows the example given in Barry Smith's dissertation
#   I think the original formulation is due to Elizabeth (something)'s dissertation at MIT
#
#   Just mucking around with it for now, it will be recoded into C++ if we ever want to scale up
#
# Alan Walker, November 2022
# (c) PassengerSim LLC
#

import numpy as np
from scipy.stats import gamma
from statistics import NormalDist

from collections import defaultdict
from time import time
from typing import Any, Literal

from passengersim_core import SimulationEngine, Leg, Path, PathClass
from passengersim.rm_steps import RmStep


class SubgradientStep(RmStep):
    """Implements Subgradient as an RM Step"""

    snapshot_filters: list[Any] = []

    step_type: Literal["subgradient"]

    kind: Literal["path"] = "path"
    """
    Subgradient is a path-based optimization algorithm to compute bid-price.

    The `kind` parameter is included in the interface for compatability, but setting
    any value here other than `path` will result in an error.
    """

    max_iter: int = 100
    max_viol: float = 1.0
    step_size: float = 0.25
    min_lambda: float = 0.5
    cv100: float = 0.2
    epsilon: float = 0.001
    momentum_alpha: float = 0.3
    use_gamma: bool = False

    @property
    def requires(self) -> list[str]:
        return ["path_forecast"]

    def __init__(self, **data):
        super().__init__(**data)
        self._subgradient = {}

    @property
    def subgradient(self):
        return self._subgradient

    def serialize(self):
        return {
            "step_type": "subgradient",
            "name": self.name,
        }

    def run(self, sim: SimulationEngine, carrier: str, _dcp_index: int = 0, _days_prior: int = 0, debug: bool = False):
        if sim.sample < 10:  # or sim.num_events() > 0:
            return

        self.create_matrices(sim, carrier)
        a, price, dmd, std_dev, cap = self.create_matrices(sim, carrier)
        a, price, dmd, std_dev, cap = self.add_slacks(a, price, dmd, std_dev, cap)
        alloc, dual, viol, iteration, abs_viol = self.optimize(
            a,
            price=price,
            dmd=dmd,
            std_dev=std_dev,
            cap=cap,
            _max_iter=self.max_iter,
            _step_size=self.step_size,
            _min_lambda=self.min_lambda,
            _max_viol=self.max_viol,
            _use_gamma=self.use_gamma,
            _debug=debug,
        )

        # Now set the bid prices
        j = 0
        for leg in sim.legs:
            if leg.carrier_name != carrier:
                continue
            if dual[j] <= 0.0:
                print("Zero bid price")
            leg.bid_price = dual[j]
            j += 1

    def create_matrices(self, sim: SimulationEngine, carrier: str):
        a_map = defaultdict(list)
        price, dmd, std_dev = [], [], []
        col = 0
        for p in sim.paths:
            if p.get_leg_carrier(0) != carrier:
                continue
            for pc in p.pathclasses:
                price.append(pc.decision_fare)
                dmd.append(max(pc.fcst_mean, 0.01))
                std_dev.append(max(pc.fcst_std_dev, 0.01))

                # Save data for the incidence (a) matrix
                for i in range(p.num_legs()):
                    flt_no = p.get_leg_fltno(i)
                    a_map[flt_no].append(col)
                col += 1

        # And now the incidence matrix
        cap = []
        a = np.empty((0, len(dmd)), float)
        for leg in sim.legs:
            if leg.carrier != carrier:
                continue
            # Remaining capacity
            cap.append(leg.capacity - leg.sold)
            row = np.zeros((1, len(dmd)))
            tmp = a_map[leg.flt_no]
            for j in tmp:
                row[0, j] = 1.0
            a = np.append(a, row, axis=0)

        # We are going to return NumPy arrays
        price = np.array(price)
        dmd = np.array(dmd)
        std_dev = np.array(std_dev)
        cap = np.array(cap)
        return a, price, dmd, std_dev, cap

    def add_slacks(self, a, price, dmd, std_dev, cap):
        # Add slacks - I've used this in the past, not 100% sure we need it though...
        ident = np.identity(len(cap))
        a = np.concatenate((a, ident), axis=1)
        slack_price = np.ones(len(cap))
        price = np.concatenate((price, slack_price), axis=0)
        dmd = np.concatenate((dmd, cap), axis=0)
        std_dev = np.concatenate((dmd, cap), axis=0)
        return a, price, dmd, std_dev, cap

    # @jit(nopython=True)
    def optimize(
        self,
        a: Any,
        dmd: Any,
        std_dev: Any,
        price: Any,
        cap: Any,
        _max_iter: float = 100,
        _step_size: float = 0.25,
        _min_lambda: float = 0.5,
        _epsilon: float = 0.001,
        _max_viol: float = 0.5,
        _momentum_alpha: float = 0.3,
        _step_adjust: float = 0.75,
        _use_gamma: bool = False,
        _debug: bool = False,
    ) -> (Any, Any, Any, Any, Any):
        dual = np.ones(len(cap)) * min(price)
        momentum = np.zeros(len(cap))
        alloc = np.ones(len(dmd))
        abs_viol, prev_abs_viol = 8e9, 9e9  # Largest capacity constraint violation
        best_sum_viol_squared, counter = 9e9, 0

        for _iteration in range(_max_iter):
            sum_dual = dual.dot(a)
            z = 1 - sum_dual / price
            for i in range(len(dmd)):
                if z[i] > _epsilon and z[i] < (1 - _epsilon) and std_dev[i] > _epsilon:
                    mu = dmd[i]
                    if _use_gamma:
                        var = std_dev[i] ** 2
                        shape = mu**2 / var
                        scale = var / mu
                        tmp_alloc = gamma.ppf(z[i], shape, loc=0, scale=scale)
                    else:
                        tmp_alloc = NormalDist(mu, sigma=std_dev[i]).inv_cdf(z[i])
                else:
                    tmp_alloc = 0.0
                alloc[i] = tmp_alloc if tmp_alloc > 0 else 0
            viol = cap - a.dot(alloc)
            dual -= _step_size * viol + momentum
            dual = np.maximum(dual, _min_lambda)
            #            if debug:
            #                print("Iteration", iteration)
            #                print("    z     = ", list(np.round(z, 3)))
            #                print("    alloc = ", list(np.round(alloc, 2)))
            #                print("    viol  = ", np.round(viol, 2))
            #                print("    delta = ", np.round(_step_size * viol, 2))
            #                print("    dual  = ", np.round(dual, 2))
            momentum = _momentum_alpha * (_step_size * viol)  # Helps convergence !!!
            abs_viol = max(abs(viol))  # Only care about going over capacity!

            # Convergence test, and adjustment of step size if no improvement
            sum_viol_squared = viol.dot(viol)
            if sum_viol_squared < best_sum_viol_squared:
                best_sum_viol_squared = sum_viol_squared
                counter = 0
            else:
                counter += 1

            if counter > 3:
                counter = 0
                _step_size *= _step_adjust

            if abs_viol > prev_abs_viol:
                _step_size *= 0.98
            elif abs_viol <= _max_viol:
                break  # Converged !

            prev_abs_viol = abs_viol
        #            if debug:
        #                print("    ", abs_viol, _step_size)

        #        if abs_viol > _max_viol:
        #            print(f"maxIter = {_max_iter}, iterations = {iteration}")
        return alloc, dual, viol, _iteration, abs_viol


def test_case_1():
    # TEST1 - manual creation of the matrices
    # Imagine DEN-DFW, connecting to DFW-BOS & DFW-ATL, each with 50 seats
    cap = np.array([50, 50, 50])

    # Markets are Y, Q by 3 local, then 2 connecting (DEN-BOS, DEN-ATL)
    #                 DEN-DFW   DFW-BOS   DFW-ATL   DEN-BOS   DEN-ATL
    #                 Y    Q    Y    Q    Y    Q    Y    Q    Y    Q
    price = np.array([200, 150, 300, 150, 250, 125, 450, 225, 400, 250])
    dmd = np.array([30, 45, 30, 45, 30, 45, 20, 30, 15, 22])
    std_dev = np.array([6, 9, 6, 9, 6, 9, 4, 5, 3, 4])

    # Incidence matrix, row is the flight, column is the demand & price
    a = np.array(
        [
            [1, 1, 0, 0, 0, 0, 1, 1, 1, 1],  # DEN-DFW
            [0, 0, 1, 1, 0, 0, 1, 1, 0, 0],  # DFW-BOS
            [0, 0, 0, 0, 1, 1, 0, 0, 1, 1],
        ]
    )  # DFW-ATL

    # dmd = dmd * 0.8

    # Let 'er rip !!!
    start_time = time()
    sg = SubgradientStep(step_type="subgradient", kind="path")
    alloc, dual, viol, iteration, abs_viol = sg.optimize(a, dmd=dmd, std_dev=std_dev, price=price, cap=cap, debug=False)

    print(f"Time = {round(time() - start_time, 3)}")
    print(f"abs_viol = {round(abs_viol, 3)}, iteration = {iteration}")
    print("alloc = ", [round(a, 2) for a in alloc])
    print("viol = ", [round(v, 2) for v in viol])
    print("bid price = ", [round(d, 2) for d in dual])
    print("E(rev) = ", round(alloc[0 : len(price)].dot(price), 2))


def test_case_2():
    # ***************************************************************************************************
    # TEST2 - working on convergence, using an example that wasn't converging from the 3-market test
    start_time = time()
    a = [
        [
            1,
            1,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            1,
            0,
            0,
            0,
        ],
        [
            0,
            0,
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            1,
            0,
            0,
        ],
        [
            1,
            1,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            1,
            0,
        ],
        [
            0,
            0,
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            1,
            1,
            1,
            1,
            1,
            1,
            0,
            0,
            0,
            1,
        ],
    ]

    cap = [61, 61, 42, 37]
    dmd = [
        4.80478620e00,
        8.27683149e00,
        1.00000000e-02,
        1.00000000e-02,
        3.31857259e00,
        4.18970312e-01,
        1.00000000e-02,
        1.00000000e-02,
        4.33337147e00,
        3.38020060e00,
        9.16140961e-01,
        6.98394534e00,
        1.00000000e-02,
        5.94758555e00,
        1.00000000e-02,
        1.55601371e00,
        4.75000000e-01,
        1.52500000e00,
        4.08234263e00,
        1.00000000e-02,
        6.19546451e00,
        1.00000000e-02,
        1.94456542e00,
        4.16666667e-01,
        1.00000000e-02,
        1.01233037e01,
        1.00000000e-02,
        8.30695357e00,
        7.17213870e-01,
        2.49499134e00,
        1.00000000e-02,
        1.00000000e-02,
        1.06633814e00,
        1.09919237e01,
        7.35534318e00,
        2.31122000e00,
        6.10000000e01,
        6.10000000e01,
        4.20000000e01,
        3.70000000e01,
    ]
    std_dev = [
        4.80478620e00,
        8.27683149e00,
        1.00000000e-02,
        1.00000000e-02,
        3.31857259e00,
        4.18970312e-01,
        1.00000000e-02,
        1.00000000e-02,
        4.33337147e00,
        3.38020060e00,
        9.16140961e-01,
        6.98394534e00,
        1.00000000e-02,
        5.94758555e00,
        1.00000000e-02,
        1.55601371e00,
        4.75000000e-01,
        1.52500000e00,
        4.08234263e00,
        1.00000000e-02,
        6.19546451e00,
        1.00000000e-02,
        1.94456542e00,
        4.16666667e-01,
        1.00000000e-02,
        1.01233037e01,
        1.00000000e-02,
        8.30695357e00,
        7.17213870e-01,
        2.49499134e00,
        1.00000000e-02,
        1.00000000e-02,
        1.06633814e00,
        1.09919237e01,
        7.35534318e00,
        2.31122000e00,
        6.10000000e01,
        6.10000000e01,
        4.20000000e01,
        3.70000000e01,
        6.10000000e01,
        6.10000000e01,
        4.20000000e01,
        3.70000000e01,
    ]

    price = [
        625,
        750,
        250,
        200,
        450,
        325,
        250,
        200,
        625,
        450,
        325,
        750,
        125,
        300,
        100,
        400,
        150,
        200,
        200,
        125,
        300,
        100,
        400,
        150,
        175,
        500,
        150,
        400,
        225,
        300,
        175,
        150,
        225,
        500,
        400,
        300,
        1,
        1,
        1,
        1,
    ]

    a = np.array(a)
    cap = np.array(cap)
    dmd = np.array(dmd)
    std_dev = np.array(std_dev)
    price = np.array(price)
    sg = SubgradientStep(step_type="subgradient", kind="path")
    alloc, dual, viol, iteration, abs_viol = sg.optimize(
        a,
        dmd=dmd,
        std_dev=std_dev,
        price=price,
        cap=cap,
        _debug=False,
        _max_viol=1.0,
        _step_size=0.3,
        _max_iter=500,
        _epsilon=0.001,
        _min_lambda=1.0,
        _step_adjust=0.75,
        _momentum_alpha=0.3,
        _use_gamma=True,
    )
    print(f"Time = {round(time() - start_time, 3)}")
    print(f"abs_viol = {round(abs_viol, 3)}, iteration = {iteration}")
    print("alloc = ", [round(a, 2) for a in alloc])
    print("viol = ", [round(v, 2) for v in viol])
    print("bid price = ", [round(d, 2) for d in dual])
    print("E(rev) = ", round(alloc[0 : len(price)].dot(price), 2))


def test_case_3():
    # ***************************************************************************************************
    # TEST3 - create the matrices from the PassengerSim classes
    start_time = time()
    sim = SimulationEngine("test")
    leg1 = Leg(1, "AL1", 1, "DEN", "DFW", 50)
    leg2 = Leg(2, "AL1", 2, "DFW", "BOS", 50)
    leg3 = Leg(3, "AL1", 3, "DFW", "ATL", 50)
    sim.add_leg(leg1, leg2, leg3)

    #    price = np.array([200, 150, 300, 150, 250, 125, 450, 225, 400, 250])
    #    dmd = np.array(    [30, 45,  30,  45,  30,  45,  20,  30,  15,  22])

    path1 = Path("DEN", "DFW", 0.0)
    path1.add_leg(leg1)
    pc = PathClass("Y")
    pc.decision_fare = 200
    pc.fcst_mean = 30
    path1.add_path_class(pc)
    pc = PathClass("Q")
    pc.decision_fare = 150
    pc.fcst_mean = 45
    path1.add_path_class(pc)
    sim.add_path(path1)

    path2 = Path("DFW", "BOS", 0.0)
    path2.add_leg(leg2)
    pc = PathClass("Y")
    pc.decision_fare = 300
    pc.fcst_mean = 30
    path2.add_path_class(pc)
    pc = PathClass("Q")
    pc.decision_fare = 150
    pc.fcst_mean = 45
    path2.add_path_class(pc)
    sim.add_path(path2)

    path3 = Path("DFW", "ATL", 0.0)
    path3.add_leg(leg3)
    pc = PathClass("Y")
    pc.decision_fare = 250
    pc.fcst_mean = 30
    path3.add_path_class(pc)
    pc = PathClass("Q")
    pc.decision_fare = 125
    pc.fcst_mean = 45
    path3.add_path_class(pc)
    sim.add_path(path3)

    path4 = Path("DEN", "BOS", 0.0)
    path4.add_leg(leg1, leg2)
    pc = PathClass("Y")
    pc.decision_fare = 450
    pc.fcst_mean = 20
    path4.add_path_class(pc)
    pc = PathClass("Q")
    pc.decision_fare = 225
    pc.fcst_mean = 30
    path4.add_path_class(pc)
    sim.add_path(path4)

    path5 = Path("DEN", "ATL", 0.0)
    path5.add_leg(leg1, leg3)
    pc = PathClass("Y")
    pc.decision_fare = 400
    pc.fcst_mean = 15
    path5.add_path_class(pc)
    pc = PathClass("Q")
    pc.decision_fare = 250
    pc.fcst_mean = 22
    path5.add_path_class(pc)
    sim.add_path(path5)

    print("***** CREATE MATRICES *****")
    sg = SubgradientStep(step_type="subgradient", kind="path")
    a, price, dmd, std_dev, cap = sg.create_matrices(sim, "AL1")
    print(price)
    print(dmd)
    print(std_dev)
    print(cap)
    print(a)

    a, price, dmd, std_dev, cap = sg.add_slacks(a, price, dmd, std_dev, cap)
    alloc, dual, viol, iteration, abs_viol = sg.optimize(a, dmd=dmd, std_dev=std_dev, price=price, cap=cap, debug=False)

    print(f"Time = {round(time() - start_time, 3)}")
    print(f"abs_viol = {round(abs_viol, 3)}, iteration = {iteration}")
    print("alloc = ", [round(a, 2) for a in alloc])
    print("viol = ", [round(v, 2) for v in viol])
    print("bid price = ", [round(d, 2) for d in dual])
    print("E(rev) = ", round(alloc[0 : len(price)].dot(price), 2))


if __name__ == "__main__":
    test_case_2()
