#
# RM Step to use Linear Programming
#
# For now, it's largely a placeholder, but there are some things I'd like to do with LP
#  - Displacement calculation for DAVN
#  - Deterministic LP, just as a base model
#  - Piecewise Linear approximation
#  - Sales Based LP (SBLP), along the lines of Sabre's model
#
# Alan W, June 2024
# (c) PassengerSim LLC
#

from ortools.linear_solver import pywraplp
from typing import Any, Literal

from passengersim_core import (
    SimulationEngine,
)
from passengersim.config import SnapshotFilter
from passengersim.rm_steps import RmStep
from passengersim_core import DynamicProgram
from statistics import NormalDist


class LpStep(RmStep):
    """Implements Linear Programming as an RM Step"""

    snapshot_filters: list[Any] = []

    step_type: Literal["lp"]

    kind: Literal["path"] = "path"
    """
    LP is a path-based optimization algorithm - but I might add leg in the future...

    The `kind` parameter is included in the interface for compatability, but setting
    any value here other than `path` will result in an error.
    """

    @property
    def requires(self) -> list[str]:
        return ["path_forecast"]

    @property
    def produces(self) -> list[str]:
        return ["bid_price", "displacement"]

    def __init__(self, **data):
        super().__init__(**data)
        self._lp = {}

    @property
    def lp(self):
        return self._lp

    def serialize(self):
        return {
            "step_type": "lp",
            "name": self.name,
        }

    def run(
        self,
        sim: SimulationEngine,
        carrier: str,
        dcp_index: int = 0,
        dcp: int = 0,
        debug: bool = False,
    ):
        if sim.sample < 10:  # or sim.num_events() > 0:
            return

#        if carrier not in self._lp:
        self._lp[carrier] = LpPiecewiseSolver(sim, carrier)
        tmp = DynamicProgram(sim, carrier)
        tmp.initialize()  # This step sets up the PcPtr structures, will refactor later to make this a separate call
        # self._lp[carrier].initialize()

        s = self._lp[carrier]
#        s.update(sim)
        s.solve(sim)

        _debug_print = debug
        snapshot_instruction = None
        if sim.snapshot_filters is not None:
            snapshot_filters = sim.snapshot_filters
            for sf in snapshot_filters:
                assert isinstance(sf, SnapshotFilter)
                if sf.type != "lp":
                    continue
                snapshot_instruction = sf.run(sim, carrier=carrier)
                _info = getattr(sf, "_last_run_info", "")
                if snapshot_instruction and (sf.carrier == carrier or sf.carrier == ""):
                    _debug_print = True
                    # z.debug_fltno = sf.flt_no[0] if len(sf.flt_no) > 0 else 0
                    _debug_output_title = sf.title
                    break

        debug_output = None  # z.run(self.maxiter, snapshot_instruction)
        if debug_output:
            print(debug_output)


class LpSimpleSolver:
    __slots__ = ("carrier", "solver", "objective", "lp_vars", "constraints")

    def __init__(self, sim: SimulationEngine, carrier: str):
        self.carrier = carrier
        self.solver = pywraplp.Solver.CreateSolver("GLOP")
        self.objective = self.solver.Objective()
        self.objective.SetMaximization()

        # create LP decision variables, which are how many passengers to accept for each path class
        self.lp_vars = {}
        for path in sim.paths:
            if path.carrier == carrier:
                for pc in path.pathclasses:
                    name = pc.identifier
                    fare = pc.fare_price
                    pc_dmd = pc.fcst_mean
                    self.lp_vars[name] = x = self.solver.NumVar(0, pc_dmd, name)
                    self.objective.SetCoefficient(x, fare)

        # Create capacity constraints
        # print("CAPACITY CONSTRAINTS")
        self.constraints = {}
        for leg in sim.legs:
            if leg.carrier_name != carrier:
                continue
            ct = self.solver.Constraint(0, leg.capacity - leg.sold, f"Leg-{leg.flt_no}")
            for pc_id in leg.pathclass_identifiers:
                ct.SetCoefficient(self.lp_vars[pc_id], 1)
                # print(f"  Leg={leg}, pc_id={pc_id}")
            self.constraints[leg.flt_no] = ct

    def update(self, sim: SimulationEngine):
        # update LP decision variables, which are how many passengers to accept for each path class
        for path in sim.paths:
            if path.carrier == self.carrier:
                for pc in path.pathclasses:
                    name = pc.identifier
                    self.lp_vars[name].SetUb(pc.fcst_mean)

        # Create capacity constraints
        for leg in sim.legs:
            if leg.carrier_name != self.carrier:
                continue
            self.constraints[leg.flt_no].SetUb(leg.capacity - leg.sold)

    def solve(self, sim: SimulationEngine):
        _result_status = self.solver.Solve()
        # The bid prices are the dual values of the capacity constraints
        for leg in sim.legs:
            if leg.carrier_name != self.carrier:
                continue
            # The duals of the constraints are the displacement costs.
            # In theory, they should be non-negative by construction, but we
            # enforce that here because the solver can sometimes return tiny
            # negative values due to numerical imprecision.
            leg.displacement = max(self.constraints[leg.flt_no].dual_value(), 0)
            leg.bid_price = leg.displacement
            # print(f"Leg: {leg}, bp={leg.bid_price}")


class LpPiecewiseSolver:
    """Just fiddling with an approach to approximate the non-linear stochastic problem.
       Break each demand into pieces, and price them at the expected marginal revenue"""
    __slots__ = ("carrier", "solver", "objective", "lp_vars", "constraints")

    def __init__(self, sim: SimulationEngine, carrier: str, debug=False):
        epsilon = 0.01
        self.carrier = carrier
        self.solver = pywraplp.Solver.CreateSolver("GLOP")
        self.objective = self.solver.Objective()
        self.objective.SetMaximization()

        # create LP decision variables, which are how many passengers to accept for each path class
        num_pieces = 25
        max_std_dev = 2.5
        self.lp_vars = {}
        if debug:
            print(f"********** Sample = {sim.sample}, setup decision variables **********")
        for path in sim.paths:
            if path.carrier == carrier:
                for pc in path.pathclasses:
                    fare = pc.fare_price
                    pc_dmd = pc.fcst_mean
                    pc_std_dev = pc.fcst_std_dev
                    var_max = pc_dmd + max_std_dev * pc_std_dev
                    piece_size = var_max / num_pieces
                    lh_rev = fare
                    for piece in range(num_pieces):
                        # What the probability that demand is at least (piece * piece_size)?
                        if pc_dmd < epsilon or pc_std_dev < epsilon:
                            prob = 0.0
                        else:
                            prob = 1.0 - NormalDist(mu=pc_dmd, sigma=pc_std_dev).cdf(piece * piece_size)
                        rh_rev = fare * prob
                        avg_rev = (lh_rev + rh_rev) / 2.0
                        lh_rev = rh_rev
                        name = f"{pc.identifier}-{piece}"
                        self.lp_vars[name] = x = self.solver.NumVar(0, piece_size, name)
                        if debug:
                            print(f"    Add variable: {name}, size={piece_size}, rev={avg_rev}")
                        self.objective.SetCoefficient(x, avg_rev)

        # Create capacity constraints
        if debug:
            print("CAPACITY CONSTRAINTS")
        self.constraints = {}
        for leg in sim.legs:
            if leg.carrier_name != carrier:
                continue
            ct = self.solver.Constraint(0, leg.capacity - leg.sold, f"Leg-{leg.flt_no}")
            for pc_id in leg.pathclass_identifiers:
                for piece in range(num_pieces):
                    name = f"{pc_id}-{piece}"
                    ct.SetCoefficient(self.lp_vars[name], 1)
                    if debug:
                        print(f"    Leg={leg}, name={name}")
            self.constraints[leg.flt_no] = ct

    def solve(self, sim: SimulationEngine, debug=False):
        _result_status = self.solver.Solve()
        # The bid prices are the dual values of the capacity constraints
        for leg in sim.legs:
            if leg.carrier_name != self.carrier:
                continue
            # The duals of the constraints are the displacement costs.
            # In theory, they should be non-negative by construction, but we
            # enforce that here because the solver can sometimes return tiny
            # negative values due to numerical imprecision.
            leg.displacement = max(self.constraints[leg.flt_no].dual_value(), 0)
            leg.bid_price = leg.displacement
            if debug:
                print(f"Leg: {leg}, bp={leg.bid_price}")


if __name__ == "__main__":
    print("Hello from LP")
