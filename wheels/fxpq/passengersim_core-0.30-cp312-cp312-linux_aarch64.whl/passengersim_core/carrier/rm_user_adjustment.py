#
# Simulate users overriding the RM recommendations
#
# Alan W, March 2024
# (c) PassengerSim LLC
#

from typing import Any, Literal

from passengersim_core import SimulationEngine, Leg
from passengersim.rm_steps import RmStep


# ------ RM STEP, USED TO PLUG THIS INTO THE SYSTEM -----------------------------------------------


class UserAdjustmentStep(RmStep):
    snapshot_filters: list[Any] = []
    step_type: Literal["useradjustment"]

    def serialize(self):
        return {
            "step_type": "useradjustment",
            "name": self.name,
        }

    def run(self, sim: SimulationEngine, carrier, dcp_index=0, _days_prior=0, debug=False):
        if sim.sample < sim.rm_start_sample:
            return
        for leg in sim.legs:
            if leg.carrier_name != carrier:
                continue
            self.close_lowest_to_match(sim, leg)

    def close_lowest_to_match(self, sim: SimulationEngine, leg: Leg):
        # First, we turn off the force closed flags
        for bkt in leg.buckets:
            bkt.force_closed = False

        # Check competitors' lowest fare
        for mkt in sim.markets:
            if mkt.orig == leg.orig and mkt.dest == leg.dest:
                my_lowest, market_lowest = self.get_lowest_fares(sim, mkt, leg.carrier_name)

                # Don't be the cheapest !!!
                if my_lowest < market_lowest:
                    lowest_open_bkt = None
                    for bkt in leg.buckets:
                        if bkt.alloc > 0:
                            lowest_open_bkt = bkt
                        else:
                            break
                    if lowest_open_bkt is not None:
                        lowest_open_bkt.force_closed = True

    def get_lowest_fares(self, sim, mkt, carrier_name):
        my_lowest, market_lowest = 9e9, 9e9
        for cxr in sim.carriers:
            try:
                price = mkt.get_competitor_price(cxr.name)
            except Exception:
                continue
            if cxr.name == carrier_name:
                my_lowest = min(my_lowest, price)
            else:
                market_lowest = min(market_lowest, price)
        return my_lowest, market_lowest


if __name__ == "__main__":
    print("Hello World, I'm an RM Analyst !!!")
