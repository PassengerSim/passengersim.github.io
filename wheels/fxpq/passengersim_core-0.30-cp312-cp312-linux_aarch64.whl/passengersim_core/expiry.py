# (c) PassengerSim LLC


import datetime
from ._Zoo import SimulationEngine


def build_expiration():
    return SimulationEngine("").build_expiration().astimezone(datetime.UTC)
