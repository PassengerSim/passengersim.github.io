#
# Custom exceptions for PassengerSim
#
# Alan W, December 2022
# (c) PassengerSim LLC
#


class InputParseException(Exception):
    """Thrown when the input file has syntax errors"""

    pass
