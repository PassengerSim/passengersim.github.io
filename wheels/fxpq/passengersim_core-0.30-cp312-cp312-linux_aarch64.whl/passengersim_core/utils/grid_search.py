#
# Experimenting with grid-search parameters
#
# Alan W, January 2023
# (c) PassengerSim LLC
#

import argparse
import os

from passengersim_core.utils import SimDriver


if __name__ == "__main__":
    # Get the base input data
    parser = argparse.ArgumentParser()
    parser.add_argument("-n", "--network-file", help="network file", default="C:/AirSim-networks/network-3mkt-pods.txt")
    parser.add_argument("-a", "--airports-file", help="airports file", default=None)
    args = parser.parse_args()

    if not os.path.exists(args.network_file):
        raise FileNotFoundError(args.network_file)
    # input_file = os.path.normpath(os.path.join(__file__, "../../../networks/network-3mkt-pods.txt"))
    # airports_file = "/Users/alanw/projects/air-sim/data/cities.scd"
    airports_file = args.airports_file
    sd = SimDriver(input_file=args.network_file, airports_file=airports_file)

    # Now run a series of named scenarios, telling it what to change each time
    tests = [("GS_base", {}), ("GS_2", {"sys_k_factor": 0.3}), ("GS_3", {"sys_k_factor": 0.3, "mkt_k_factor": 0.1})]
    for scenario, mods in tests:
        sd.modify(scenario, mods)
        sd.go()
