#
# Class to store airport data
#
# Alan W, October 2022
# (c) PassengerSim LLC
#


class Airport:
    def __init__(self, _code):
        self.code = _code
        self.city = None
        self.name = None
        self.country = None
        self.country_name = None
        self.gmt_offset = None
        self.latitude = None
        self.longitude = None

    def __str__(self):
        return f"{self.code}:{self.name}, {self.country}:{self.country_name}"


def get_airports(file_name):
    airport_dict = {}
    input_file = open(file_name)
    for line in input_file:
        line = line.strip(" \n")
        if len(line) == 0 or line[0] == "#":
            continue
        z = line.split(";")

        a = Airport(z[0])
        a.city = z[1]
        a.name = z[2].strip()
        a.country = z[11]
        a.country_name = z[12].strip()
        a.gmt_offset = float(z[19]) / 2.0

        # Latitude and longitude
        lon_deg = int(z[20])
        lon_min = int(z[21])
        lon_sec = int(z[22])
        longitude = lon_deg + lon_min / 60.0 + lon_sec / 3600.0
        a.longitude = -1 * longitude if z[23] == "W" else longitude

        lat_deg = int(z[24])
        lat_min = int(z[26])
        lat_sec = int(z[22])
        latitude = lat_deg + lat_min / 60.0 + lat_sec / 3600.0
        a.latitude = -1 * latitude if z[27] == "S" else latitude
        airport_dict[a.code] = a

    input_file.close()
    return airport_dict


# Simple test for trying it standalone
if __name__ == "__main__":
    file_name = "/data/cities.scd"
    airports = get_airports(file_name)
    for ac in ["PPT", "EYW", "SYD"]:
        print(airports[ac])
