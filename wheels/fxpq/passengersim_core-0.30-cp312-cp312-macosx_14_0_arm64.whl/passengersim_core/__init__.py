logo = """\
   ___                                     _____
  / _ \___ ____ ___ ___ ___  ___ ____ ____/ __(_)_ _
 / ___/ _ `(_-<(_-</ -_) _ \/ _ `/ -_) __/\ \/ /  ' \
/_/   \_,_/___/___/\__/_//_/\_, /\__/_/ /___/_/_/_/_/
                           /___/  Version {}
"""
import sqlite3  # code complains about missing library without this # noqa: F401

from ._Zoo import *  # noqa: F401, F403
from .expiry import build_expiration
from ._infer_version import __version__, __version_tuple__

__all__ = [
    "Airport",
    "Ancillary",
    "BookingCurve",
    "Bucket",
    "Cabin",
    "Carrier",
    "ChoiceModel",
    "DecisionWindow",
    "Demand",
    "DynamicProgram",
    "EMSR",
    "Event",
    "Fare",
    "Forecast",
    "ForecastVectors",
    "Frat5",
    "Generator",
    "Leg",
    "Market",
    "MctException",
    "MultiFlightEM",
    "MyIterator",
    "Offer",
    "Path",
    "PathClass",
    "ProBP",
    "SimulationEngine",
    "LicenseError",
    "__version__",
    "__version_tuple__",
    "build_expiration",
]
