#
# Read in the Alaska mini-schedule from Excel and write it out in YAML
#
# AlanW, 7/31/2024
# (c) PassengerSim LLC
#

import pandas as pd

airlines = ["AA", "AS", "B6", "DL", "UA", "WN"]
input_file = "/Users/alanw/projects/pxsim-clean/passengersim-core/data/AS_Mini_Network_All_Airlines.xlsx"


def format_time(t):
    hh = int(t / 100)
    mm = int(t % 100)
    return f"{hh}:{mm:02d}"


print("legs:")
for cxr in airlines:
    z = pd.read_excel(input_file, sheet_name=cxr)
    for _index, d in z.iterrows():
        dep_date = "2020-01-01"
        dep_time = format_time(d.Departure)
        arr_time = format_time(d.Arrival)
        print(f"  - carrier: {cxr}")
        print(f"    fltno: {d.Flight}")
        print(f"    orig: {d.Origin}")
        print(f"    dest: {d.Destination}")
        print(f"    date: '{dep_date}'")
        print(f"    dep_time: '{dep_time}'")
        print(f"    arr_time: '{arr_time}'")
        print(f"    capacity: {d.Capacity}")
        print(f"    distance: {d.Mileage}")
    print("")
