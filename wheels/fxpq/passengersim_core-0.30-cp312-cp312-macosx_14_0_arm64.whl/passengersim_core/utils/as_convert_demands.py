#
# Read in the Alaska mini-schedule demand data from Excel and write it out in YAML
#
# AlanW, 8/7/2024
# (c) PassengerSim LLC
#

from collections import defaultdict
import pandas as pd

# We use the fares to get the reference fare for the demand
fares_input_file = "/Users/alanw/projects/pxsim-clean/passengersim-core/data/AS_Mini_Fares_Final.xlsx"
z = pd.read_excel(fares_input_file,
                  sheet_name="Working",
                  skiprows=4,
                  names=["OD", "cxr", "distance", "WTP", "rt_restriction",
                         "Y0", "Y1", "Y2", "Y3", "Y4", "Y5", "Y6", "Y7", "Y8", "Y9", "Y10", "Y11",
                         "AP0", "AP1", "AP2", "AP3", "AP4", "AP5", "AP6", "AP7", "AP8", "AP9", "AP10", "AP11"])
reference_fares = defaultdict(float)
for index, p in z.iterrows():
    orig = p.OD[0:3]
    dest = p.OD[4:]
    price = p.Y11
    reference_fares[(orig, dest)] = price

input_file = "/Users/alanw/projects/pxsim-clean/passengersim-core/data/AS_Mini_Demand_Final.xlsx"
print("demands:")
z = pd.read_excel(input_file,
                  sheet_name="Final",
                  skiprows=2,
                  names=["Route", "Orig", "Dest", "NS_Distance", "Avg_Fare",
                         "WTP_BL", "WTP_PL", "WTP_VFR", "WTP_B", "WTP_PB",
                         "Avg WTP",
                         "Dmd_BL", "Dmd_PL", "Dmd_VFR", "Dmd_B", "Dmd_PB", "Dmd_Sum_Pax",
                         "AP_BL", "AP_PL", "AP_VFR", "AP_B", "AP_PB"])
total_demand = 0.0
for index, d in z.iterrows():
    for seg, choice_model in {"BL": "budget_leisure",
                              "PL": "premium_leisure",
                              "VFR": "visiting_friends_and_relatives",
                              "B": "business",
                              "PB": "premium_business"}.items():
        curve = "c1" if seg in ["B", "PB"] else "c2"
        ref = reference_fares[(d.Orig, d.Dest)]
        if seg in ["PL", "B"]:
            ref = ref * 2.5
        elif seg == "PB":
            ref = ref * 3
        print(f"  - orig: {d.Orig}")
        print(f"    dest: {d.Dest}")
        print(f"    segment: {seg}")
        print(f"    base_demand: {d['Dmd_'+seg]:.3f}")
        print(f"    reference_fare: {ref}")
        print(f"    curve: {curve}")
        print(f"    choice_model: {choice_model}")
        print(f"    distance: {d.NS_Distance:.2f}")
        total_demand += d['Dmd_'+seg]
print("")
# print(f"total_demand={int(total_demand)}")

