#
# Read in the Alaska mini-schedule fares data from Excel and write it out in YAML
#
# AlanW, 8/8/2024
# (c) PassengerSim LLC
#

import pandas as pd

fares_input_file = "/Users/alanw/projects/pxsim-clean/passengersim-core/data/AS_Mini_Fares_Final.xlsx"
z = pd.read_excel(fares_input_file,
                  sheet_name="Working",
                  skiprows=4,
                  names=["OD", "cxr", "distance", "WTP", "rt_restriction",
                         "Y0", "Y1", "Y2", "Y3", "Y4", "Y5", "Y6", "Y7", "Y8", "Y9", "Y10", "Y11",
                         "AP0", "AP1", "AP2", "AP3", "AP4", "AP5", "AP6", "AP7", "AP8", "AP9", "AP10", "AP11"])

carriers = ["AA", "AS", "B6", "DL", "UA", "WN"]
print("\nfares:")
for index, p in z.iterrows():
    orig = p.OD[0:3]
    dest = p.OD[4:]
    for i in range(12):
        price = p[f"Y{i}"]
        adv_purch = p[f"AP{i}"]
        print(f"  - carrier: {p.cxr}")
        print(f"    orig: {orig}")
        print(f"    dest: {dest}")
        print(f"    booking_class: Y{i}")
        print(f"    price: {price}")
        print(f"    advance_purchase: {adv_purch}")
        rest = ["R1"] if p.rt_restriction == "Y" else []
        if 3 <= i <= 7:
            rest.append("R2")
        elif i > 7:
            rest.append("R3")
        if len(rest) == 0:
            print(f"    restrictions: []")
        else:
            print(f"    restrictions:")
            for r in rest:
                print(f"     - {r}")

