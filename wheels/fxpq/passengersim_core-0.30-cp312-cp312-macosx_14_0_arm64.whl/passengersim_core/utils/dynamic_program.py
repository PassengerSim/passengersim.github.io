import timeit

import numba as nb
import numpy as np


@nb.njit(boundscheck=False, fastmath=True)
def dp(
    capacity: int,
    fares: np.ndarray,
    arrival_rates: np.ndarray,
    n_discrete_time_slices: int = 0,
    arrivals_per_time_slice: float = 0.05,
    return_full_emsr: bool = False,
):
    """
    Dynamic program to compute booking limits.

    Parameters
    ----------
    capacity : int
        Total capacity remaining on this flight at start of process.
    fares : 1-d array of float, shape=[n_fares]
        Fare classes (i.e. revenue per customer)
    arrival_rates : 2-d array of float, shape=[n_fares, n_dcps]
        Average number of customers for each face product arriving in
        each time period (assume poisson arrival process)
    n_discrete_time_slices : int, optional
        Number of time slices to use within each DCP to approximate
        discrete arrivals
    arrivals_per_time_slice : float, optional
    return_full_emsr : bool, default False

    Returns
    -------
    nested_booking_limit : array of int [n_fares, n_time_periods]
        Nested booking limits
    """
    # establish dimensions
    n_fares = arrival_rates.shape[0]
    n_dcps = arrival_rates.shape[1]
    max_fare = np.max(fares)

    if n_discrete_time_slices > 0:
        # all DCPs have same number of discrete time slices
        n_slices = np.broadcast_to(np.full(1, n_discrete_time_slices, dtype=np.int32), (n_dcps,))
    else:
        # each DCP can have its own number of discrete time slices
        n_slices = np.zeros(n_dcps, dtype=np.int32)
        for t in range(n_dcps):
            n_slices[t] = np.ceil(np.sum(arrival_rates[:, t]) / arrivals_per_time_slice)

    # initialize revenue vector
    revenue = np.zeros(capacity + 1)
    revenue_next = np.zeros(capacity + 1)
    nested_booking_limit = np.zeros((n_fares, n_dcps), dtype=np.int32)
    if return_full_emsr:
        expected_marginal_revenue = np.zeros((capacity, n_dcps), dtype=np.float32)
    else:
        expected_marginal_revenue = np.zeros((capacity, 1), dtype=np.float32)

    arrival_prob = np.empty_like(arrival_rates, dtype=np.float32)
    for j in range(n_fares):
        for t in range(n_dcps):
            arrival_prob[j, t] = arrival_rates[j, t] / n_slices[t]

    no_arrival_prob = 1.0 - np.sum(arrival_prob, axis=0)

    for t in range(n_dcps):
        if return_full_emsr:
            emsr_t = t
        else:
            emsr_t = 0
            expected_marginal_revenue[:, emsr_t] = 0

        _sum_marginal = np.zeros(capacity)  # initialize sum of marginal revenue vector
        for _ in range(n_slices[t]):
            i = 0
            # start by initializing the revenue vector with no-arrivals value
            revenue_next[i] = no_arrival_prob[t] * revenue[i]
            # then add arrival prob for each fare class
            for j in range(n_fares):
                revenue_next[i] += arrival_prob[j, t] * np.maximum(revenue[i + 1] + fares[j], revenue[i])
            for i in range(1, capacity):
                # start by initializing the revenue vector with no-arrivals value
                revenue_next[i] = no_arrival_prob[t] * revenue[i]
                # then add arrival prob for each fare class
                for j in range(n_fares):
                    revenue_next[i] += arrival_prob[j, t] * np.maximum(revenue[i + 1] + fares[j], revenue[i])
                expected_marginal_revenue[i - 1, emsr_t] += revenue_next[i - 1] - revenue_next[i]
            # add marginal revenue to the sum vector
            expected_marginal_revenue[-1, emsr_t] += revenue_next[-2] - revenue_next[-1]
            # swap revenue vector references, which is faster than copying
            revenue, revenue_next = revenue_next, revenue
        # average marginal revenue for DCP
        expected_marginal_revenue[:, emsr_t] /= n_slices[t]
        # address numerical issues on max fare
        expected_marginal_revenue[:, emsr_t] = np.minimum(expected_marginal_revenue[:, emsr_t], max_fare)
        nested_booking_limit[:, t] = np.searchsorted(expected_marginal_revenue[:, emsr_t], fares, side="right")
    return nested_booking_limit, expected_marginal_revenue


if __name__ == "__main__":
    # fares = np.array([500, 400, 300, 250])
    # arrival_rate = np.array(
    #     [
    #         [3, 5, 4, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    #         [3, 5, 4, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    #         [4, 8, 10, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    #         [2, 4, 20, 26, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    #     ]
    # )
    # capacity = 40
    fares = np.array([400, 300, 250])
    arrival_rate = np.array(
        [
            [
                6,
                10,
                8,
                2,
            ],
            [
                4,
                8,
                10,
                10,
            ],
            [
                2,
                4,
                20,
                26,
            ],
        ]
    )
    capacity = 40
    nested_booking_limit, expected_marginal_revenue = dp(capacity, fares, arrival_rate, return_full_emsr=True)
    print(nested_booking_limit)
    print(expected_marginal_revenue)

    n = 200
    runtime = timeit.repeat(
        "dp(capacity, fares, arrival_rate, 0)",
        globals=globals(),
        number=n,
        repeat=5,
    )
    print(", ".join(f"{r/n*1000:.2f} msecs" for r in runtime))
