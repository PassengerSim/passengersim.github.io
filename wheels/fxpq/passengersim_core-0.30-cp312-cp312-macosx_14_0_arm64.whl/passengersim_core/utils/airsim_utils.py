#
# Some Python utility functions to help build simulation models
#
# Alan Walker, Feb 2022
# (c) PassengerSim LLC
#

from datetime import datetime, timedelta, UTC
import calendar
import math
import numpy as np
from scipy.stats import norm
import time

from passengersim_core import Event, Fare


def great_circle(lat1, lon1, lat2, lon2):
    """Using Haversine formula, to get nautical miles"""
    x1 = math.radians(lon1)
    y1 = math.radians(lat1)
    x2 = math.radians(lon2)
    y2 = math.radians(lat2)
    a = math.sin((x2 - x1) / 2.0) ** 2.0 + (math.cos(x1) * math.cos(x2) * (math.sin((y2 - y1) / 2.0) ** 2.0))
    angle2 = 2.0 * math.asin(min(1.0, math.sqrt(a)))
    # Convert back to degrees.
    angle2 = math.degrees(angle2)
    # Each degree on a great circle of Earth is 60 nautical miles.
    distance2 = 60.0 * angle2
    return distance2


def get_mileage(airports: dict, orig: str, dest: str):
    """Get the distance between two airports
    Expects a dictionary of airports"""
    if orig not in airports or dest not in airports:
        return 0
    a1 = airports[orig]
    a2 = airports[dest]
    dist = great_circle(a1.latitude, a1.longitude, a2.latitude, a2.longitude)
    return dist


def insert_sep(sep, *args):
    """Format a CSV line"""
    buf = ""
    for a in args:
        buf = buf + str(a) if buf == "" else buf + sep + str(a)
    return buf


# #####################################################################################################
# Converting to and from Unix timestamps to various formats in the files we need to process
# - PassengerSim's internal format is a Unix timestamp (seconds since 1970-01-01
def decimal_time_to_ts(dec_time, base_date=0):
    tmp = float(dec_time)
    hh = int(tmp) * 3600
    mm = (tmp - int(tmp)) * 3600
    ts = hh + mm + base_date
    return int(ts)


def ts_to_time(ts):
    """Return the time from the timestamp as a string in HH:MM format"""
    day_offset = ts % 86400
    hh = int(day_offset / 3600)
    mm = int((day_offset - hh * 3600) / 60)
    return f"{hh:02d}:{mm:02d}"


def iso_to_unix(s, assume_utc=True):
    """Convert ISO datetime directly to Unix timestamp"""
    tmp = datetime.fromisoformat(s)
    if assume_utc and tmp.tzinfo is None:
        tmp = tmp.replace(tzinfo=UTC)
    return int(calendar.timegm(tmp.utctimetuple()))


def createTS(base_date, offset, hh, mm):
    """Create Unix time from base date, offset (days) and time"""
    td = timedelta(days=offset, hours=hh, minutes=mm)
    tmp = base_date + td
    # print("createTS", base_date, offset, hh, mm, tmp)
    return int(time.mktime(tmp.timetuple()))


def ts_from_hhmm(_str_time, _base_date, offset=0):
    dep_time_str = _str_time.split(":")
    hh, mm = int(dep_time_str[0]), int(dep_time_str[1])
    ts = createTS(_base_date, offset, hh, mm)
    return ts


def compute_days_prior(sim, dep_time):
    dep_day = int(dep_time / 86400)
    curr_day = int(sim.last_event_time / 86400)
    days_prior = dep_day - curr_day
    if sim.num_events() == 0:
        days_prior = 0
    return days_prior


def parse_array(data, cast_int=False):
    if isinstance(data, str):
        z = data.split()
    else:
        z = data
    a = [float(tmp) for tmp in z]
    if cast_int:
        a = [int(x) for x in a]
    return a


def add_dcp(sim, base_time, date_offset, dcp_list, debug=False):
    """Pushes an event per reading day (DCP) onto the queue
    Could move this to the core C++ code, but really no need to.
    This event occurs 2 seconds before midnight on the specified date."""
    for dcp_index, dcp in enumerate(dcp_list):
        if dcp == 0:
            continue
        event_time = sim.base_time - dcp * 86400 + 3600 * 6
        # tmp = datetime.fromtimestamp(event_time, tz=timezone.utc)
        # print(f"Added DCP {dcp} at {tmp.strftime('%Y-%m-%d %H:%M:%S %Z')}")
        info = ("DCP", dcp, dcp_index)
        rm_event = Event(info, event_time)
        if debug:
            print("Event = ", rm_event)
        sim.add_event(rm_event)


def print_info(sim):
    print(f"Iteration {sim.iteration}, Revenue = {sim.revenue}")
    for m in sim.demands:
        print(f"    {m.orig}-{m.dest}:{m.segment}  Sold = {m.sold},  Rev = {m.revenue}")
    for s in sim.legs:
        print(f"    {s.orig}-{s.dest}:{s.carrier}  Sold = {s.sold}")


# #####################################################################################################
# Some math and stat utility stuff
#
def gamma_demand(mu, sigma=None, cv100=0.3):
    """Generate random gamma deviate for demand"""
    if sigma is None:
        sigma = cv100 * math.sqrt(mu) * 10.0
    dmd = np.random.gamma(shape=(mu**2) / (sigma**2), scale=(sigma**2) / mu)
    return dmd


def expected_traffic(alloc, demand, sigma=None, cv100=0.3):
    """Implementation of the Boeing Spill Model
    Uses Normal distributions"""
    mu = demand / alloc
    if sigma is None:
        sigma = cv100 * math.sqrt(demand) * 10.0
    sigma = sigma / alloc

    # Normalize the distribution
    z = (1.0 - mu) / sigma
    cdf = norm.cdf(z)
    pdf = norm.pdf(z)

    # x1 is E(D|D<C)
    x1 = mu - sigma * pdf / cdf

    # x2 is P(D<C)
    x2 = cdf

    # x3 is P(D>C)
    x3 = 1.0 - x2

    # E(Traffic) = E(D|D<C).P(D<C) + C.P(D>C)
    traffic = alloc * (x1 * x2 + x3)

    # Make sure the answer's not silly!
    traffic = min(traffic, demand)
    traffic = min(traffic, alloc)
    return traffic


def create_fares(dmd, debug=False):
    """Use the average price of the demand segment to create fares
    Only really works when we have 1 segment per O&D
    Will come up with something better in the future"""
    pcts = {"Y": 200, "B": 160, "M": 120, "H": 100, "Q": 75}
    dmd.reference_fare = 10000
    for bkg_class, p in pcts.items():
        price = int(dmd.price * (p / 100.0))
        f = Fare("", dmd.orig, dmd.dest, bkg_class, price)
        dmd.add_fare(f)
        if f.price < dmd.reference_fare:
            dmd.reference_fare = f.price
        if debug:
            print(f)


# #####################################################################################################
# Some demo calls with the code
#
if __name__ == "__main__":
    print("Sample Boeing Spill Model outputs")
    print(50, 100, expected_traffic(50, 100))
    print(50, 80, expected_traffic(50, 80))
    print(60, 80, expected_traffic(60, 80))
    print(70, 80, expected_traffic(70, 80))
