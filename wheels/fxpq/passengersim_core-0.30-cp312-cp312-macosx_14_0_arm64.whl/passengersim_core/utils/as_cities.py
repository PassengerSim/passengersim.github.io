#
# Read in the Alaska mini-schedule, get the unique airport list and then generate a places file
#
# AlanW, 8/6/2024
# (c) PassengerSim LLC
#

import math
import pandas as pd

airlines = ["AA", "AS", "B6", "DL", "UA", "WN"]
schedule_file = "/Users/alanw/projects/pxsim-clean/passengersim-core/data/AS_Mini_Network_All_Airlines.xlsx"
airports_file = "/Users/alanw/projects/pxsim-clean/passengersim-core/data/airports.csv"

unique_airports = set()

def format_time(t):
    hh = int(t / 100)
    mm = int(t % 100)
    return f"{hh}:{mm:02d}"


for cxr in airlines:
    z = pd.read_excel(schedule_file, sheet_name=cxr)
    for index, d in z.iterrows():
        unique_airports.add(d.Origin)
        unique_airports.add(d.Destination)

missing_state = []
print("places:")
apts = pd.read_csv(airports_file, header=0)
for index, row in apts.iterrows():
    apt = row.code
    if row.country_code == "US" and isinstance(row.state_name, float):
        missing_state.append(apt)
    if apt in unique_airports:
        print(f"  {apt}:")
        print(f"    label: {row.apt_name}")
        print(f"    country: {row.country_code}")
        print(f"    state: {row.state_name}")
        print(f"    lat: {row.latitude}")
        print(f"    lon: {row.longitude}")
        print(f"    time_zone: {row.time_zone}")

pass

