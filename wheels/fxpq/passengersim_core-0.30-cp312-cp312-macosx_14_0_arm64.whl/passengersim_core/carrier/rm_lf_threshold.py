#
# Load Factor Threshold
#
# Alan W, October 2022
# (c) PassengerSim LLC
#

from typing import Any, Literal

from passengersim_core import SimulationEngine
from passengersim.rm_steps import RmStep

# from line_profiler_pycharm import profile


# ------ RM STEP, USED TO PLUG THIS INTO THE SYSTEM -----------------------------------------------


class LfThresholdStep(RmStep):
    snapshot_filters: list[Any] = []
    step_type: Literal["lfthreshold"]
    kind: Literal["leg"] = "leg"
    algorithm: Literal["lf_target", "leg_rev_max", "beta_fit"]

    @property
    def requires(self) -> list[str]:
        return []

    def serialize(self):
        return {
            "step_type": "lfthreshold",
            "name": self.name,
            "algorithm": self.algorithm,
            "kind": self.kind,
        }

    def run(self, sim: SimulationEngine, carrier, _dcp_index=0, _days_prior=0, debug=False):
        if sim.sample < sim.rm_start_sample:  # or sim.num_events() > 0:
            return

        # What load factor curve are we using?
        lfc = None
        for a in sim.carriers:
            if a.name == carrier:
                lfc = a.load_factor_curve
                break
        if lfc is None:
            raise Exception("Load factor curve not found")

        for leg in sim.legs:
            if leg.carrier_name != carrier:
                continue

            load_factor = leg.sold / leg.capacity
            for bkt in leg.buckets:
                bkt.alloc = leg.capacity
                if bkt.name not in lfc.curve:
                    raise Exception(f"No threshold found for bucket {bkt.name} in LF Curve {lfc.name}")
                threshold = lfc.curve[bkt.name]
                if load_factor > threshold:
                    bkt.force_closed = True
                else:
                    bkt.force_closed = False

            if sim.snapshot_filters is not None:
                snapshot_filters = sim.snapshot_filters
                for sf in snapshot_filters:
                    if sf.type == "rm":
                        sf.run(sim, leg=leg)


if __name__ == "__main__":
    print("Hello World")
