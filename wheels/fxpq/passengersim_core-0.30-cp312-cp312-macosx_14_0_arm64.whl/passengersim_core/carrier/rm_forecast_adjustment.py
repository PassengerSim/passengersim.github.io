#
# Adjust forecasts at the Path & PathClass level
#  - Mostly used for bid price controls without a gradient (i.e. ProBP optimizer)
#
# Alan W, October 2023
# (c) PassengerSim LLC
#

from passengersim.rm_steps import RmStep
from typing import Any, Literal
from passengersim.snapshot import get_snapshot_instruction


# ------ RM STEP, USED TO PLUG THIS INTO THE SYSTEM -----------------------------------------------
#
class ForecastAdjustmentStep(RmStep):
    step_type: Literal["forecastadjustment"]
    algorithm: Literal["days_to_departure", "timeframe"]
    kind: Any | None
    alpha: float = 0.15  # Not actually used for forecast adjustment

    @property
    def requires(self):
        return []

    @property
    def produces(self):
        return ["path_forecast"]

    def serialize(self):
        return {
            "step_type": "forecastadjustment",
            "name": self.name,
            "algorithm": self.algorithm,
            "kind": self.kind,
        }

    def run(
        self,
        sim,
        carrier: str,
        dcp_index: int | None = None,
        days_prior: int | None = None,
        debug: bool = False,
    ):
        if sim.sample < 3:
            return

        if debug:
            print(f"Forecast adjustment, sample={sim.sample}, {carrier=}, {days_prior=}")

        current_ts = sim.last_event_time
        for p in sim.paths:
            if p.get_leg_carrier(0) == carrier:
                snapshot_instruction = get_snapshot_instruction(sim, path=p, only_type="forecast_adj", debug=debug)
                snapshot_instruction.mode = "a"
                last_fcst_ts = p.last_fcst_ts
                departure_ts = sim.base_time

                # When does this timeframe end?
                end_tf_ts = departure_ts
                tf_remaining_days = -1
                if (dcp_index + 1) <= sim.num_dcps:
                    tf_remaining_days = days_prior - sim.get_days_prior(dcp_index + 1)
                    end_tf_ts = current_ts + tf_remaining_days * 86400
                if tf_remaining_days < 0:
                    raise RuntimeError("tf_remaining_days is negative")
                p.adjust_forecasts(
                    self.algorithm, last_fcst_ts, current_ts, end_tf_ts, departure_ts, snapshot_instruction
                )
                p.adjusted_at = current_ts
