#
# Runs all the RM components end-to-end
#
# Alan W, February 2023
# (c) PassengerSim LLC
#

from collections import defaultdict


class Rm_System:
    def __init__(self, _name=""):
        self.name = _name
        self.processes = defaultdict(list)
        self.availability_control = "none"

    def add_process(self, _process_name, _step_list):
        """Add a process to the RM pipeline, and check that the steps are compatible"""
        available_data = []
        for s in _step_list:
            # Check inputs to this step
            for input_data in s.requires:
                if input_data not in available_data:
                    raise Exception(f"Step: {s.name} requires {input_data}")
            # What does this step output?
            for output_data in s.produces:
                available_data.append(output_data)
        self.processes[_process_name] = _step_list

    def add_parm(self, p1, p2):
        """Used by the file loader
        Parameter is passed to the last step that was added"""
        if len(self.processes) == 0:
            raise Exception("No steps in the RM System, cannot add parameter")
        self.processes[-1].add_parm(p1, p2)

    def run(self, sim, carrier, dcp_index=0, days_prior=0, event_type="DCP"):
        event_type = event_type.lower()
        if event_type in self.processes:
            step_list = self.processes[event_type]
            for s in step_list:
                s.run(sim, carrier, dcp_index, days_prior)
