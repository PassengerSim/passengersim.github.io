#
# Adjust forecasts at the Path & PathClass level
#  - Mostly used for bid price controls without a gradient (i.e. ProBP optimizer)
#
# Alan W, October 2023
# (c) PassengerSim LLC
#

from passengersim.rm_steps import RmStep
from typing import Any, Literal


# ------ RM STEP, USED TO PLUG THIS INTO THE SYSTEM -----------------------------------------------
#
class FareAdjustmentStep(RmStep):
    step_type: Literal["fareadjustment"]
    algorithm: Literal["ki", "mr"]
    kind: Any | None
    alpha: float | None = 0.15  # Not actually used for fare adjustment
    frat5: str

    @property
    def requires(self):
        return ["path_forecast"]

    @property
    def produces(self):
        return ["path_forecast"]

    def serialize(self):
        return {
            "step_type": "fareadjustment",
            "name": self.name,
            "algorithm": self.algorithm,
            "kind": self.kind,
        }

    def run(self, sim, _carrier, _dcp_index, _days_prior, _debug=False):
        if sim.sample < 3:
            return

        if _debug:
            print("Fare adjustment, sample = ", sim.sample, ", carrier = ", _carrier)

        # Get the curve we're going to use
        f5 = None  # Frat5("test")
        for a in sim.carriers:
            if a.name == _carrier:
                f5 = a.frat5
                if f5 is None:
                    raise Exception("Must have a Frat5 curve to use Fare Adjustment")
                break
        if _dcp_index >= f5.num_values:
            return

        # Once I'm happy with the algorithm, I'll probably migrate these loops into C++ for performance
        for dmd in sim.demands:
            # Only do this for the specified carrier
            tmp_fares = [f for f in dmd.fares if f.carrier_name == _carrier]

            # Highest fare doesn't get adjusted, this just simplifies reporting...
            f = tmp_fares[0]
            f.adjust_price(_dcp_index, f.price)

            lo_fare = tmp_fares[-1].price

            # Snapshot filter just figures out if we want to print data, all the output is in Python for this step
            filter = None
            if sim.snapshot_filters is not None:
                snapshot_filters = sim.snapshot_filters
                for sf in snapshot_filters:
                    if sf.type == "fare_adj":
                        filter = sf.run(sim, carrier=_carrier, orig=dmd.orig, dest=dmd.dest)

            if filter is not None and filter.trigger:
                debug = True
                f5_ratio = f5.get_val(_dcp_index)
                fa_f5 = 1.0 + f5.fare_adjustment_scale * (f5_ratio - 1.0)
                print(
                    f"Fare adj: {_carrier}, {dmd.orig}-{dmd.dest}, "
                    f"sample={sim.sample}, dcp_index={_dcp_index}, f5_ratio={f5_ratio}, fa_f5={fa_f5:5.3f}"
                )
                print("     Cls   Price    PSup   AdjPrice")
                psup = f5.sellup_probability(_dcp_index, f.price, lo_fare)
                print(f"     {f.booking_class}   {f.price:6.2f}  {psup:6.2f}   {f.price:6.2f}")
            else:
                debug = False

            for j in range(1, len(tmp_fares)):
                f = tmp_fares[j]
                tgt_fare = f.price
                if self.algorithm == "mr":
                    adj_fare = f5.adjust_fare_mr(_dcp_index, tgt_fare, lo_fare)
                elif self.algorithm == "ki":
                    next_higher_fare = tmp_fares[j - 1].price
                    adj_fare = f5.adjust_fare_ki(_dcp_index, tgt_fare, next_higher_fare, lo_fare)
                else:
                    raise ValueError(f"Unknown algorithm for Fare Adjustment, '{self.algorithm}'")
                adj_fare = max(adj_fare, 0.0)
                f.adjust_price(_dcp_index, adj_fare)
                if debug:
                    psup = f5.sellup_probability(_dcp_index, f.price, lo_fare)
                    print(f"     {f.booking_class}   {tgt_fare:6.2f}  {psup:6.2f}   {adj_fare:6.2f}")
