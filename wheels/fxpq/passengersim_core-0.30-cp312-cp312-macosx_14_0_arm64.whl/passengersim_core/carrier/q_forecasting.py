#
# Q-Forecasting
# Apply FRAT5 curves to get Q equivalent demand, as well as parse demand to bucket_number level
#
# Alan W, November 2022
# (c) PassengerSim LLC
#

from Bucket import Bucket
from Leg import Leg


class Frat5:
    """Quick and dirty Frat5 curve"""

    def __init__(self):
        self.curve = {"Y": 0.10, "B": 0.25, "M": 0.45, "V": 0.70, "Q": 1.0}


def equivalent_q(leg, frat5):
    """Use the FRAT5 curve to convert bucket_number demands to Q equivalent demand"""
    q_equiv = 0.0
    for b in leg.buckets:
        q_equiv += b.sold / frat5.curve.get(b.name, 1.0)
    return q_equiv


def repartition_q(leg, frat5, q_equiv):
    """Use the FRAT5 curve to parse the Q-equivalent demand forecast into buckets"""
    prev_p = 0.0
    for b in leg.buckets:
        p = frat5.curve.get(b.name, 1.0)
        mult = p - prev_p
        b.fcst_mean = q_equiv * mult
        prev_p = p


if __name__ == "__main__":
    # Run a simple demo / test of the code.  The unit tests will have more cases
    leg = Leg(1, "XX", 123, "SAN", "LAX", capacity=150, duration=60)
    leg.add_bucket(Bucket("Y", 100, 200, revenue=275, sold=5))
    leg.add_bucket(Bucket("B", 90, 200, revenue=173, sold=10))
    leg.add_bucket(Bucket("M", 80, 200, revenue=122, sold=20))
    leg.add_bucket(Bucket("V", 70, 200, revenue=93, sold=30))
    leg.add_bucket(Bucket("Q", 60, 200, revenue=66, sold=35))

    f5 = Frat5()
    eq = equivalent_q(leg, f5)
    print(f"Equivalent Q demand = {round(eq, 1)}")

    fcst = 215.0
    repartition_q(leg, f5, fcst)

    for b in leg.buckets:
        print(f"Dmd for {b.name} = {round(b.fcst_mean, 1)}")
