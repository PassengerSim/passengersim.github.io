#
# Leg optimzation, using EMSR
#
# Alan W, October 2022
# (c) PassengerSim LLC
#

import math
from math import floor, sqrt
from statistics import NormalDist
from scipy.stats import gamma
from typing import Any, Literal

from passengersim_core import SimulationEngine, Leg
from passengersim.rm_steps import RmStep

# from line_profiler_pycharm import profile


# ------ RM STEP, USED TO PLUG THIS INTO THE SYSTEM -----------------------------------------------


class FcfsStep(RmStep):
    snapshot_filters: list[Any] = []
    step_type: Literal["fcfs"]

    def serialize(self):
        return {
            "step_type": "fcfs",
            "name": self.name,
        }

    def run(self, sim: SimulationEngine, carrier: str, dcp_index: int = 0, dcp: int = 0, debug: bool = False):
        if sim.sample < sim.rm_start_sample:
            return
        for leg in sim.legs:
            assert isinstance(carrier, str)
            if leg.carrier_name != carrier:
                continue
            cap = leg.capacity
            for bkt in leg.buckets:
                bkt.alloc = cap
            if sim.snapshot_filters is not None:
                snapshot_filters = sim.snapshot_filters
                for sf in snapshot_filters:
                    if sf.type == "rm":
                        sf.run(sim, leg=leg)


class EmsrStep(RmStep):
    snapshot_filters: list[Any] = []
    step_type: Literal["emsr"]
    kind: Literal["leg"] = "leg"
    """
    EMSR (Expected Marginal Seat Revenue) is a leg-based optimization algorithm.

    The `kind` parameter is included in the interface for compatability, but setting
    any value here other than `leg` will result in an error.
    """

    algorithm: Literal["a", "b", "emsra", "emsrb", "emsrg"]
    """
    Which variant of the EMSR optimization algorithm should be applied.

    Currently the "A" and "B" variants are implemented.
    The "G" variant is EMSRb using a Gamma distribution (experimental)
    """

    @property
    def requires(self) -> list[str]:
        return ["leg_forecast"]

    def serialize(self):
        return {
            "step_type": "emsr",
            "name": self.name,
            "algorithm": self.algorithm,
            "kind": self.kind,
        }

    def run(self, sim: SimulationEngine, carrier: str, _dcp_index: int = 0, _days_prior: int = 0, debug: bool = False):
        if sim.sample < 10:  # or sim.num_events() > 0:
            return

        assert isinstance(carrier, str)
        for leg in sim.legs:
            if leg.carrier_name != carrier:
                continue

            # self.compute_decision_fares(leg)
            self.static_decision_fares(leg)

            if self.algorithm == "emsra":
                emsr_a(leg)
            elif self.algorithm == "emsrb":
                leg.emsrb(False)
            elif self.algorithm == "emsrg":
                emsr_b(leg, False, False, use_gamma=True)
            else:
                raise Exception(f"Unknown EMSR algorithm: {self.algorithm}")

            if sim.snapshot_filters is not None:
                snapshot_filters = sim.snapshot_filters
                for sf in snapshot_filters:
                    if sf.type == "rm":
                        sf.run(sim, leg=leg)

    def static_decision_fares(self, leg):
        pass

    def compute_decision_fares(self, leg):
        for bkt in leg.buckets:
            if bkt.revenue > 0:
                bkt.fcst_revenue = 0.85 * bkt.fcst_revenue + 0.15 * bkt.revenue / bkt.sold


# ------ RM OPTIMIZATION ALGORITHMS --------------------------------------------------------------------
#
def littlewood(mu, sigma, rev_low, rev_hi, cv100=0.2, use_gamma=False):
    # print("littlewood", mu, sigma, rev_low, rev_hi)
    # In case I don't have standard deviation, use cv100
    if sigma is None or sigma < 0.001:
        sigma = cv100 * sqrt(mu) * 10.0

    if mu <= 0.01:
        return 0

    # Beware of fare inversions
    if rev_low >= rev_hi or rev_low < 1:
        prot = 0.0
    #        print(f"*** Fare Inversion, rev_lo = {rev_low}, rev_hi = {rev_hi}")
    else:
        z = 1.0 - rev_low / rev_hi
        if use_gamma:
            var = sigma**2
            a = mu**2 / var
            b = var / mu
            prot = gamma.ppf(z, a, loc=0, scale=b)
            # print(f"    z={z}, a={a}, b={b}, prot={prot}")
        else:
            prot = NormalDist(mu=mu, sigma=sigma).inv_cdf(z)
    if math.isnan(prot):
        prot = 0.0
    return max(prot, 0.0)


def emsr_a(leg: Leg, theft_nesting: bool = False, debug: bool = False):
    """Compute protection level for each bucket_number, using EMSR-A.

    EMSR-A is a leg-based optimization algorithm, which calculates
    protection levels for a set of fare buckets, based on the number of
    tickets already sold and the expected number of future potential
    customers.

    Parameters
    ----------
    leg : passengersim.Leg
        The individual leg on which to calculate protection levels.
    theft_nesting : bool, default False
        This enables the theft nesting, which does ...
    debug : bool, default False
        Print additional debug information to stdout.  This should not
        change the computation at all, but may produce a lot of output
        in the run log.
    """
    remaining_cap = leg.capacity
    prot = 0
    allocs = []
    for j in range(leg.get_num_buckets() - 1):
        if theft_nesting:
            alloc = max(0, round(leg.capacity - prot))
        else:
            alloc = max(0, round(leg.capacity - (prot + leg.sold)))
        leg.bucket_number(j).alloc = alloc

        rev_low = leg.bucket_number(j + 1).fcst_revenue
        tot_prot = 0.0
        # Sum protections to this bucket_number
        for k in range(j + 1):
            b = leg.bucket_number(k)
            prot = littlewood(
                mu=b.fcst_mean,
                sigma=b.fcst_std_dev,
                rev_low=rev_low,
                rev_hi=b.fcst_revenue,
            )
            tot_prot += prot
            if debug:
                print(
                    f"Class {leg.bucket_number(j).name}, revLow={round(rev_low, 2)}, mu={round(b.fcst_mean, 2)},"
                    f" sigma={round(b.fcst_std_dev, 2)}, prot={round(prot, 2)}"
                )
        if debug:
            print(f"--- Tot prot = {round(tot_prot, 1)}")
        allocs.append(floor(remaining_cap))
        remaining_cap -= tot_prot

    # Whatever is left goes into the last bucket_number (no protection as nothing is below it)
    if theft_nesting:
        alloc = max(0, round(leg.capacity - prot))
    else:
        alloc = max(0, round(leg.capacity - (prot + leg.sold)))
    leg.bucket_number(leg.get_num_buckets() - 1).alloc = alloc
    allocs.append(floor(remaining_cap))

    if debug and leg.flt_no == 101:
        print("    Allocs = ", allocs)


def emsr_b(leg: Leg, theftNesting: bool = False, debug: bool = False, use_gamma=False):
    """Compute protection level for each bucket_number, using EMSR-B."""
    capacity = leg.capacity
    prot = 0.0  # if theftNesting else leg.sold
    for j in range(leg.get_num_buckets() - 1):
        if theftNesting:
            alloc = max(0, round(capacity - prot))
        else:
            alloc = max(0, math.floor(capacity - (prot + leg.sold)))
        leg.bucket_number(j).alloc = alloc

        # Get weighted average down to and including bucket_number j
        fare_num, fare_denom = 0.0, 0.0
        agg_mu, agg_sigma = 0.0, 0.0
        for k in range(j + 1):
            b = leg.bucket_number(k)
            fare_num += b.fcst_revenue * b.fcst_mean
            fare_denom += b.fcst_mean
            agg_mu += b.fcst_mean
            agg_sigma += b.fcst_std_dev**2
        agg_fare = fare_num / fare_denom if fare_denom > 0 else 0
        agg_sigma = sqrt(agg_sigma)
        rev_low = leg.bucket_number(j + 1).fcst_revenue

        prot = littlewood(mu=agg_mu, sigma=agg_sigma, rev_low=rev_low, rev_hi=agg_fare, cv100=0.2, use_gamma=use_gamma)
        # prot = round(prot)
        leg.bucket_number(j).protection = round(prot)
        if debug:
            print(
                f"Class {leg.bucket_number(j).name},"
                f" sold={leg.bucket_number(j).sold},"
                f" mu={round(leg.bucket_number(j).fcst_mean, 2)}"
                f" agg_fare={round(agg_fare, 2)}, rev_low={round(rev_low, 2)}, agg_mu={round(agg_mu, 2)},"
                f" agg_sigma={round(agg_sigma, 2)}, prot={round(prot, 2)}, auth={leg.bucket_number(j).alloc}"
            )

    # Whatever is left goes into the last bucket_number (no protection as nothing is below it)
    if theftNesting:
        alloc = max(0, round(capacity - prot))
    else:
        alloc = max(0, round(capacity - (prot + leg.sold)))
    leg.bucket_number(leg.get_num_buckets() - 1).alloc = alloc

    if debug:
        j = leg.get_num_buckets() - 1
        print(
            f"Class {leg.bucket_number(j).name},"
            f" sold={leg.bucket_number(j).sold}, mu={round(leg.bucket_number(j).fcst_mean, 2)}"
            f" agg_fare={round(agg_fare, 2)}, agg_mu={round(agg_mu, 2)},"
            f" agg_sigma={round(agg_sigma, 2)}, prot={0}, auth={leg.bucket_number(j).alloc}"
        )


if __name__ == "__main__":
    prot = littlewood(mu=19.15, sigma=81.9, rev_low=240.7, rev_hi=278.54)
    print("Test 1, prot = ", prot)
