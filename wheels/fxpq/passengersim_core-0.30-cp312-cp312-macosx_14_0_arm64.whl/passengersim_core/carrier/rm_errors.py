#
# Simulate forecast errors
#
# Alan W, August 2024
# (c) PassengerSim LLC
#

import numpy as np
from passengersim.rm_steps import RmStep
from typing import Any, Literal


# ------ RM STEP, USED TO PLUG THIS INTO THE SYSTEM -----------------------------------------------
#
class ErrorsStep(RmStep):
    step_type: Literal["errors"]
    # algorithm: Literal["loglog"]
    # kind: Any | None
    bias: float | None = 0.0
    k_factor: float | None = 0.3

    @property
    def requires(self):
        return []

    @property
    def produces(self):
        return []

    def serialize(self):
        return {
            "step_type": "errors",
            "name": self.name,
            "bias": self.boas,
            "k_factor": self.k_factor,
        }

    def run(self, sim, carrier_code, _dcp_index, _days_prior, _debug=False):
        rng = np.random.default_rng()
        if sim.sample < 3:
            return

        if _debug:
            print("Errors, sample = ", sim.sample, ", carrier = ", carrier_code)

        for leg in sim.legs:
            if leg.carrier_name != carrier_code:
                continue
            for bkt in leg.buckets:
                bkt.fcst_mean = max(self.get_new_fcst(rng, bkt.fcst_mean), 0.0)

        for path in sim.paths:
            if path.carrier != carrier_code:
                continue
            for pc in path.pathclasses:
                pc.fcst_mean = max(self.get_new_fcst(rng, pc.fcst_mean), 0.0)

    def get_new_fcst(self, rng, mean):
        mean_diff = self.bias * mean
        std_dev = abs(mean_diff) * self.k_factor
        new_fcst = mean + rng.normal(mean_diff, std_dev)
        return new_fcst

