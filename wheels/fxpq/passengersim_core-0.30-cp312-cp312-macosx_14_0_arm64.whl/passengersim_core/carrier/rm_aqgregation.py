#
# Aggregate path forecasts to the leg level
#
# Alan W, December 2022
# (c) PassengerSim LLC
#

from typing import Literal

from passengersim_core import SimulationEngine
from passengersim.rm_steps import RmStep


# ------ RM STEP, USED TO PLUG THIS INTO THE SYSTEM -----------------------------------------------
#
class AggregationStep(RmStep):
    step_type: Literal["aggregation"]

    @property
    def requires(self) -> list[str]:
        return ["path_forecast"]

    @property
    def produces(self) -> list[str]:
        return ["leg_forecast"]

    def run(
        self,
        sim: SimulationEngine,
        carrier: str,
        _dcp_index: int = 0,
        _days_prior: int = 0,
        debug: bool = False,
    ):
        if sim.sample < 3:
            return

        if debug:
            print("Aggregating, sample = ", sim.sample, ", carrier = ", carrier)

        sim.path_2_leg(carrier)
        return
