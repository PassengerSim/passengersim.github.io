#
# EMSRb, but cabin
#
# THIS IS TEMPORARY, WHILE I AM TESTING MULTI-CABIN !!!
#
# Alan W, October 2022
# (c) PassengerSim LLC
#

from typing import Any, Literal

from passengersim_core import SimulationEngine, EMSR
from passengersim.rm_steps import RmStep

# from line_profiler_pycharm import profile


# ------ RM STEP, USED TO PLUG THIS INTO THE SYSTEM -----------------------------------------------


class CabinStep(RmStep):
    snapshot_filters: list[Any] = []
    step_type: Literal["cabin"]
    kind: Literal["leg"] = "leg"
    """
    EMSR (Expected Marginal Seat Revenue) is a leg-based optimization algorithm.

    The `kind` parameter is included in the interface for compatability, but setting
    any value here other than `leg` will result in an error.
    """

    algorithm: Literal["a", "b", "emsra", "emsrb", "emsrg"]
    """
    Which variant of the EMSR optimization algorithm should be applied.

    Currently the "A" and "B" variants are implemented.
    The "G" variant is EMSRb using a Gamma distribution (experimental)
    """

    @property
    def requires(self) -> list[str]:
        return ["leg_forecast"]

    def serialize(self):
        return {
            "step_type": "cabin",
            "name": self.name,
            "algorithm": self.algorithm,
            "kind": self.kind,
        }

    def run(self, sim: SimulationEngine, carrier, _dcp_index=0, _days_prior=0, debug=False):
        if sim.sample < 10:  # or sim.num_events() > 0:
            return

        opt = EMSR()
        for leg in sim.legs:
            if leg.carrier_name != carrier:
                continue

            # self.compute_decision_fares(leg)
            self.static_decision_fares(leg)

            for cabin in leg.cabins:
                opt.emsrb(cabin)

            if sim.snapshot_filters is not None:
                snapshot_filters = sim.snapshot_filters
                for sf in snapshot_filters:
                    if sf.type == "rm":
                        sf.run(sim, leg=leg)

    def static_decision_fares(self, leg):
        pass

    def compute_decision_fares(self, leg):
        for bkt in leg.buckets:
            if bkt.revenue > 0:
                bkt.fcst_revenue = 0.85 * bkt.fcst_revenue + 0.15 * bkt.revenue / bkt.sold
