if __name__ == "__main__":
    print("""\
Copyright (c) PassengerSim LLC, 2023
This in-development tool is not for public distribution.
""")
