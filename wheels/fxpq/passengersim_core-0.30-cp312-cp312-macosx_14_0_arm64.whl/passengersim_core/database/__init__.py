from pathlib import Path


def initialize_tables(conn):
    with open(Path(__file__).parent / "initialize_tables.sql") as f:
        script = f.read()
    conn.executescript(script)
    conn.commit()
