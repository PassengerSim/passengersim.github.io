#!/usr/bin/env -S uv run --script
#
# /// script
# requires-python = ">=3.12"
#
# [project]
# name = "gt-paxlab"
# ///
"""
gatech-paxlab.py — Automate connecting to the Georgia Tech Linux server
and launching Jupyter Lab via an SSH tunnel.

Steps performed automatically:
  1. Open a background SSH master connection (authenticates once — you may be
     prompted for your password here and only here).
  2. Run `update-paxlab.py` on the remote host to install or upgrade
     PassengerSim if a newer version is available in /opt/pax-installers.
  3. Check whether a Jupyter Lab server is already running on the remote host
     by calling `jupyter lab list`.  If one is found, its token and port are
     reused and no new server is started.
  4. If no server is running, start one by calling `~/server-paxlab` via nohup
     so that it keeps running even if the SSH connection later drops.  The
     server's output is redirected to ~/.paxlab-jupyter.log on the server, and
     the script tails that file until the token appears.
  5. Open an SSH port-forward tunnel (server port → localhost:LOCAL_PORT).
  6. Open the browser at http://localhost:LOCAL_PORT/lab?token=<TOKEN>.

Usage:
  python gatech-paxlab.py [GA_TECH_ID]

If GA_TECH_ID is not given on the command line the script falls back to
the GA_TECH_ID environment variable, then to a cached value from a previous
run, and finally prompts the user.

The server hostname and GT ID are cached between runs in a platform-specific
config file so that you are not prompted on every invocation:
  macOS  : ~/Library/Application Support/paxlab/config.json
  Linux  : $XDG_CONFIG_HOME/paxlab/config.json  (~/.config/paxlab/config.json)
  Windows: %APPDATA%\\paxlab\\config.json

The server hostname can also be overridden at any time via the
PAXLAB_SERVER_HOST environment variable.

The Jupyter root directory (--notebook-dir) defaults to the remote user's home
directory ("~") and can be overridden via the PAXLAB_NOTEBOOK_DIR environment
variable or by entering a different path when prompted.  The chosen value is
cached in the config file for future runs.

Password handling
-----------------
SSH connection multiplexing (ControlMaster / ControlPath) is used so that
all SSH connections in this script share a single authenticated session.
You are prompted for your password at most once (when the master connection
is established in step 1).  All later connections reuse the open socket and
never ask again.  The socket lives in a per-run temporary directory that is
deleted when the script exits, so nothing persists between runs and your
existing ~/.ssh/authorized_keys is never modified.

Jupyter server lifetime
-----------------------
The remote Jupyter server is started with nohup and runs in the background,
so it keeps running after this script exits (or if the SSH connection drops).
On the next run the script will detect the still-running server and connect
to it directly without starting a new one.
"""

from __future__ import annotations

import argparse
import json
import os
import platform
import re
import sys
import time
import tempfile
import shutil
import webbrowser
import subprocess
from pathlib import Path

# --------------------------------------------------------------------------- #
# Configuration
# --------------------------------------------------------------------------- #

LOCAL_PORT = 8999  # local port forwarded to the remote Jupyter port

# Path on the remote server where server startup output is logged.
# Using a fixed, predictable name lets subsequent runs tail the same log.
REMOTE_LOG = "~/.paxlab-jupyter.log"

# Token regex: matches a Jupyter URL in the server startup log or anywhere in
# free-form text, capturing (port, token).  Used when polling for a newly
# started server where we don't need to inspect the root directory.
TOKEN_RE = re.compile(r"http://localhost:([0-9]+)/.*\?token=([a-zA-Z0-9]{48})")

# Server-list regex: matches one entry from `jupyter lab list` output, which
# has the form:
#   http://localhost:8889/?token=<TOKEN> :: /resolved/root/dir
# Captures (port, token, root_dir).
SERVER_RE = re.compile(r"http://localhost:([0-9]+)/.*\?token=([a-zA-Z0-9]{48})\s*::\s*(\S+)")

# How long to wait (seconds) for the Jupyter token to appear in the log.
TOKEN_TIMEOUT = 120

# How long to wait (seconds) for the SSH master socket to be created.
MASTER_TIMEOUT = 60

# How long to wait (seconds) after the tunnel is opened before launching
# the browser, giving SSH time to finish negotiating the port forward.
TUNNEL_SETTLE = 2


# --------------------------------------------------------------------------- #
# Persistent config (hostname + GT ID cached between runs)
# --------------------------------------------------------------------------- #


def get_config_path() -> Path:
    """
    Return the platform-appropriate path for the paxlab config file.

    - macOS   : ~/Library/Application Support/paxlab/config.json
    - Windows : %APPDATA%/paxlab/config.json
    - Linux   : $XDG_CONFIG_HOME/paxlab/config.json  (default: ~/.config/…)
    """
    system = platform.system()
    if system == "Darwin":
        base = Path.home() / "Library" / "Application Support" / "paxlab"
    elif system == "Windows":
        appdata = os.environ.get("APPDATA")
        base = Path(appdata) / "paxlab" if appdata else Path.home() / "AppData" / "Roaming" / "paxlab"
    else:
        # Linux / other POSIX: respect the XDG Base Directory specification.
        xdg = os.environ.get("XDG_CONFIG_HOME", "").strip()
        base = Path(xdg) / "paxlab" if xdg else Path.home() / ".config" / "paxlab"
    return base / "config.json"


def load_config() -> dict:
    """Load the cached config from disk, returning an empty dict on any error."""
    path = get_config_path()
    if path.exists():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            pass  # corrupt file — start fresh
    return {}


def save_config(config: dict) -> None:
    """Persist *config* to disk, creating parent directories as needed."""
    path = get_config_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(config, indent=2), encoding="utf-8")
    except Exception as exc:
        # Non-fatal: warn but don't abort the script.
        print(f"  Warning: could not save config to {path}: {exc}", file=sys.stderr)


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #


def parse_args() -> argparse.Namespace:
    """
    Parse command-line arguments.

    Positional:
      gt_id        Georgia Tech ID (optional; falls back to env var / cached value / prompt)

    Optional:
      --token TOK  Connect directly to the Jupyter server identified by this token.
                   When given, the update check and notebook-dir selection are skipped;
                   the script looks for a running server with this exact token and
                   errors out if none is found.
    """
    parser = argparse.ArgumentParser(
        prog="gt-paxlab",
        description="Connect to a remote Jupyter Lab server on the Georgia Tech Linux cluster.",
        add_help=True,
    )
    parser.add_argument(
        "gt_id",
        nargs="?",
        default=None,
        help="Georgia Tech ID (e.g. jnewman32).  Falls back to GA_TECH_ID env var, cached value, or interactive prompt.",
    )
    parser.add_argument(
        "--token",
        metavar="TOKEN",
        default=None,
        help=(
            "Connect directly to the Jupyter server identified by this 48-character token.  "
            "Skips the PassengerSim update check and notebook-dir selection.  "
            "Exits with an error if no server with this token is currently running."
        ),
    )
    return parser.parse_args()


def get_gt_id(config: dict, cli_gt_id: str | None = None) -> str:
    """
    Resolve the Georgia Tech ID, in priority order:
      1. CLI positional argument (*cli_gt_id* from argparse)
      2. GA_TECH_ID environment variable
      3. Cached value from a previous run (user may accept or override)
      4. Interactive prompt
    """
    if cli_gt_id:
        return cli_gt_id
    env_id = os.environ.get("GA_TECH_ID", "").strip()
    if env_id:
        return env_id
    cached = config.get("gt_id", "").strip()
    if cached:
        response = input(f"Georgia Tech ID [{cached}]: ").strip()
        return response if response else cached
    return input("Enter your Georgia Tech ID: ").strip()


def get_server_host(config: dict) -> str:
    """
    Resolve the remote server hostname, in priority order:
      1. PAXLAB_SERVER_HOST environment variable
      2. Cached value from a previous run (user may accept or override)
      3. Interactive prompt
    """
    env_host = os.environ.get("PAXLAB_SERVER_HOST", "").strip()
    if env_host:
        return env_host
    cached = config.get("server_host", "").strip()
    if cached:
        response = input(f"Server hostname [{cached}]: ").strip()
        return response if response else cached
    return input("Enter the server hostname: ").strip()


def get_notebook_dir(config: dict) -> str:
    """
    Resolve the root directory for Jupyter (--notebook-dir), in priority order:
      1. PAXLAB_NOTEBOOK_DIR environment variable
      2. Cached value from a previous run (user may accept or override)
      3. Default to "~" (the user's home directory on the remote server)

    This value is passed to the remote Jupyter server via --notebook-dir so
    that notebooks open in the desired directory rather than the default.
    """
    env_dir = os.environ.get("PAXLAB_NOTEBOOK_DIR", "").strip()
    if env_dir:
        return env_dir
    cached = config.get("notebook_dir", "").strip()
    default = cached if cached else "~"
    if default == ".":
        default = "~"
    response = input(f"Jupyter root directory on server [{default}]: ").strip()
    return response if response else default


def follower_opts(control_path: str) -> list[str]:
    """Return SSH options that reuse an existing ControlMaster socket."""
    return ["-o", "ControlMaster=no", "-o", f"ControlPath={control_path}"]


def run_remote(args_ssh: list[str], cmd: str, *, timeout: int = 30) -> str:
    """
    Run *cmd* on the remote host via the existing master connection and return
    combined stdout+stderr as a string.  Raises RuntimeError on non-zero exit.
    """
    result = subprocess.run(
        [*args_ssh, cmd],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=timeout,
    )
    return result.stdout.decode(errors="replace")


def parse_token(text: str) -> tuple[str | None, str | None]:
    """
    Search *text* for a Jupyter Lab URL and return (token, port) or
    (None, None) if none is found.
    """
    match = TOKEN_RE.search(text)
    if match:
        return match.group(2), match.group(1)  # token, port
    return None, None


def resolve_remote_path(ssh_follower: list[str], path: str) -> str:
    """
    Expand *path* on the remote host and return its absolute form.

    Two transformations are applied:
      1. Tilde/shell expansion — ``echo {path}`` is evaluated inside a bash
         login shell, so "~" becomes the user's real home directory (e.g.
         "/home/jnewman32") and any other shell-expandable tokens are resolved.
      2. Absolute-path conversion — ``realpath -m`` turns relative paths into
         absolute ones (anchored at the current working directory of the login
         shell, which is the user's home directory).  The ``-m`` flag means the
         target path is not required to exist yet.

    Falls back to the original string if the remote call fails.
    """
    try:
        # `echo {path}` lets bash expand "~" (unquoted tilde expansion).
        # `realpath -m` then converts the result to an absolute path without
        # requiring the directory to already exist on the server.
        result = run_remote(ssh_follower, f"bash -lc 'realpath -m $(echo {path})'", timeout=10)
        resolved = result.strip()
        if resolved:
            return resolved
    except Exception:
        pass
    return path


def find_server_by_token(ssh_follower: list[str], token: str) -> str | None:
    """
    Search the list of running Jupyter Lab servers for one whose token matches
    *token* exactly.  Returns the port string if found, or None if no matching
    server is running.
    """
    print("  Running `jupyter lab list` on the server …", end="\r\n")
    try:
        output = run_remote(ssh_follower, "bash -lc 'uv run -p .paxlab jupyter lab list'", timeout=30)
    except Exception as exc:
        print(f"  Warning: `jupyter lab list` failed ({exc}).", end="\r\n")
        return None

    for line in output.splitlines():
        print(f"  [list] {line}", end="\r\n")
        match = SERVER_RE.search(line)
        if match and match.group(2) == token:
            return match.group(1)  # port

    return None


# --------------------------------------------------------------------------- #
# Main connection steps
# --------------------------------------------------------------------------- #


def establish_master(control_path: str, user_host: str) -> subprocess.Popen:
    """
    Start a background SSH master connection (-M -N) and wait until the
    ControlPath socket is created, indicating successful authentication.

    The returned process must be kept alive for as long as follower connections
    are needed; terminate it when finished.
    """
    master_proc = subprocess.Popen(
        # -M  : become the ControlMaster (create the shared socket)
        # -N  : do not execute a remote command; just keep the connection open
        # stdin is inherited so a password prompt (if any) is shown to the user
        ["ssh", "-M", "-N", "-o", f"ControlPath={control_path}", user_host],
    )

    print("      Waiting for SSH master connection …", end="\r\n")
    deadline = time.monotonic() + MASTER_TIMEOUT
    while not os.path.exists(control_path):
        if master_proc.poll() is not None:
            raise RuntimeError(
                "SSH master connection exited before the socket was created.\n"
                "Check your GT ID, VPN connection, and credentials."
            )
        if time.monotonic() > deadline:
            master_proc.terminate()
            raise RuntimeError("Timed out waiting for the SSH master connection.")
        time.sleep(0.25)

    print("      Master connection established.", end="\r\n")
    return master_proc


def check_existing_server(ssh_follower: list[str], resolved_notebook_dir: str) -> tuple[str | None, str | None]:
    """
    Ask the remote host for a list of running Jupyter Lab servers, print all
    of them so the user can see what is running, and return (token, port) of
    the first one whose root directory matches *resolved_notebook_dir*, or
    (None, None) if none matches.

    The root directory in `jupyter lab list` output is the fully-resolved
    absolute path (e.g. "/home/jnewman32"), so *resolved_notebook_dir* must
    already have tildes and variables expanded before being passed here.
    """
    print("  Running `jupyter lab list` on the server …", end="\r\n")
    try:
        # Use a login shell (-l) so that ~/.bash_profile / ~/.profile is sourced
        # and uv (typically in ~/.local/bin) is on PATH, even in a non-interactive
        # SSH session.
        output = run_remote(ssh_follower, "bash -lc 'uv run -p .paxlab jupyter lab list'", timeout=30)
    except Exception as exc:
        print(f"  Warning: `jupyter lab list` failed ({exc}); assuming no server.", end="\r\n")
        return None, None

    # Collect all running servers from the output so we can display them all.
    servers: list[tuple[str, str, str]] = []  # list of (port, token, root_dir)
    for line in output.splitlines():
        print(f"  [list] {line}", end="\r\n")
        match = SERVER_RE.search(line)
        if match:
            servers.append((match.group(1), match.group(2), match.group(3)))

    if not servers:
        return None, None

    # Print a summary of all running servers so the user can see what is active.
    print(f"\n  Found {len(servers)} running server(s):", end="\r\n")
    match_port: str | None = None
    match_token: str | None = None
    for port, token, root_dir in servers:
        marker = "✓" if root_dir == resolved_notebook_dir else " "
        print(f"    [{marker}] port {port}  root {root_dir}", end="\r\n")
        if root_dir == resolved_notebook_dir and match_port is None:
            match_port = port
            match_token = token

    return match_token, match_port


def start_server_and_get_token(
    ssh_follower: list[str], notebook_dir: str, resolved_notebook_dir: str
) -> tuple[str | None, str | None]:
    """
    Start ~/server-paxlab on the remote host via nohup so that it survives
    SSH disconnection, then poll `jupyter lab list` until a server with the
    correct root directory appears.

    *notebook_dir* is the raw value (possibly "~") passed as --notebook-dir
    to Jupyter.  *resolved_notebook_dir* is the same path after shell expansion
    (e.g. "/home/jnewman32") and is used to match the server in the list output,
    since `jupyter lab list` always reports the fully-resolved path.

    Returns (token, port) or (None, None) on failure.
    """
    # Launch the server in the background.  nohup prevents the process from
    # receiving SIGHUP when the SSH session ends, keeping it alive after exit.
    # Pass --notebook-dir so Jupyter opens in the configured root directory.
    start_cmd = f"bash -lc 'nohup uv run -p .paxlab jupyter lab --no-browser --notebook-dir=\"{notebook_dir}\" >> {REMOTE_LOG} 2>&1 &'"
    print(f"  Starting Jupyter Lab Server in {notebook_dir!r} …", end="\r\n")
    try:
        run_remote(ssh_follower, start_cmd, timeout=30)
    except Exception as exc:
        print(f"  Error starting server: {exc}", file=sys.stderr, end="\r\n")
        return None, None

    # Poll `jupyter lab list` until the server with the correct root registers
    # itself, or we time out.  We match on resolved_notebook_dir because the
    # list output always shows the fully-expanded absolute path.
    print(f"  Waiting for Jupyter server to start (up to {TOKEN_TIMEOUT}s) …", end="\r\n")
    deadline = time.monotonic() + TOKEN_TIMEOUT
    poll_interval = 5  # seconds between retries
    while time.monotonic() < deadline:
        time.sleep(poll_interval)
        try:
            output = run_remote(
                ssh_follower,
                "bash -lc 'uv run -p .paxlab jupyter lab list'",
                timeout=30,
            )
        except Exception:
            continue  # transient error; try again
        for line in output.splitlines():
            print(f"  [list] {line}", end="\r\n")
            match = SERVER_RE.search(line)
            if match:
                port, token, root_dir = match.group(1), match.group(2), match.group(3)
                if root_dir == resolved_notebook_dir:
                    return token, port
                else:
                    print(
                        f"  [list]   → skipping server at port {port} (root {root_dir!r} ≠ {resolved_notebook_dir!r})",
                        end="\r\n",
                    )

    print("  Timed out waiting for Jupyter server.", file=sys.stderr, end="\r\n")
    return None, None


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #


def main() -> None:
    # Parse command-line arguments first so --token can short-circuit prompts.
    args = parse_args()

    # Load cached settings (GT ID and server hostname) from the previous run.
    config = load_config()

    gt_id = get_gt_id(config, args.gt_id)
    if not gt_id:
        print("Error: Georgia Tech ID is required.", file=sys.stderr, end="\r\n")
        sys.exit(1)

    server_host = get_server_host(config)
    if not server_host:
        print("Error: server hostname is required.", file=sys.stderr, end="\r\n")
        sys.exit(1)

    # When --token is given we skip the notebook-dir prompt entirely.
    explicit_token: str | None = args.token
    if not explicit_token:
        notebook_dir = get_notebook_dir(config)
        config["notebook_dir"] = notebook_dir

    # Persist GT ID and server host (and notebook_dir when applicable) so the
    # user is not prompted on the next run.
    config["gt_id"] = gt_id
    config["server_host"] = server_host
    save_config(config)

    user_host = f"{gt_id}@{server_host}"

    # Per-run temporary directory for the SSH multiplexing socket.
    # mkdtemp creates it with mode 0700 (owner-only), keeping the socket private.
    # The directory is removed in the outer finally block no matter how we exit.
    socket_dir = tempfile.mkdtemp(prefix="ssh-paxlab-")
    control_path = os.path.join(socket_dir, "ctrl")

    # SSH args prepended to every follower invocation.
    ssh_follower = ["ssh", *follower_opts(control_path), user_host]

    master_proc = None
    tunnel_proc = None

    try:
        # ------------------------------------------------------------------ #
        # Step 1 — Authenticate once via the master connection
        # ------------------------------------------------------------------ #
        print(f"\n[1] Connecting to {user_host} …")
        print("    (You may be prompted for your password once.)\n")
        master_proc = establish_master(control_path, user_host)

        # ------------------------------------------------------------------ #
        # Step 2 — Update PassengerSim on the remote host (if a newer
        #           installer is available in /opt/pax-installers).
        #           Skipped when --token is given (fast-connect mode).
        # ------------------------------------------------------------------ #
        if explicit_token:
            print("\n[2] Skipping PassengerSim update check (--token supplied).", end="\r\n")
        else:
            print("\n[2] Checking for PassengerSim updates …", end="\r\n")
            try:
                # Run in a login shell so that ~/.bash_profile / ~/.profile is
                # sourced and uv (typically in ~/.local/bin) is on PATH.
                update_output = run_remote(
                    ssh_follower,
                    "bash -lc 'uv run python /opt/pax-installers/update-paxlab.py'",
                    timeout=300,  # installer download can take a while
                )
                for line in update_output.splitlines():
                    print(f"  [update] {line}", end="\r\n")
            except Exception as exc:
                print(f"  Warning: update check failed ({exc}); continuing anyway.", end="\r\n")

        # ------------------------------------------------------------------ #
        # Step 3 — Find/start the Jupyter server
        # ------------------------------------------------------------------ #
        if explicit_token:
            # Fast-connect mode: locate the server by token, ignoring the
            # working directory.  Error out if no matching server is found.
            print(f"\n[3] Looking for Jupyter server with token {explicit_token[:8]}… …", end="\r\n")
            remote_port = find_server_by_token(ssh_follower, explicit_token)
            if remote_port is None:
                print(
                    "\nNo running Jupyter server found with the supplied token.",
                    file=sys.stderr,
                    end="\r\n",
                )
                sys.exit(1)
            token = explicit_token
            print(f"\n  ✓ Found server on port {remote_port}.", end="\r\n")
        else:
            # Normal mode: check for an existing server matching the notebook
            # dir, or start a new one.
            print("\n[3] Checking for an existing Jupyter Lab server …", end="\r\n")

            # Resolve the notebook dir on the remote so that "~" becomes the real
            # absolute path (e.g. "/home/jnewman32") that `jupyter lab list` reports.
            print(f"  Resolving notebook dir {notebook_dir!r} on the server …", end="\r\n")
            resolved_notebook_dir = resolve_remote_path(ssh_follower, notebook_dir)
            print(f"  Resolved to: {resolved_notebook_dir}", end="\r\n")

            token, remote_port = check_existing_server(ssh_follower, resolved_notebook_dir)

            if token:
                print(f"\n  ✓ Found existing server on port {remote_port}.", end="\r\n")
                print("    Will reuse it — no new server will be started.", end="\r\n")
            else:
                print("\n  No running server found.", end="\r\n")
                print("  Starting a new one (it will keep running after this script exits) …\n", end="\r\n")
                token, remote_port = start_server_and_get_token(ssh_follower, notebook_dir, resolved_notebook_dir)

            if not token:
                print("\nFailed to obtain a Jupyter token.  See output above.", file=sys.stderr, end="\r\n")
                sys.exit(1)

        print(f"\n  Token : {token}", end="\r\n")
        print(f"  Port  : {remote_port}", end="\r\n")

        # ------------------------------------------------------------------ #
        # Step 4 — Port-forward tunnel (localhost:LOCAL_PORT → server:remote_port)
        # ------------------------------------------------------------------ #
        print(f"\n[4] Opening tunnel  localhost:{LOCAL_PORT} → {server_host}:{remote_port} …", end="\r\n")
        print("    (Reusing the authenticated session — no password needed.)", end="\r\n")

        tunnel_proc = subprocess.Popen(
            [
                "ssh",
                "-N",  # no remote command; just forward the port
                "-L",
                # Bind explicitly to 127.0.0.1 (IPv4) rather than the default "localhost",
                # which on Windows OpenSSH binds only to ::1 (IPv6).  Without this, browsers
                # that resolve "localhost" to 127.0.0.1 find nothing listening and report a
                # connection error even though the SSH tunnel itself is up.
                f"127.0.0.1:{LOCAL_PORT}:localhost:{remote_port}",
                *follower_opts(control_path),
                user_host,
            ]
        )

        time.sleep(TUNNEL_SETTLE)

        if tunnel_proc.poll() is not None:
            print("SSH tunnel exited unexpectedly.  Check your VPN / credentials.", file=sys.stderr, end="\r\n")
            sys.exit(1)

        # ------------------------------------------------------------------ #
        # Step 5 — Open the browser
        # ------------------------------------------------------------------ #
        # Use 127.0.0.1 explicitly to match the IPv4 tunnel binding above.
        url = f"http://127.0.0.1:{LOCAL_PORT}/lab?token={token}"
        print(f"\n[5] Opening browser at:\n    {url}\n", end="\r\n")
        webbrowser.open(url)

        # ------------------------------------------------------------------ #
        # Keep the tunnel alive until the user presses Ctrl-C
        # ------------------------------------------------------------------ #
        print(
            "\033[1;31m Press Ctrl-C to close the SSH tunnel (the Jupyter server will keep running). \033[0m\n",
            end="\r\n",
        )

        try:
            while True:
                if master_proc.poll() is not None:
                    print("\nSSH master connection has closed.", end="\r\n")
                    break
                if tunnel_proc.poll() is not None:
                    print("\nSSH tunnel has closed.", end="\r\n")
                    break
                time.sleep(1)
        except KeyboardInterrupt:
            print("\nShutting down tunnel …", end="\r\n")

    except RuntimeError as exc:
        print(f"\nError: {exc}", file=sys.stderr, end="\r\n")
        sys.exit(1)

    finally:
        # Close the tunnel and master connection, then remove the socket dir.
        for proc in (tunnel_proc, master_proc):
            if proc is None:
                continue
            try:
                proc.terminate()
                proc.wait(timeout=5)
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass
        shutil.rmtree(socket_dir, ignore_errors=True)

    print("Done.  (Jupyter server is still running on the remote host.)", end="\r\n")


if __name__ == "__main__":
    main()
